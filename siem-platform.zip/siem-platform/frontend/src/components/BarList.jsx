export default function BarList({ items, label, value, render, emptyText = 'Nothing to show yet' }) {
  if (!items.length) return <p className="muted">{emptyText}</p>;
  const max = Math.max(1, ...items.map(value));
  return (
    <ul className="barlist">
      {items.map((it, i) => (
        <li key={i}>
          <div className="barlist-row">
            <span className="barlist-label">{render ? render(it) : label(it)}</span>
            <span className="barlist-value">{value(it)}</span>
          </div>
          <div className="barlist-track"><div className="barlist-fill" style={{ width: `${(value(it) / max) * 100}%` }} /></div>
        </li>
      ))}
    </ul>
  );
}
