import { Link } from 'react-router-dom';

export function Stat({ label, value, note, to, tone }) {
  const body = (
    <>
      <span className="stat-label">{label}</span>
      <span className={`stat-value ${tone ? `tone-${tone}` : ''}`}>{Number(value ?? 0).toLocaleString()}</span>
      {note && <span className="stat-note">{note}</span>}
    </>
  );
  return to ? <Link to={to} className="stat stat-link">{body}</Link> : <div className="stat">{body}</div>;
}

export const StatRow = ({ children }) => <div className="stat-row">{children}</div>;

// Open alerts split by severity, as one stacked bar.
export function SeverityStack({ counts }) {
  const order = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
  const total = order.reduce((s, k) => s + (counts[k] || 0), 0);
  return (
    <div className="sevstack">
      <div className="sevstack-bar" role="img" aria-label={order.map((k) => `${counts[k] || 0} ${k.toLowerCase()}`).join(', ')}>
        {total === 0 && <span className="sevstack-empty" />}
        {order.map((k) => (counts[k] ? <span key={k} className={`fill-${k.toLowerCase()}`} style={{ flexGrow: counts[k] }} /> : null))}
      </div>
      <ul className="sevstack-legend">
        {order.map((k) => (
          <li key={k}><i className={`fill-${k.toLowerCase()}`} />{k.charAt(0) + k.slice(1).toLowerCase()}<b>{counts[k] || 0}</b></li>
        ))}
      </ul>
    </div>
  );
}
