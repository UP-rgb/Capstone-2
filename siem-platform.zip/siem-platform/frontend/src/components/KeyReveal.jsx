import { useState } from 'react';
import { Modal } from './ui';

// Shows a freshly issued device API key exactly once, with a ready-to-run test command.
export default function KeyReveal({ device, apiKey, notice, onClose }) {
  const [copied, setCopied] = useState('');
  const origin = window.location.origin.replace(':5173', ':5000');
  const curl = `curl -X POST ${origin}/api/ingest \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ${apiKey}" \\
  -d '{"eventType":"auth_failure","severity":"LOW","sourceIP":"192.168.1.50","username":"administrator","message":"Test event from ${device.name}"}'`;
  const copy = async (text, what) => {
    try { await navigator.clipboard.writeText(text); setCopied(what); } catch { setCopied(''); }
  };
  return (
    <Modal title={`API key for ${device.name}`} onClose={onClose} wide footer={<button type="button" className="btn" onClick={onClose}>I have stored the key</button>}>
      <p className="warn-note">{notice || 'Store this key now. Only a hash is kept on the server, so it cannot be shown again.'}</p>
      <div className="key-box">
        <code className="mono">{apiKey}</code>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => copy(apiKey, 'key')}>{copied === 'key' ? 'Copied' : 'Copy key'}</button>
      </div>
      <p className="small muted">Send it in the <code className="mono">x-api-key</code> header. To test ingestion from the device:</p>
      <pre className="json">{curl}</pre>
      <button type="button" className="btn btn-ghost btn-sm" onClick={() => copy(curl, 'curl')}>{copied === 'curl' ? 'Copied' : 'Copy command'}</button>
    </Modal>
  );
}
