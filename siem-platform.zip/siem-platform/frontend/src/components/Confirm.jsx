import { useState } from 'react';
import { ErrorNote, Modal } from './ui';

export default function Confirm({ title, children, confirmLabel = 'Delete', danger = true, onConfirm, onClose }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const go = async () => {
    setBusy(true); setError(null);
    try { await onConfirm(); onClose(); } catch (e) { setError(e); setBusy(false); }
  };
  return (
    <Modal title={title} onClose={onClose} footer={(
      <>
        <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button type="button" className={`btn ${danger ? 'btn-danger' : ''}`} onClick={go} disabled={busy}>{busy ? 'Working…' : confirmLabel}</button>
      </>
    )}>
      {children}
      <ErrorNote error={error} />
    </Modal>
  );
}
