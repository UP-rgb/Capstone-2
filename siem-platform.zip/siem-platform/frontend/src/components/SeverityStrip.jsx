import { hourLabel, sentence } from '../utils/format';

// The last 24 hours as a strip of hourly columns: height = event volume,
// colour = the worst detection seen in that hour (grey when nothing was detected).
export default function SeverityStrip({ hourly }) {
  const max = Math.max(1, ...hourly.map((h) => h.events));
  const totalDet = hourly.reduce((s, h) => s + h.detections, 0);
  return (
    <div className="strip-wrap">
      <div className="strip" role="img" aria-label={`Events per hour over 24 hours, ${totalDet} detections`}>
        {hourly.map((h) => {
          const height = h.events ? Math.max(6, Math.round(Math.sqrt(h.events / max) * 100)) : 2;
          const sev = h.maxSeverity ? h.maxSeverity.toLowerCase() : 'none';
          return (
            <div key={h.hour} className="strip-col" title={`${hourLabel(h.hour)}: ${h.events} events, ${h.detections} detections${h.maxSeverity ? `, worst ${sentence(h.maxSeverity)}` : ''}`}>
              <div className={`strip-bar strip-${sev}`} style={{ height: `${height}%` }} />
              {h.detections > 0 && <span className={`strip-pin strip-pin-${sev}`}>{h.detections}</span>}
            </div>
          );
        })}
      </div>
      <div className="strip-axis" aria-hidden="true">
        {hourly.map((h, i) => (
          <span key={h.hour} className={i === hourly.length - 1 ? 'strip-now' : undefined}>
            {i === hourly.length - 1 ? 'Now' : i % 6 === 0 ? hourLabel(h.hour) : ''}
          </span>
        ))}
      </div>
      <div className="strip-legend">
        {['critical', 'high', 'medium', 'low', 'none'].map((s) => (
          <span key={s}><i className={`strip-${s}`} />{s === 'none' ? 'No detection' : sentence(s.toUpperCase())}</span>
        ))}
      </div>
    </div>
  );
}
