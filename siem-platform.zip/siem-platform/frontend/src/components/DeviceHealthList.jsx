import { HealthDot } from './ui';
import { sentence, timeAgo } from '../utils/format';

export default function DeviceHealthList({ devices }) {
  if (!devices.length) return <p className="muted">No devices registered yet.</p>;
  return (
    <ul className="devlist">
      {devices.map((d) => (
        <li key={d.id}>
          <div>
            <div className="devlist-name">{d.name}</div>
            <div className="muted small">{sentence(d.type)}, {Number(d.eventCount || 0).toLocaleString()} events</div>
          </div>
          <div className="devlist-side">
            <HealthDot health={d.health} />
            <span className="muted small">{d.lastHeartbeat ? `Seen ${timeAgo(d.lastHeartbeat)}` : 'No heartbeat yet'}</span>
          </div>
        </li>
      ))}
    </ul>
  );
}
