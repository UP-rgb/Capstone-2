import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLive } from '../context/LiveContext';
import Toasts from './Toasts';

const ADMIN_NAV = [
  { group: 'Monitor', items: [
    ['', 'Overview'], ['alerts', 'Alerts'], ['incidents', 'Incidents'], ['events', 'Event search'], ['mitre', 'ATT&CK coverage'], ['reports', 'SOC reports'],
  ] },
  { group: 'Intelligence', items: [
    ['threat-intel', 'Threat intelligence'], ['ioc', 'IOC database'], ['playbooks', 'Response playbooks'],
  ] },
  { group: 'Administration', items: [
    ['devices', 'Devices and API keys'], ['users', 'Users and roles'], ['evaluation', 'Detection evaluation'], ['audit', 'Audit log'],
  ] },
];

const CLIENT_NAV = [
  { group: 'Monitor', items: [
    ['', 'Overview'], ['alerts', 'Alerts'], ['incidents', 'Incidents'], ['events', 'Event search'], ['mitre', 'ATT&CK coverage'], ['reports', 'SOC reports'],
  ] },
  { group: 'Your environment', items: [
    ['devices', 'Monitored devices'], ['playbooks', 'Response playbooks'],
  ] },
];

function Shield() {
  return (
    <svg viewBox="0 0 32 32" width="28" height="28" aria-hidden="true">
      <path d="M16 2 4 6.5v8.2c0 7.4 5.1 13.4 12 15.3 6.9-1.9 12-7.9 12-15.3V6.5L16 2z" fill="currentColor" opacity=".16" />
      <path d="M16 2 4 6.5v8.2c0 7.4 5.1 13.4 12 15.3 6.9-1.9 12-7.9 12-15.3V6.5L16 2z" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <path d="M9 17h4l2-5 3 9 2-4h3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function Layout() {
  const { user, isAdmin, base, logout } = useAuth();
  const { connected } = useLive();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const nav = isAdmin ? ADMIN_NAV : CLIENT_NAV;

  useEffect(() => setOpen(false), [location.pathname]);

  const signOut = () => { logout(); navigate('/login', { replace: true }); };

  return (
    <div className={`shell ${isAdmin ? 'shell-admin' : 'shell-client'}`}>
      <a href="#main" className="skip-link">Skip to content</a>
      <aside className={`sidebar no-print ${open ? 'open' : ''}`}>
        <div className="brand">
          <Shield />
          <div>
            <div className="brand-name">Enterprise SIEM</div>
            <div className="brand-role">{isAdmin ? 'Administrator console' : (user.organization || 'Client workspace')}</div>
          </div>
        </div>

        <nav className="nav" aria-label="Main">
          {nav.map((g) => (
            <div key={g.group} className="nav-group">
              <div className="nav-group-label">{g.group}</div>
              {g.items.map(([path, label]) => (
                <NavLink key={path} to={path ? `${base}/${path}` : base} end={!path} className="nav-link">{label}</NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-foot">
          <div className={`live ${connected ? 'live-on' : ''}`}>
            <span aria-hidden="true" />{connected ? 'Live updates on' : 'Live updates reconnecting'}
          </div>
          <div className="who">
            <div className="who-name">{user.fullName || user.username}</div>
            <div className="who-meta">{user.username}, {isAdmin ? 'administrator' : 'client analyst'}</div>
          </div>
          <div className="foot-actions">
            <NavLink to={`${base}/account`} className="btn btn-ghost-dark btn-sm">Account</NavLink>
            <button type="button" className="btn btn-ghost-dark btn-sm" onClick={signOut}>Sign out</button>
          </div>
        </div>
      </aside>

      <div className="main-wrap">
        <div className="topbar no-print">
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen((o) => !o)} aria-expanded={open}>Menu</button>
          <span className="topbar-title">Enterprise SIEM</span>
        </div>
        <main id="main" className="main">
          <Outlet />
        </main>
      </div>
      {open && <div className="scrim" onClick={() => setOpen(false)} aria-hidden="true" />}
      <Toasts />
    </div>
  );
}
