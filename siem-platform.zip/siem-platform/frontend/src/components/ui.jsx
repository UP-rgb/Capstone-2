import { useEffect, useRef } from 'react';
import { sentence } from '../utils/format';

export function SeverityBadge({ severity, score }) {
  if (!severity) return <span className="muted">—</span>;
  return (
    <span className={`sev sev-${severity.toLowerCase()}`} title={score !== undefined ? `Risk score ${score}` : undefined}>
      <span className="sev-dot" aria-hidden="true" />
      {sentence(severity)}
      {score !== undefined && <span className="sev-score">{score}</span>}
    </span>
  );
}

export function StatusPill({ status }) {
  return <span className={`status status-${String(status).toLowerCase()}`}>{sentence(status)}</span>;
}

export function HealthDot({ health }) {
  const label = { online: 'Online', stale: 'No recent heartbeat', never_seen: 'Never connected', disabled: 'Disabled' }[health] || health;
  return <span className={`health health-${health}`}><span aria-hidden="true" />{label}</span>;
}

export const Mono = ({ children, title }) => <code className="mono" title={title}>{children ?? '—'}</code>;

export function PageHeader({ title, intro, actions }) {
  return (
    <header className="page-header">
      <div>
        <h1>{title}</h1>
        {intro && <p className="page-intro">{intro}</p>}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  );
}

export function Panel({ title, aside, children, className = '', flush = false }) {
  return (
    <section className={`panel ${flush ? 'panel-flush' : ''} ${className}`}>
      {(title || aside) && (
        <div className="panel-head">
          {title && <h2>{title}</h2>}
          {aside && <div className="panel-aside">{aside}</div>}
        </div>
      )}
      <div className="panel-body">{children}</div>
    </section>
  );
}

export const EmptyState = ({ title, children }) => (
  <div className="empty">
    <p className="empty-title">{title}</p>
    {children && <p className="muted">{children}</p>}
  </div>
);

export const ErrorNote = ({ error, onRetry }) => (error ? (
  <div className="error-note" role="alert">
    <span>{error.message || String(error)}</span>
    {onRetry && <button type="button" className="btn btn-ghost btn-sm" onClick={onRetry}>Try again</button>}
  </div>
) : null);

export const Loading = ({ label = 'Loading' }) => <div className="loading" aria-live="polite">{label}…</div>;

export function Pagination({ pagination, onPage }) {
  if (!pagination || pagination.pages <= 1) return null;
  const { page, pages, total } = pagination;
  return (
    <nav className="pager" aria-label="Pagination">
      <span className="muted">{total.toLocaleString()} results, page {page} of {pages}</span>
      <div>
        <button type="button" className="btn btn-ghost btn-sm" disabled={page <= 1} onClick={() => onPage(page - 1)}>Previous</button>
        <button type="button" className="btn btn-ghost btn-sm" disabled={page >= pages} onClick={() => onPage(page + 1)}>Next</button>
      </div>
    </nav>
  );
}

export function Modal({ title, onClose, children, footer, wide = false }) {
  const ref = useRef(null);
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    ref.current?.querySelector('input, select, textarea, button')?.focus();
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'modal-wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
        <div className="modal-head">
          <h2>{title}</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close">×</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Field({ label, hint, children, error }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
      {hint && !error && <span className="field-hint">{hint}</span>}
      {error && <span className="field-error">{error}</span>}
    </label>
  );
}

export function Select({ value, onChange, options, placeholder, ...rest }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} {...rest}>
      {placeholder !== undefined && <option value="">{placeholder}</option>}
      {options.map((o) => (typeof o === 'string'
        ? <option key={o} value={o}>{sentence(o)}</option>
        : <option key={o.value} value={o.value}>{o.label}</option>))}
    </select>
  );
}
