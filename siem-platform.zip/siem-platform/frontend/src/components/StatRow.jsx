import { Link } from 'react-router-dom';

// A single ruled row of headline counts. `to` makes a figure a shortcut to the filtered list.
export default function StatRow({ stats }) {
  return (
    <dl className="stats">
      {stats.map((s) => {
        const inner = (
          <>
            <dt>{s.label}</dt>
            <dd className={s.tone ? `tone-${s.tone}` : undefined}>{s.display ?? Number(s.value || 0).toLocaleString()}</dd>
            {s.note && <span className="stat-note">{s.note}</span>}
          </>
        );
        return s.to
          ? <Link key={s.label} to={s.to} className="stat stat-link">{inner}</Link>
          : <div key={s.label} className="stat">{inner}</div>;
      })}
    </dl>
  );
}
