import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLive } from '../context/LiveContext';
import { SeverityBadge } from './ui';
import { attackLabel } from '../utils/format';

export default function Toasts() {
  const { toasts, dismiss } = useLive();
  const { base } = useAuth();
  if (!toasts.length) return null;
  return (
    <div className="toasts" aria-live="assertive">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast-${t.alert.severity.toLowerCase()}`}>
          <div className="toast-top">
            <SeverityBadge severity={t.alert.severity} score={t.alert.riskScore} />
            <span className="muted">{t.alert.device?.name}</span>
            <button type="button" className="icon-btn" onClick={() => dismiss(t.id)} aria-label="Dismiss">×</button>
          </div>
          <p className="toast-title">{t.alert.title}</p>
          <p className="toast-meta small">
            <span>{attackLabel(t.alert.attackType)}</span>
            <span className="mono">{t.alert.mitreTechnique || 'unmapped'}</span>
            {t.incident && <Link to={`${base}/incidents/${t.incident.id}`} onClick={() => dismiss(t.id)}>Open {t.incident.reference}</Link>}
          </p>
        </div>
      ))}
    </div>
  );
}
