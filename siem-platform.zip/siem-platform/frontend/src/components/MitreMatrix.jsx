import { Link } from 'react-router-dom';

// Tactic columns with the platform's mapped techniques; tiles darken with incident count.
export default function MitreMatrix({ mitre, tacticOrder, base, compact = false }) {
  const max = Math.max(1, ...mitre.map((m) => m.count));
  const tactics = tacticOrder.filter((t) => mitre.some((m) => m.tactic === t));
  return (
    <div className={`matrix ${compact ? 'matrix-compact' : ''}`}>
      {tactics.map((tactic) => (
        <div key={tactic} className="matrix-col">
          <div className="matrix-tactic">{tactic}</div>
          {mitre.filter((m) => m.tactic === tactic).map((m) => {
            const level = m.count ? Math.ceil((m.count / max) * 4) : 0;
            return (
              <Link
                key={m.technique}
                to={`${base}/incidents?technique=${encodeURIComponent(m.technique)}`}
                className={`matrix-tile heat-${level}`}
                title={`${m.technique} ${m.name}: ${m.count} incident(s)`}
              >
                <span className="mono matrix-id">{m.technique}</span>
                <span className="matrix-name">{m.name}</span>
                <span className="matrix-count">{m.count}</span>
              </Link>
            );
          })}
        </div>
      ))}
    </div>
  );
}
