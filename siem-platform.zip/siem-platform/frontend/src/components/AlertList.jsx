import { Link } from 'react-router-dom';
import { SeverityBadge } from './ui';
import { attackLabel, timeAgo } from '../utils/format';

// Compact feed used on both dashboards.
export default function AlertList({ alerts, base }) {
  if (!alerts.length) return <p className="muted">No alerts yet. Detections will appear here the moment they happen.</p>;
  return (
    <ol className="feed">
      {alerts.map((a) => (
        <li key={a.id} className={`feed-item feed-${a.severity.toLowerCase()}`}>
          <div className="feed-main">
            <Link to={a.incidentId ? `${base}/incidents/${a.incidentId}` : `${base}/alerts?q=${encodeURIComponent(a.sourceIP || a.title)}`} className="feed-title">{a.title}</Link>
            <div className="feed-meta">
              <span>{attackLabel(a.attackType)}</span>
              {a.mitreTechnique && <span className="mono">{a.mitreTechnique}</span>}
              {a.device && <span>{a.device.name}</span>}
              {a.eventCount > 1 && <span>{a.eventCount} events</span>}
            </div>
          </div>
          <div className="feed-side">
            <SeverityBadge severity={a.severity} score={a.riskScore} />
            <span className="muted small">{timeAgo(a.lastSeen)}</span>
          </div>
        </li>
      ))}
    </ol>
  );
}
