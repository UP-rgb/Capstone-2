import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, homeFor, useAuth } from './context/AuthContext';
import { LiveProvider } from './context/LiveContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import { Loading } from './components/ui';

import Login from './pages/Login';
import NotFound from './pages/NotFound';
import AdminDashboard from './pages/admin/AdminDashboard';
import UsersPage from './pages/admin/UsersPage';
import DevicesPage from './pages/admin/DevicesPage';
import IocPage from './pages/admin/IocPage';
import ThreatIntelPage from './pages/admin/ThreatIntelPage';
import AuditPage from './pages/admin/AuditPage';
import EvaluationPage from './pages/admin/EvaluationPage';
import ClientDashboard from './pages/client/ClientDashboard';
import MyDevicesPage from './pages/client/MyDevicesPage';
import AlertsPage from './pages/shared/AlertsPage';
import IncidentsPage from './pages/shared/IncidentsPage';
import IncidentDetailPage from './pages/shared/IncidentDetailPage';
import EventsPage from './pages/shared/EventsPage';
import MitrePage from './pages/shared/MitrePage';
import PlaybooksPage from './pages/shared/PlaybooksPage';
import AccountPage from './pages/shared/AccountPage';
import ReportsPage from './pages/shared/ReportsPage';

// Pages both roles can open. Data is scoped by the API, so the same page shows
// every tenant to an administrator and only the client's own devices to a client.
const shared = (
  <>
    <Route path="alerts" element={<AlertsPage />} />
    <Route path="incidents" element={<IncidentsPage />} />
    <Route path="incidents/:id" element={<IncidentDetailPage />} />
    <Route path="events" element={<EventsPage />} />
    <Route path="mitre" element={<MitrePage />} />
    <Route path="playbooks" element={<PlaybooksPage />} />
    <Route path="reports" element={<ReportsPage />} />
    <Route path="account" element={<AccountPage />} />
  </>
);

function Home() {
  const { user, ready } = useAuth();
  if (!ready) return <div className="center-screen"><Loading label="Checking session" /></div>;
  return <Navigate to={user ? homeFor(user) : '/login'} replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <LiveProvider>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />

            <Route path="/admin" element={<ProtectedRoute role="ADMIN"><Layout /></ProtectedRoute>}>
              <Route index element={<AdminDashboard />} />
              {shared}
              <Route path="threat-intel" element={<ThreatIntelPage />} />
              <Route path="ioc" element={<IocPage />} />
              <Route path="devices" element={<DevicesPage />} />
              <Route path="users" element={<UsersPage />} />
              <Route path="audit" element={<AuditPage />} />
              <Route path="evaluation" element={<EvaluationPage />} />
              <Route path="*" element={<NotFound />} />
            </Route>

            <Route path="/client" element={<ProtectedRoute role="CLIENT"><Layout /></ProtectedRoute>}>
              <Route index element={<ClientDashboard />} />
              {shared}
              <Route path="devices" element={<MyDevicesPage />} />
              <Route path="*" element={<NotFound />} />
            </Route>

            <Route path="*" element={<Home />} />
          </Routes>
        </LiveProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
