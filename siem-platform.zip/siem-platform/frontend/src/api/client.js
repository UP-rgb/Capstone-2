// Thin fetch wrapper: adds the JWT, parses JSON errors, and signs out on 401.
const BASE = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');
const TOKEN_KEY = 'siem.token';

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };

export class ApiError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export async function api(path, { method = 'GET', body, query } = {}) {
  const qs = query
    ? `?${new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined && v !== '' && v !== null)).toString()}`
    : '';
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const token = tokenStore.get();
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(`${BASE}/api${path}${qs}`, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch {
    throw new ApiError(0, 'Cannot reach the SIEM server. Check that the backend is running.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && token) onUnauthorized();
    const details = data.details && typeof data.details === 'object' && !Array.isArray(data.details)
      ? Object.entries(data.details).map(([k, v]) => `${k} ${v}`).join('; ')
      : null;
    throw new ApiError(res.status, details ? `${data.error}: ${details}` : (data.error || `Request failed (${res.status})`), data.details);
  }
  return data;
}

export const socketUrl = () => BASE || window.location.origin;

// Authenticated file download (CSV exports). The JWT travels in a header, so a plain
// <a href> cannot be used; fetch the file and hand the browser a blob instead.
export async function download(path, query) {
  const qs = query ? `?${new URLSearchParams(Object.entries(query).filter(([, v]) => v)).toString()}` : '';
  const token = tokenStore.get();
  let res;
  try {
    res = await fetch(`${BASE}/api${path}${qs}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
  } catch {
    throw new ApiError(0, 'Cannot reach the SIEM server. Check that the backend is running.');
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && token) onUnauthorized();
    throw new ApiError(res.status, data.error || `Download failed (${res.status})`);
  }
  const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '')?.[1] || 'export.csv';
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement('a'), { href: url, download: name });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
