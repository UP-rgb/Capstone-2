import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { socketUrl, tokenStore } from '../api/client';
import { useAuth } from './AuthContext';

const LiveContext = createContext({ connected: false, revision: 0, toasts: [], dismiss: () => {} });

// FR9: one Socket.io connection per signed-in session. `revision` bumps on every push
// so pages can refetch; new alerts also raise a toast.
export function LiveProvider({ children }) {
  const { user } = useAuth();
  const [connected, setConnected] = useState(false);
  const [revision, setRevision] = useState(0);
  const [toasts, setToasts] = useState([]);
  const timers = useRef({});

  const dismiss = useCallback((id) => {
    setToasts((t) => t.filter((x) => x.id !== id));
    clearTimeout(timers.current[id]);
  }, []);

  useEffect(() => {
    if (!user) return undefined;
    const socket = io(socketUrl(), { auth: { token: tokenStore.get() }, transports: ['websocket', 'polling'] });
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('connect_error', () => setConnected(false));

    const bump = () => setRevision((r) => r + 1);
    socket.on('new_alert', (payload) => {
      bump();
      const id = `${payload.alert.id}-${Date.now()}`;
      setToasts((t) => [{ id, ...payload }, ...t].slice(0, 4));
      timers.current[id] = setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 9000);
    });
    socket.on('alert_updated', bump);
    socket.on('incident_updated', bump);

    return () => {
      socket.disconnect();
      Object.values(timers.current).forEach(clearTimeout);
    };
  }, [user]);

  const value = useMemo(() => ({ connected, revision, toasts, dismiss }), [connected, revision, toasts, dismiss]);
  return <LiveContext.Provider value={value}>{children}</LiveContext.Provider>;
}

export const useLive = () => useContext(LiveContext);
