import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { ErrorNote, Loading, Mono, PageHeader, Panel } from '../../components/ui';
import MitreMatrix from '../../components/MitreMatrix';
import { attackLabel } from '../../utils/format';

export default function MitrePage() {
  const { base, isAdmin } = useAuth();
  const { data, error, loading, reload } = useApi('/dashboard/stats', null, { live: true });
  if (loading && !data) return <Loading />;
  if (error && !data) return <ErrorNote error={error} onRetry={reload} />;

  return (
    <>
      <PageHeader
        title="MITRE ATT&CK coverage"
        intro={`The eight detection categories the platform maps to ATT&CK, grouped by tactic. Darker tiles have more incidents${isAdmin ? '' : ' on your devices'}. Choose a tile to see those incidents.`}
      />
      <Panel>
        <MitreMatrix mitre={data.mitre} tacticOrder={data.tacticOrder} base={base} />
      </Panel>
      <Panel title="Mapping table" flush>
        <div className="table-scroll">
          <table className="table">
            <thead><tr><th>Detection category</th><th>Technique</th><th>ATT&amp;CK name</th><th>Tactic</th><th className="num">Incidents</th></tr></thead>
            <tbody>
              {data.mitre.map((m) => (
                <tr key={m.technique}>
                  <td>{attackLabel(m.attackType)} <span className="muted small"><Mono>{m.attackType}</Mono></span></td>
                  <td><a href={`https://attack.mitre.org/techniques/${m.technique.replace('.', '/')}/`} target="_blank" rel="noreferrer"><Mono>{m.technique}</Mono></a></td>
                  <td>{m.name}</td>
                  <td>{m.tactic}</td>
                  <td className="num">{m.count ? <Link to={`${base}/incidents?technique=${encodeURIComponent(m.technique)}&status=all`}>{m.count}</Link> : 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}
