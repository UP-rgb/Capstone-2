import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import {
  EmptyState, ErrorNote, Loading, Mono, PageHeader, Pagination, Panel, Select, SeverityBadge, StatusPill,
} from '../../components/ui';
import SearchInput from '../../components/SearchInput';
import { ALERT_STATUSES, ATTACK_LABELS, attackLabel, dateTime, SEVERITIES, timeAgo } from '../../utils/format';

const STATUS_FILTERS = [{ value: 'open', label: 'Open (new or acknowledged)' }, ...ALERT_STATUSES.map((s) => ({ value: s, label: s.charAt(0) + s.slice(1).toLowerCase().replace('_', ' ') }))];
const ATTACKS = Object.entries(ATTACK_LABELS).map(([value, label]) => ({ value, label }));

export default function AlertsPage() {
  const { base, isAdmin } = useAuth();
  const [f, setF, reset] = useQueryState({ status: 'open' });
  const query = { status: f.status === 'all' ? '' : f.status, severity: f.severity, attackType: f.attackType, q: f.q, page: f.page, limit: 25 };
  const { data, error, loading, reload, setData } = useApi('/alerts', query, { live: true });
  const users = useApi('/users', null, { skip: !isAdmin });
  const [rowError, setRowError] = useState(null);

  const patch = async (alert, path, body) => {
    setRowError(null);
    try {
      const r = await api(`/alerts/${alert.id}/${path}`, { method: 'PATCH', body });
      setData((d) => ({ ...d, data: d.data.map((a) => (a.id === alert.id ? { ...a, ...r.data } : a)) }));
    } catch (e) { setRowError(e); }
  };

  return (
    <>
      <PageHeader
        title="Alerts"
        intro={isAdmin
          ? 'Every detection that scored 40 or more. Repeated hits from the same source on the same device are folded into one alert.'
          : 'Detections on your devices that scored 40 or more. Repeated hits from the same source are folded into one alert.'}
      />

      <div className="filters">
        <SearchInput value={f.q} onChange={(v) => setF('q', v)} placeholder="Search title or source IP" />
        <Select value={f.status} onChange={(v) => setF('status', v || 'all')} options={[...STATUS_FILTERS, { value: 'all', label: 'Any status' }]} aria-label="Status" />
        <Select value={f.severity || ''} onChange={(v) => setF('severity', v)} options={SEVERITIES} placeholder="Any severity" aria-label="Severity" />
        <Select value={f.attackType || ''} onChange={(v) => setF('attackType', v)} options={ATTACKS} placeholder="Any attack type" aria-label="Attack type" />
        <button type="button" className="btn btn-ghost btn-sm" onClick={reset}>Clear filters</button>
      </div>

      <ErrorNote error={rowError} />
      <Panel flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? (
          <EmptyState title="No alerts match these filters">Try another status, or clear the filters to see everything.</EmptyState>
        ) : (
          <div className="table-scroll">
            <table className="table">
              <thead>
                <tr>
                  <th>Alert</th><th>Severity</th><th>Device</th><th>Source</th><th className="num">Events</th>
                  <th>Last seen</th><th>Status</th>{isAdmin && <th>Assigned to</th>}
                </tr>
              </thead>
              <tbody>
                {data.data.map((a) => (
                  <tr key={a.id}>
                    <td>
                      <div className="strong">{a.title}</div>
                      <div className="muted small">
                        {attackLabel(a.attackType)}{a.mitreTechnique && <> <Mono>{a.mitreTechnique}</Mono></>}
                        {a.incident && <> <Link to={`${base}/incidents/${a.incident.id}`}>{a.incident.reference}</Link></>}
                      </div>
                    </td>
                    <td><SeverityBadge severity={a.severity} score={a.riskScore} /></td>
                    <td>{a.device?.name || '—'}</td>
                    <td><Mono>{a.sourceIP}</Mono></td>
                    <td className="num">{a.eventCount}</td>
                    <td className="nowrap" title={dateTime(a.lastSeen)}>{timeAgo(a.lastSeen)}</td>
                    <td>
                      <select className="inline-select" value={a.status} onChange={(e) => patch(a, 'status', { status: e.target.value })} aria-label={`Status of ${a.title}`}>
                        {ALERT_STATUSES.map((s) => <option key={s} value={s}>{s.charAt(0) + s.slice(1).toLowerCase().replace('_', ' ')}</option>)}
                      </select>
                    </td>
                    {isAdmin && (
                      <td>
                        <select className="inline-select" value={a.assignedTo || ''} onChange={(e) => patch(a, 'assign', { userId: e.target.value || null })} aria-label={`Assignee for ${a.title}`}>
                          <option value="">Unassigned</option>
                          {(users.data?.data || []).filter((u) => u.isActive).map((u) => <option key={u.id} value={u.id}>{u.username}</option>)}
                        </select>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      {data && <Pagination pagination={data.pagination} onPage={(p) => setF('page', p)} />}
      <p className="muted small legend-note">Status keys: <StatusPill status="NEW" /> not yet looked at, <StatusPill status="ACKNOWLEDGED" /> someone is on it, <StatusPill status="FALSE_POSITIVE" /> benign activity.</p>
    </>
  );
}
