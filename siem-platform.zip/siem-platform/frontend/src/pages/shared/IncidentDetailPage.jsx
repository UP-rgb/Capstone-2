import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import {
  EmptyState, ErrorNote, Field, Loading, Modal, Mono, Panel, SeverityBadge, StatusPill,
} from '../../components/ui';
import { attackLabel, dateTime, INCIDENT_STATUSES, iocTypeLabel, sentence, timeAgo } from '../../utils/format';

const EVIDENCE_TYPES = [['note', 'Note'], ['log', 'Log extract'], ['indicator', 'Indicator'], ['screenshot-ref', 'Screenshot reference']];

const show = (v) => {
  if (v === null || v === undefined || v === '') return '—';
  if (Array.isArray(v)) return v.length > 6 ? `${v.slice(0, 6).join(', ')} and ${v.length - 6} more` : v.join(', ');
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
};
const humanKey = (k) => sentence(k.replace(/([a-z])([A-Z])/g, '$1_$2').toUpperCase());

function Lifecycle({ status }) {
  const current = INCIDENT_STATUSES.indexOf(status);
  return (
    <ol className="lifecycle" aria-label="Incident lifecycle">
      {INCIDENT_STATUSES.map((s, i) => (
        <li key={s} className={i < current ? 'done' : i === current ? 'current' : ''} aria-current={i === current ? 'step' : undefined}>
          <span className="lc-n">{i + 1}</span>
          <span className="lc-label">{sentence(s)}</span>
        </li>
      ))}
    </ol>
  );
}

function StatusControl({ incident, isAdmin, onChanged }) {
  const idx = INCIDENT_STATUSES.indexOf(incident.status);
  const allowed = INCIDENT_STATUSES.filter((s) => isAdmin || s !== 'CLOSED');
  const nextStep = INCIDENT_STATUSES[idx + 1];
  const [target, setTarget] = useState(nextStep && allowed.includes(nextStep) ? nextStep : '');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  if (!isAdmin && incident.status === 'CLOSED') {
    return <p className="muted">This incident was closed by an administrator. Ask an administrator to reopen it if the activity returns.</p>;
  }

  const save = async (e) => {
    e.preventDefault();
    if (!target) return;
    setBusy(true); setError(null);
    try {
      await api(`/incidents/${incident.id}/status`, { method: 'PATCH', body: { status: target, note: note.trim() || undefined } });
      setNote('');
      onChanged();
    } catch (err) { setError(err); } finally { setBusy(false); }
  };

  return (
    <form className="status-form" onSubmit={save}>
      <Field label="Move to">
        <select value={target} onChange={(e) => setTarget(e.target.value)}>
          <option value="">Choose a status</option>
          {allowed.filter((s) => s !== incident.status).map((s) => <option key={s} value={s}>{sentence(s)}</option>)}
        </select>
      </Field>
      <Field label="Note for the timeline" hint="Optional. Say what you did or found.">
        <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} />
      </Field>
      <ErrorNote error={error} />
      <button type="submit" className="btn" disabled={!target || busy}>{busy ? 'Saving…' : 'Update status'}</button>
      {!isAdmin && <p className="muted small">Only an administrator can close an incident.</p>}
    </form>
  );
}

function RiskBreakdown({ breakdown, score }) {
  if (!breakdown?.length) return <p className="muted">No breakdown recorded.</p>;
  const raw = breakdown.reduce((s, b) => s + b.points, 0);
  return (
    <table className="table table-compact">
      <tbody>
        {breakdown.map((b, i) => (
          <tr key={i}><td>{b.factor}</td><td className="num mono">+{b.points}</td></tr>
        ))}
      </tbody>
      <tfoot>
        <tr><td>Risk score{raw > 100 ? ` (${raw} capped at 100)` : ''}</td><td className="num mono strong">{score}</td></tr>
      </tfoot>
    </table>
  );
}

function CommentsPanel({ incident, onAdded }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      await api(`/incidents/${incident.id}/comments`, { method: 'POST', body: { comment: text } });
      setText('');
      onAdded();
    } catch (err) { setError(err); } finally { setBusy(false); }
  };
  return (
    <Panel title={`Comments (${incident.comments.length})`}>
      {incident.comments.length ? (
        <ul className="comments">
          {incident.comments.map((c) => (
            <li key={c.id}>
              <div className="comment-head"><strong>{c.username}</strong><span className="muted small" title={dateTime(c.createdAt)}>{timeAgo(c.createdAt)}</span></div>
              <p>{c.comment}</p>
            </li>
          ))}
        </ul>
      ) : <p className="muted">No comments yet. Record what you checked so the next analyst can pick up where you left off.</p>}
      <form onSubmit={submit} className="comment-form">
        <label className="sr-only" htmlFor="new-comment">Add a comment</label>
        <textarea id="new-comment" rows={3} value={text} onChange={(e) => setText(e.target.value)} placeholder="Add a comment" maxLength={5000} />
        <ErrorNote error={error} />
        <button type="submit" className="btn btn-sm" disabled={!text.trim() || busy}>{busy ? 'Posting…' : 'Post comment'}</button>
      </form>
    </Panel>
  );
}

function EvidencePanel({ incident, onAdded }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: '', type: 'note', content: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const close = () => { setOpen(false); setError(null); };
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      await api(`/incidents/${incident.id}/evidence`, { method: 'POST', body: form });
      setForm({ title: '', type: 'note', content: '' });
      close();
      onAdded();
    } catch (err) { setError(err); } finally { setBusy(false); }
  };
  return (
    <Panel title={`Analyst evidence (${incident.evidenceItems.length})`} aside={<button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen(true)}>Add evidence</button>}>
      {incident.evidenceItems.length ? (
        <ul className="evidence">
          {incident.evidenceItems.map((ev) => (
            <li key={ev.id}>
              <div className="comment-head">
                <strong>{ev.title}</strong>
                <span className="muted small">{EVIDENCE_TYPES.find(([v]) => v === ev.type)?.[1] || ev.type}, added by {ev.username} {timeAgo(ev.createdAt)}</span>
              </div>
              {ev.content && <pre className="pre">{ev.content}</pre>}
            </li>
          ))}
        </ul>
      ) : <p className="muted">Attach log extracts, indicators or notes that support your findings.</p>}
      {open && (
        <Modal title="Add evidence" onClose={close} footer={(
          <>
            <button type="button" className="btn btn-ghost" onClick={close}>Cancel</button>
            <button type="submit" form="evidence-form" className="btn" disabled={!form.title.trim() || busy}>{busy ? 'Saving…' : 'Add evidence'}</button>
          </>
        )}
        >
          <form id="evidence-form" onSubmit={submit} className="form-grid">
            <Field label="Title"><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} maxLength={200} required /></Field>
            <Field label="Type">
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {EVIDENCE_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </Field>
            <Field label="Content"><textarea rows={8} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} className="mono-input" /></Field>
            <ErrorNote error={error} />
          </form>
        </Modal>
      )}
    </Panel>
  );
}

function EventsPanel({ events }) {
  const [raw, setRaw] = useState(null);
  return (
    <Panel title={`Linked events (${events.length})`} flush>
      {!events.length ? <div className="panel-pad"><p className="muted">No events linked.</p></div> : (
        <div className="table-scroll table-tall">
          <table className="table table-compact">
            <thead><tr><th>Time</th><th>Event</th><th>Source</th><th>Destination</th><th>User</th><th className="num">Risk</th><th /></tr></thead>
            <tbody>
              {events.map((ev) => (
                <tr key={ev.id} className={ev.attackType ? 'row-detected' : undefined}>
                  <td className="nowrap">{dateTime(ev.timestamp)}</td>
                  <td>
                    <Mono>{ev.eventType}</Mono>
                    {ev.message && <div className="muted small clamp">{ev.message}</div>}
                  </td>
                  <td><Mono>{ev.sourceIP}</Mono></td>
                  <td><Mono>{ev.destinationIP ? `${ev.destinationIP}${ev.destinationPort ? `:${ev.destinationPort}` : ''}` : null}</Mono></td>
                  <td>{ev.username || '—'}</td>
                  <td className="num">{ev.riskScore || '—'}</td>
                  <td><button type="button" className="btn btn-ghost btn-sm" onClick={() => setRaw(ev)}>Raw</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {raw && (
        <Modal title={`Raw payload, ${raw.eventType}`} onClose={() => setRaw(null)} wide>
          <pre className="pre">{JSON.stringify(raw.raw, null, 2)}</pre>
        </Modal>
      )}
    </Panel>
  );
}

export default function IncidentDetailPage() {
  const { id } = useParams();
  const { base, isAdmin } = useAuth();
  const { data, error, loading, reload } = useApi(`/incidents/${id}`, null, { live: true });
  const users = useApi('/users', null, { skip: !isAdmin });
  const [assignError, setAssignError] = useState(null);

  if (loading && !data) return <Loading label="Loading incident" />;
  if (error && !data) {
    return error.status === 404
      ? <EmptyState title="Incident not found">It may belong to another organisation or have been removed. <Link to={`${base}/incidents`}>Back to incidents</Link></EmptyState>
      : <ErrorNote error={error} onRetry={reload} />;
  }

  const inc = data.data;
  const ev = inc.evidence || {};
  const detection = ev.detection && typeof ev.detection === 'object' ? Object.entries(ev.detection) : [];

  const assign = async (userId) => {
    setAssignError(null);
    try {
      await api(`/incidents/${inc.id}/assign`, { method: 'PATCH', body: { userId: userId || null } });
      reload();
    } catch (e) { setAssignError(e); }
  };

  return (
    <>
      <div className="crumbs"><Link to={`${base}/incidents`}>Incidents</Link> <span aria-hidden="true">/</span> <Mono>{inc.reference}</Mono></div>
      <header className="incident-head">
        <div>
          <h1>{inc.title}</h1>
          <div className="incident-tags">
            <SeverityBadge severity={inc.severity} score={inc.riskScore} />
            <StatusPill status={inc.status} />
            <span>{attackLabel(inc.attackType)}</span>
            {inc.mitreTechnique && <span className="technique"><Mono>{inc.mitreTechnique}</Mono> {inc.mitreName}, {inc.mitreTactic}</span>}
          </div>
        </div>
      </header>

      <Panel><Lifecycle status={inc.status} /></Panel>

      <div className="grid grid-detail">
        <div className="stack">
          <Panel title="What happened">
            <p className="lede">{ev.latestDescription || inc.description}</p>
            {detection.length > 0 && (
              <dl className="kv kv-wide">
                {detection.map(([k, v]) => <FragmentKV key={k} k={humanKey(k)} v={show(v)} />)}
              </dl>
            )}
            {ev.secondaryDetections?.length > 0 && (
              <p className="muted small">Also matched: {ev.secondaryDetections.map((d) => d.title).join('; ')}</p>
            )}
          </Panel>

          <div className="grid grid-2">
            <Panel title={`Why it scored ${inc.riskScore}`}>
              <RiskBreakdown breakdown={ev.riskBreakdown} score={inc.riskScore} />
            </Panel>
            <Panel title="Indicators and threat intelligence">
              {!ev.iocMatches?.length && !ev.threatIntel?.length && <p className="muted">No IOC or threat-intelligence match for this activity. The score comes from the detection rule alone.</p>}
              {ev.iocMatches?.length > 0 && (
                <ul className="intel-list">
                  {ev.iocMatches.map((m, i) => (
                    <li key={`ioc-${i}`}>
                      <Mono>{m.value}</Mono>
                      <span className="muted small">IOC database, {iocTypeLabel(m.type)} in {m.field}, {sentence(m.confidence || 'MEDIUM')} confidence, source {m.source}</span>
                    </li>
                  ))}
                </ul>
              )}
              {ev.threatIntel?.length > 0 && (
                <ul className="intel-list">
                  {ev.threatIntel.map((t, i) => (
                    <li key={`ti-${i}`}>
                      <span><Mono>{t.indicator}</Mono> <SeverityBadge severity={t.severity} /></span>
                      <span className="muted small">{t.source}{t.confidence ? `, ${sentence(t.confidence)} confidence` : ''}{t.summary ? `. ${t.summary}` : ''}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Panel>
          </div>

          <EventsPanel events={inc.events} />
          <CommentsPanel incident={inc} onAdded={reload} />
          <EvidencePanel incident={inc} onAdded={reload} />
        </div>

        <aside className="stack">
          <Panel title="Change status">
            <StatusControl key={inc.status} incident={inc} isAdmin={isAdmin} onChanged={reload} />
          </Panel>

          <Panel title="Details">
            <dl className="kv">
              <dt>Device</dt><dd>{inc.device ? <>{inc.device.name} <span className="muted">({sentence(inc.device.type)})</span></> : '—'}</dd>
              <dt>Device address</dt><dd><Mono>{inc.device?.ipAddress}</Mono></dd>
              <dt>Source</dt><dd>{inc.sourceIP ? <Link to={`${base}/events?sourceIP=${encodeURIComponent(inc.sourceIP)}`}><Mono>{inc.sourceIP}</Mono></Link> : '—'}</dd>
              <dt>First seen</dt><dd>{dateTime(inc.firstSeen)}</dd>
              <dt>Last seen</dt><dd>{dateTime(inc.lastSeen)}</dd>
              <dt>Related events</dt><dd>{inc.eventCount}</dd>
              <dt>Alerts</dt><dd>{inc.alerts.length}</dd>
              {inc.resolvedAt && <><dt>Resolved</dt><dd>{dateTime(inc.resolvedAt)}</dd></>}
              <dt>Assigned to</dt>
              <dd>
                {isAdmin ? (
                  <select className="inline-select" value={inc.assignedTo || ''} onChange={(e) => assign(e.target.value)} aria-label="Assign incident">
                    <option value="">Unassigned</option>
                    {(users.data?.data || []).filter((u) => u.isActive).map((u) => <option key={u.id} value={u.id}>{u.fullName || u.username}</option>)}
                  </select>
                ) : (inc.assignee ? (inc.assignee.fullName || inc.assignee.username) : <span className="muted">Unassigned</span>)}
              </dd>
            </dl>
            <ErrorNote error={assignError} />
            {inc.assignments?.length > 0 && (
              <div className="assign-history">
                <p className="small strong">Assignment history</p>
                <ul className="plain-list small">
                  {inc.assignments.map((a) => (
                    <li key={a.id}>
                      {a.user ? (a.user.fullName || a.user.username) : 'Unassigned'}
                      <span className="muted"> by {a.assignedByUsername}, {timeAgo(a.createdAt)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </Panel>

          {inc.playbook && (
            <Panel title="Response playbook" aside={<Link to={`${base}/playbooks#${inc.attackType}`} className="small">All playbooks</Link>}>
              <p className="strong">{inc.playbook.title}</p>
              <ol className="steps">
                {inc.playbook.steps.map((s) => <li key={s}>{s}</li>)}
              </ol>
            </Panel>
          )}

          <Panel title="Timeline">
            <ol className="timeline">
              {[...(inc.timeline || [])].reverse().map((t, i) => (
                <li key={i} className={`tl-${t.type}`}>
                  <div className="tl-when" title={dateTime(t.at)}>{dateTime(t.at)}</div>
                  <div className="tl-what">{t.message}</div>
                  <div className="muted small">{t.by}</div>
                </li>
              ))}
            </ol>
          </Panel>
        </aside>
      </div>
    </>
  );
}

function FragmentKV({ k, v }) {
  return <><dt>{k}</dt><dd className="break">{v}</dd></>;
}
