import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { download } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import { EmptyState, ErrorNote, Loading, Mono, PageHeader, Panel, SeverityBadge, StatusPill } from '../../components/ui';
import StatRow from '../../components/StatRow';
import BarList from '../../components/BarList';
import {
  attackLabel, dateOnly, dateTime, duration, INCIDENT_STATUSES, sentence, SEVERITIES,
} from '../../utils/format';

const PRESETS = [['1', 'Last 24 hours'], ['7', 'Last 7 days'], ['30', 'Last 30 days'], ['custom', 'Custom']];
const DAY = 86400000;
const toInput = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);

function useRange(f) {
  return useMemo(() => {
    if (f.range === 'custom' && f.from && f.to) {
      const from = new Date(`${f.from}T00:00:00`);
      const to = new Date(`${f.to}T23:59:59`);
      return { from: from.toISOString(), to: to.toISOString() };
    }
    const days = Number(f.range) || 7;
    const to = new Date();
    return { from: new Date(to.getTime() - days * DAY).toISOString(), to: to.toISOString() };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [f.range, f.from, f.to]);
}

// Plain-language opening paragraph, so the printed report reads on its own.
function narrative(d, orgLabel) {
  const t = d.totals;
  const crit = d.incidentsBySeverity.CRITICAL || 0;
  const parts = [
    `Between ${dateTime(d.period.from)} and ${dateTime(d.period.to)} the platform processed ${t.events.toLocaleString()} security events from ${d.devices.length} device${d.devices.length === 1 ? '' : 's'} for ${orgLabel}.`,
    `${t.detections.toLocaleString()} event${t.detections === 1 ? ' was' : 's were'} classified as attacks, raising ${t.alerts} alert${t.alerts === 1 ? '' : 's'} and ${t.incidents} incident${t.incidents === 1 ? '' : 's'}${crit ? `, ${crit} of them critical` : ''}.`,
  ];
  if (t.incidents) {
    parts.push(`${t.resolvedInPeriod} incident${t.resolvedInPeriod === 1 ? ' was' : 's were'} resolved in the period and ${t.openIncidents} of the new incidents remain open.`);
    const rt = d.responseTimes;
    if (rt.acknowledgeMinutes.count) parts.push(`Analysts took a median of ${duration(rt.acknowledgeMinutes.p50)} to act on a new incident${rt.resolveMinutes.count ? ` and ${duration(rt.resolveMinutes.p50)} to resolve one` : ''}.`);
  }
  if (t.falsePositiveAlerts) parts.push(`${t.falsePositiveAlerts} alert${t.falsePositiveAlerts === 1 ? ' was marked as a false positive' : 's were marked as false positives'}.`);
  return parts.join(' ');
}

export default function ReportsPage() {
  const { base, isAdmin, user } = useAuth();
  const [f, setF, , setMany] = useQueryState({ range: '7' });
  const range = useRange(f);
  const { data, error, loading, reload } = useApi('/reports/summary', range);
  const [busy, setBusy] = useState('');
  const [dlError, setDlError] = useState(null);

  const orgLabel = isAdmin ? 'all tenants' : (user.organization || 'your organisation');
  const exportCsv = async (dataset) => {
    setBusy(dataset); setDlError(null);
    try { await download(`/reports/export/${dataset}`, range); } catch (e) { setDlError(e); } finally { setBusy(''); }
  };
  const setPreset = (v) => {
    if (v === 'custom') {
      const to = new Date();
      setMany({ range: 'custom', from: f.from || toInput(new Date(to.getTime() - 7 * DAY)), to: f.to || toInput(to) });
    } else setMany({ range: v, from: '', to: '' });
  };

  return (
    <>
      <div className="no-print stack">
        <PageHeader
          title="SOC reports"
          intro={`A summary of detections, incidents and analyst response for ${orgLabel} over a chosen period. Print it or save it as PDF from your browser, or download the underlying records as CSV.`}
          actions={<button type="button" className="btn" onClick={() => window.print()} disabled={!data}>Print or save as PDF</button>}
        />
        <div className="filters report-controls">
          <div className="segmented" role="group" aria-label="Report period">
            {PRESETS.map(([v, l]) => (
              <button key={v} type="button" className={f.range === v ? 'on' : ''} aria-pressed={f.range === v} onClick={() => setPreset(v)}>{l}</button>
            ))}
          </div>
          {f.range === 'custom' && (
            <>
              <label className="filter-date">From <input type="date" value={f.from || ''} max={f.to || undefined} onChange={(e) => setF('from', e.target.value)} /></label>
              <label className="filter-date">To <input type="date" value={f.to || ''} min={f.from || undefined} onChange={(e) => setF('to', e.target.value)} /></label>
            </>
          )}
          <span className="filters-gap" />
          <span className="muted small">Download as CSV:</span>
          {['incidents', 'alerts', 'events'].map((d) => (
            <button key={d} type="button" className="btn btn-ghost btn-sm" disabled={Boolean(busy)} onClick={() => exportCsv(d)}>{busy === d ? 'Preparing…' : sentence(d.toUpperCase())}</button>
          ))}
        </div>
        <ErrorNote error={dlError} />
      </div>

      {loading && !data ? <Loading label="Building report" /> : error ? <ErrorNote error={error} onRetry={reload} /> : (
        <article className="report">
          <header className="report-head">
            <div>
              <h2 className="report-title">SOC report for {isAdmin ? 'all tenants' : (user.organization || user.username)}</h2>
              <p className="report-period">{dateOnly(data.period.from)} to {dateOnly(data.period.to)}</p>
            </div>
            <p className="muted small report-meta">Generated {dateTime(data.generatedAt)} by {data.generatedBy}<br />Enterprise SIEM Platform</p>
          </header>

          <p className="report-lede">{narrative(data, orgLabel)}</p>

          <StatRow stats={[
            { label: 'Events', value: data.totals.events },
            { label: 'Detections', value: data.totals.detections },
            { label: 'Alerts raised', value: data.totals.alerts },
            { label: 'Incidents opened', value: data.totals.incidents, tone: data.incidentsBySeverity.CRITICAL ? 'critical' : undefined },
            { label: 'Incidents resolved', value: data.totals.resolvedInPeriod },
            { label: 'False-positive alerts', value: data.totals.falsePositiveAlerts },
          ]}
          />

          <div className="grid grid-3 report-grid">
            <Panel title="Incidents by severity">
              <ul className="sevcount">
                {SEVERITIES.map((s) => <li key={s}><SeverityBadge severity={s} /><span className="sevcount-n">{data.incidentsBySeverity[s] || 0}</span></li>)}
              </ul>
            </Panel>
            <Panel title="Incidents by status">
              <BarList items={INCIDENT_STATUSES.map((s) => ({ s, n: data.incidentsByStatus[s] || 0 }))} label={(r) => sentence(r.s)} value={(r) => r.n} />
            </Panel>
            <Panel title="Analyst response">
              <dl className="kv">
                <dt>Time to first action</dt>
                <dd>{duration(data.responseTimes.acknowledgeMinutes.p50)} <span className="muted small">median, {data.responseTimes.acknowledgeMinutes.count} incidents</span></dd>
                <dt>Average</dt><dd>{duration(data.responseTimes.acknowledgeMinutes.avg)}</dd>
                <dt>Time to resolve</dt>
                <dd>{duration(data.responseTimes.resolveMinutes.p50)} <span className="muted small">median, {data.responseTimes.resolveMinutes.count} incidents</span></dd>
                <dt>Average</dt><dd>{duration(data.responseTimes.resolveMinutes.avg)}</dd>
              </dl>
              <p className="muted small report-note">First action is the first status change or assignment after an incident opens.</p>
            </Panel>
          </div>

          <div className="grid grid-2 report-grid">
            <Panel title="Incidents by attack type">
              <BarList items={Object.entries(data.incidentsByType).map(([k, n]) => ({ k, n })).sort((a, b) => b.n - a.n)} label={(r) => attackLabel(r.k)} value={(r) => r.n} emptyText="No incidents in this period" />
            </Panel>
            <Panel title="MITRE ATT&CK techniques" flush>
              <table className="table table-compact">
                <thead><tr><th>Technique</th><th>Tactic</th><th className="num">Incidents</th></tr></thead>
                <tbody>
                  {data.mitre.filter((m) => m.count).sort((a, b) => b.count - a.count).map((m) => (
                    <tr key={m.technique}><td><Mono>{m.technique}</Mono> {m.name}</td><td>{m.tactic}</td><td className="num">{m.count}</td></tr>
                  ))}
                  {!data.mitre.some((m) => m.count) && <tr><td colSpan={3} className="muted">No techniques observed in this period.</td></tr>}
                </tbody>
              </table>
            </Panel>
          </div>

          <div className="grid grid-2 report-grid">
            <Panel title="Devices" flush>
              <table className="table table-compact">
                <thead><tr><th>Device</th><th className="num">Events</th><th className="num">Detections</th></tr></thead>
                <tbody>
                  {data.devices.map((d) => <tr key={d.id}><td>{d.name} <span className="muted small">{sentence(d.type)}</span></td><td className="num">{d.events.toLocaleString()}</td><td className="num">{d.detections}</td></tr>)}
                  {!data.devices.length && <tr><td colSpan={3} className="muted">No device sent events in this period.</td></tr>}
                </tbody>
              </table>
            </Panel>
            <Panel title="Top sources" flush>
              <table className="table table-compact">
                <thead><tr><th>Source IP</th><th className="num">Events</th><th className="num">Detections</th></tr></thead>
                <tbody>
                  {data.topSources.map((s) => <tr key={s.ip}><td><Mono>{s.ip}</Mono></td><td className="num">{s.events}</td><td className="num">{s.detections}</td></tr>)}
                  {!data.topSources.length && <tr><td colSpan={3} className="muted">No source addresses recorded.</td></tr>}
                </tbody>
              </table>
            </Panel>
          </div>

          <Panel title={`Incidents opened in the period (${data.incidents.length})`} flush>
            {!data.incidents.length ? <EmptyState title="No incidents in this period" /> : (
              <div className="table-scroll">
                <table className="table table-compact">
                  <thead><tr><th>Reference</th><th>Incident</th><th>Severity</th><th>Status</th><th>Technique</th><th>Device</th><th>Opened</th><th>Resolved</th></tr></thead>
                  <tbody>
                    {data.incidents.map((i) => (
                      <tr key={i.id}>
                        <td><Link to={`${base}/incidents/${i.id}`}><Mono>{i.reference}</Mono></Link></td>
                        <td>{i.title}</td>
                        <td><SeverityBadge severity={i.severity} score={i.riskScore} /></td>
                        <td><StatusPill status={i.status} /></td>
                        <td><Mono>{i.mitreTechnique}</Mono></td>
                        <td>{i.device || '—'}</td>
                        <td className="nowrap">{dateTime(i.createdAt)}</td>
                        <td className="nowrap">{i.resolvedAt ? dateTime(i.resolvedAt) : <span className="muted">Open</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Panel>
        </article>
      )}
    </>
  );
}
