import { useState } from 'react';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { ErrorNote, Field, PageHeader, Panel } from '../../components/ui';
import { dateTime } from '../../utils/format';

export default function AccountPage() {
  const { user, isAdmin } = useAuth();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const mismatch = form.confirm && form.confirm !== form.newPassword;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null); setDone(false);
    try {
      await api('/auth/change-password', { method: 'POST', body: { currentPassword: form.currentPassword, newPassword: form.newPassword } });
      setForm({ currentPassword: '', newPassword: '', confirm: '' });
      setDone(true);
    } catch (err) { setError(err); } finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader title="Your account" />
      <div className="grid grid-2">
        <Panel title="Profile">
          <dl className="kv">
            <dt>Name</dt><dd>{user.fullName || '—'}</dd>
            <dt>Username</dt><dd>{user.username}</dd>
            <dt>Email</dt><dd>{user.email}</dd>
            <dt>Role</dt><dd><span className={`role-tag role-${isAdmin ? 'admin' : 'client'}`}>{isAdmin ? 'Administrator' : 'Client analyst'}</span></dd>
            {user.organization && <><dt>Organisation</dt><dd>{user.organization}</dd></>}
            <dt>Last sign-in</dt><dd>{dateTime(user.lastLogin)}</dd>
          </dl>
          <p className="muted small">Sessions last 8 hours. Ask an administrator to change your role or organisation.</p>
        </Panel>
        <Panel title="Change password">
          <form onSubmit={submit} className="form-grid">
            <Field label="Current password"><input type="password" autoComplete="current-password" value={form.currentPassword} onChange={(e) => setForm({ ...form, currentPassword: e.target.value })} /></Field>
            <Field label="New password" hint="At least 8 characters, with upper and lower case letters and a number.">
              <input type="password" autoComplete="new-password" value={form.newPassword} onChange={(e) => setForm({ ...form, newPassword: e.target.value })} />
            </Field>
            <Field label="Repeat new password" error={mismatch ? 'Passwords do not match' : null}>
              <input type="password" autoComplete="new-password" value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} />
            </Field>
            <ErrorNote error={error} />
            {done && <p className="ok-note" role="status">Password changed.</p>}
            <div><button type="submit" className="btn" disabled={busy || !form.currentPassword || !form.newPassword || mismatch}>{busy ? 'Saving…' : 'Change password'}</button></div>
          </form>
        </Panel>
      </div>
    </>
  );
}
