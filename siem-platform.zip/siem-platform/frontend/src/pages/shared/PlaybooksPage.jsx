import { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { ErrorNote, Loading, Mono, PageHeader } from '../../components/ui';
import { attackLabel } from '../../utils/format';

export default function PlaybooksPage() {
  const { base } = useAuth();
  const { hash } = useLocation();
  const books = useApi('/meta/playbooks');
  const mitre = useApi('/meta/mitre');

  useEffect(() => {
    if (hash && books.data) document.getElementById(hash.slice(1))?.scrollIntoView({ block: 'start' });
  }, [hash, books.data]);

  if (books.loading && !books.data) return <Loading />;
  if (books.error) return <ErrorNote error={books.error} onRetry={books.reload} />;
  const techniqueFor = Object.fromEntries((mitre.data?.data || []).map((m) => [m.attackType, m]));

  return (
    <>
      <PageHeader
        title="Response playbooks"
        intro="Step-by-step containment guides for each detection category. The matching playbook is also shown on every incident."
      />
      <div className="playbooks">
        {Object.entries(books.data.data).map(([type, pb]) => {
          const m = techniqueFor[type];
          return (
            <section key={type} id={type} className={`panel playbook ${hash === `#${type}` ? 'playbook-focus' : ''}`}>
              <div className="panel-head">
                <h2>{pb.title}</h2>
                <div className="panel-aside">{m && <span className="muted small"><Mono>{m.technique}</Mono> {m.tactic}</span>}</div>
              </div>
              <div className="panel-body">
                <ol className="steps">{pb.steps.map((s) => <li key={s}>{s}</li>)}</ol>
                <Link to={`${base}/incidents?attackType=${type}&status=all`} className="small">{attackLabel(type)} incidents</Link>
              </div>
            </section>
          );
        })}
      </div>
    </>
  );
}
