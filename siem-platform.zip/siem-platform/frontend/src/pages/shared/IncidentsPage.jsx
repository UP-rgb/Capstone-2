import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import {
  EmptyState, ErrorNote, Loading, Mono, PageHeader, Pagination, Panel, Select, SeverityBadge, StatusPill,
} from '../../components/ui';
import SearchInput from '../../components/SearchInput';
import { ATTACK_LABELS, attackLabel, dateTime, INCIDENT_STATUSES, sentence, SEVERITIES, timeAgo } from '../../utils/format';

const STATUS_FILTERS = [
  { value: 'active', label: 'Active (not resolved)' },
  ...INCIDENT_STATUSES.map((s) => ({ value: s, label: sentence(s) })),
  { value: 'all', label: 'Any status' },
];
const ATTACKS = Object.entries(ATTACK_LABELS).map(([value, label]) => ({ value, label }));

export default function IncidentsPage() {
  const { base, isAdmin } = useAuth();
  const [f, setF, reset] = useQueryState({ status: 'active' });
  const mitre = useApi('/meta/mitre');
  const query = {
    status: f.status === 'all' ? '' : f.status, severity: f.severity, attackType: f.attackType,
    technique: f.technique, q: f.q, page: f.page, limit: 25,
  };
  const { data, error, loading, reload } = useApi('/incidents', query, { live: true });
  const techniques = (mitre.data?.data || []).map((m) => ({ value: m.technique, label: `${m.technique} ${m.name}` }));

  return (
    <>
      <PageHeader
        title="Incidents"
        intro="Raised automatically when an event scores 70 or more, and tagged with the MITRE ATT&CK technique it maps to. Open one to investigate, comment and move it through its lifecycle."
      />

      <div className="filters">
        <SearchInput value={f.q} onChange={(v) => setF('q', v)} placeholder="Search reference, title or IP" />
        <Select value={f.status} onChange={(v) => setF('status', v || 'all')} options={STATUS_FILTERS} aria-label="Status" />
        <Select value={f.severity || ''} onChange={(v) => setF('severity', v)} options={SEVERITIES} placeholder="Any severity" aria-label="Severity" />
        <Select value={f.attackType || ''} onChange={(v) => setF('attackType', v)} options={ATTACKS} placeholder="Any attack type" aria-label="Attack type" />
        <Select value={f.technique || ''} onChange={(v) => setF('technique', v)} options={techniques} placeholder="Any technique" aria-label="MITRE technique" />
        <button type="button" className="btn btn-ghost btn-sm" onClick={reset}>Clear filters</button>
      </div>

      <Panel flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? (
          <EmptyState title="No incidents match these filters">
            {f.status === 'active' ? 'Nothing is open right now. Choose "Any status" to see resolved and closed incidents.' : 'Try clearing the filters.'}
          </EmptyState>
        ) : (
          <div className="table-scroll">
            <table className="table">
              <thead>
                <tr>
                  <th>Incident</th><th>Severity</th><th>Status</th><th>Technique</th><th>Device</th>
                  <th>Source</th>{isAdmin && <th>Assigned to</th>}<th className="num">Events</th><th>Last activity</th>
                </tr>
              </thead>
              <tbody>
                {data.data.map((i) => (
                  <tr key={i.id}>
                    <td>
                      <Link to={`${base}/incidents/${i.id}`} className="strong">{i.title}</Link>
                      <div className="muted small"><Mono>{i.reference}</Mono> {attackLabel(i.attackType)}</div>
                    </td>
                    <td><SeverityBadge severity={i.severity} score={i.riskScore} /></td>
                    <td><StatusPill status={i.status} /></td>
                    <td>{i.mitreTechnique ? <span title={`${i.mitreTactic}: ${i.mitreName}`}><Mono>{i.mitreTechnique}</Mono></span> : '—'}</td>
                    <td>{i.device?.name || '—'}</td>
                    <td><Mono>{i.sourceIP}</Mono></td>
                    {isAdmin && <td>{i.assignee?.username || <span className="muted">Unassigned</span>}</td>}
                    <td className="num">{i.eventCount}</td>
                    <td className="nowrap" title={dateTime(i.lastSeen)}>{timeAgo(i.lastSeen)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      {data && <Pagination pagination={data.pagination} onPage={(p) => setF('page', p)} />}
    </>
  );
}
