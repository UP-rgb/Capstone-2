import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import {
  EmptyState, ErrorNote, Loading, Modal, Mono, PageHeader, Pagination, Panel, Select, SeverityBadge,
} from '../../components/ui';
import SearchInput from '../../components/SearchInput';
import { attackLabel, dateTime, SEVERITIES } from '../../utils/format';

function EventDetail({ id, base, onClose }) {
  const { data, error, loading } = useApi(`/events/${id}`);
  const ev = data?.data;
  return (
    <Modal title="Event detail" onClose={onClose} wide>
      {loading ? <Loading /> : error ? <ErrorNote error={error} /> : (
        <>
          <dl className="kv kv-wide">
            <dt>Time</dt><dd>{dateTime(ev.timestamp)}</dd>
            <dt>Device</dt><dd>{ev.device?.name} <Mono>{ev.device?.ipAddress}</Mono></dd>
            <dt>Event type</dt><dd><Mono>{ev.eventType}</Mono></dd>
            <dt>Severity</dt><dd><SeverityBadge severity={ev.severity} score={ev.riskScore} /></dd>
            <dt>Detection</dt><dd>{ev.attackType ? attackLabel(ev.attackType) : <span className="muted">None</span>}</dd>
            <dt>Source</dt><dd><Mono>{ev.sourceIP}</Mono></dd>
            <dt>Destination</dt><dd><Mono>{ev.destinationIP ? `${ev.destinationIP}${ev.destinationPort ? `:${ev.destinationPort}` : ''}` : null}</Mono></dd>
            <dt>User</dt><dd>{ev.username || '—'}</dd>
            <dt>Message</dt><dd className="break">{ev.message || '—'}</dd>
            {ev.incident && <><dt>Incident</dt><dd><Link to={`${base}/incidents/${ev.incident.id}`} onClick={onClose}>{ev.incident.reference} {ev.incident.title}</Link></dd></>}
            {ev.iocMatches?.length > 0 && (
              <><dt>IOC matches</dt><dd>{ev.iocMatches.map((m) => <div key={m.id}><Mono>{m.matchedValue}</Mono> <span className="muted small">in {m.matchedField}, {m.ioc?.source}</span></div>)}</dd></>
            )}
          </dl>
          <h3 className="sub-head">Raw payload</h3>
          <pre className="pre">{JSON.stringify(ev.raw, null, 2)}</pre>
        </>
      )}
    </Modal>
  );
}

export default function EventsPage() {
  const { base, isAdmin } = useAuth();
  const [f, setF, reset] = useQueryState({});
  const devices = useApi('/devices');
  const [openId, setOpenId] = useState(null);
  const query = {
    q: f.q, eventType: f.eventType, severity: f.severity, sourceIP: f.sourceIP, deviceId: f.deviceId,
    from: f.from ? new Date(f.from).toISOString() : '', to: f.to ? new Date(f.to).toISOString() : '',
    detectedOnly: f.detectedOnly, page: f.page, limit: 50,
  };
  const { data, error, loading, reload } = useApi('/events', query);

  return (
    <>
      <PageHeader
        title="Event search"
        intro={isAdmin ? 'Every security event stored by the platform, newest first.' : 'Every event your devices have sent, newest first.'}
        actions={<button type="button" className="btn btn-ghost" onClick={reload}>Refresh</button>}
      />

      <div className="filters">
        <SearchInput value={f.q} onChange={(v) => setF('q', v)} placeholder="Search message, user, type or IP" />
        <SearchInput value={f.sourceIP} onChange={(v) => setF('sourceIP', v)} placeholder="Exact source IP" label="Source IP" />
        <Select value={f.deviceId || ''} onChange={(v) => setF('deviceId', v)} options={(devices.data?.data || []).map((d) => ({ value: d.id, label: d.name }))} placeholder="Any device" aria-label="Device" />
        <Select value={f.severity || ''} onChange={(v) => setF('severity', v)} options={SEVERITIES} placeholder="Any severity" aria-label="Severity" />
        <label className="filter-date">From <input type="datetime-local" value={f.from || ''} onChange={(e) => setF('from', e.target.value)} /></label>
        <label className="filter-date">To <input type="datetime-local" value={f.to || ''} onChange={(e) => setF('to', e.target.value)} /></label>
        <label className="check"><input type="checkbox" checked={f.detectedOnly === 'true'} onChange={(e) => setF('detectedOnly', e.target.checked ? 'true' : '')} /> Detections only</label>
        <button type="button" className="btn btn-ghost btn-sm" onClick={reset}>Clear filters</button>
      </div>

      <Panel flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? (
          <EmptyState title="No events match">Widen the time range or clear the filters. Devices send events to POST /api/ingest with their API key.</EmptyState>
        ) : (
          <div className="table-scroll">
            <table className="table table-compact table-hover">
              <thead>
                <tr><th>Time</th><th>Device</th><th>Event</th><th>Source</th><th>Destination</th><th>User</th><th>Severity</th><th>Detection</th></tr>
              </thead>
              <tbody>
                {data.data.map((ev) => (
                  <tr key={ev.id} className={ev.attackType ? 'row-detected' : undefined} onClick={() => setOpenId(ev.id)}>
                    <td className="nowrap">{dateTime(ev.timestamp)}</td>
                    <td className="nowrap">{ev.device?.name}</td>
                    <td>
                      <button type="button" className="link-btn" onClick={(e) => { e.stopPropagation(); setOpenId(ev.id); }}><Mono>{ev.eventType}</Mono></button>
                      {ev.message && <div className="muted small clamp">{ev.message}</div>}
                    </td>
                    <td><Mono>{ev.sourceIP}</Mono></td>
                    <td><Mono>{ev.destinationIP ? `${ev.destinationIP}${ev.destinationPort ? `:${ev.destinationPort}` : ''}` : null}</Mono></td>
                    <td>{ev.username || '—'}</td>
                    <td><SeverityBadge severity={ev.severity} /></td>
                    <td>{ev.attackType ? attackLabel(ev.attackType) : <span className="muted">—</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      {data && <Pagination pagination={data.pagination} onPage={(p) => setF('page', p)} />}
      {openId && <EventDetail id={openId} base={base} onClose={() => setOpenId(null)} />}
    </>
  );
}
