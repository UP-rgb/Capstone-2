import { useState } from 'react';
import { api } from '../../api/client';
import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import {
  EmptyState, ErrorNote, Field, Loading, Modal, Mono, PageHeader, Pagination, Panel, Select, SeverityBadge,
} from '../../components/ui';
import SearchInput from '../../components/SearchInput';
import { ATTACK_LABELS, attackLabel, IOC_TYPE_LABELS, IOC_TYPES, iocTypeLabel, sentence, SEVERITIES, timeAgo } from '../../utils/format';

const ATTACKS = Object.entries(ATTACK_LABELS).map(([value, label]) => ({ value, label }));
const CONFIDENCE = ['HIGH', 'MEDIUM', 'LOW'];
const EMPTY = { type: 'IP', value: '', severity: 'HIGH', confidence: 'MEDIUM', attackType: 'ioc_reputation', source: 'manual', description: '' };

// Mirrors the server-side checks so the bulk importer can detect the type of each line.
const guessType = (v) => {
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(v) || /^[0-9a-f:]+:[0-9a-f:]*$/i.test(v)) return 'IP';
  if (/^([a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$/i.test(v)) return 'HASH';
  if (/^https?:\/\//i.test(v)) return 'URL';
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return 'EMAIL';
  if (/^([a-z0-9-]{1,63}\.)+[a-z]{2,63}$/i.test(v)) return 'DOMAIN';
  return null;
};

function IocForm({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (v) => setForm({ ...form, [k]: v?.target ? v.target.value : v });
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try { await api('/ioc', { method: 'POST', body: form }); onSaved(); } catch (err) { setError(err); setBusy(false); }
  };
  return (
    <Modal title="Add an indicator" onClose={onClose} footer={(
      <>
        <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button type="submit" form="ioc-form" className="btn" disabled={busy || !form.value.trim()}>{busy ? 'Saving…' : 'Add indicator'}</button>
      </>
    )}
    >
      <form id="ioc-form" className="form-grid form-2" onSubmit={submit}>
        <Field label="Value" hint="IP, domain, URL, email address or MD5/SHA-1/SHA-256 hash.">
          <input value={form.value} className="mono-input" onChange={(e) => { const v = e.target.value; setForm({ ...form, value: v, type: guessType(v.trim()) || form.type }); }} required />
        </Field>
        <Field label="Type"><Select value={form.type} onChange={set('type')} options={IOC_TYPES.map((t) => ({ value: t, label: IOC_TYPE_LABELS[t] }))} /></Field>
        <Field label="Severity if seen"><Select value={form.severity} onChange={set('severity')} options={SEVERITIES} /></Field>
        <Field label="Confidence"><Select value={form.confidence} onChange={set('confidence')} options={CONFIDENCE} /></Field>
        <Field label="Attack type" hint="Decides the MITRE technique of any incident it causes."><Select value={form.attackType} onChange={set('attackType')} options={ATTACKS} /></Field>
        <Field label="Source"><input value={form.source} onChange={set('source')} placeholder="manual, AbuseIPDB, vendor report" /></Field>
        <Field label="Description"><textarea rows={3} value={form.description} onChange={set('description')} /></Field>
        <div className="span-2"><ErrorNote error={error} /></div>
      </form>
    </Modal>
  );
}

function BulkImport({ onClose, onDone }) {
  const [text, setText] = useState('');
  const [defaults, setDefaults] = useState({ severity: 'HIGH', confidence: 'MEDIUM', attackType: 'ioc_reputation', source: 'bulk import' });
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const lines = text.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
  const items = lines.map((l) => {
    const [a, b] = l.split(',').map((s) => s.trim());
    if (b && IOC_TYPES.includes(a.toUpperCase())) return { type: a.toUpperCase(), value: b, ...defaults };
    return { type: guessType(a), value: a, ...defaults };
  });
  const unknown = items.filter((i) => !i.type).length;

  const submit = async () => {
    setBusy(true); setError(null);
    try {
      const r = await api('/ioc/bulk', { method: 'POST', body: { items: items.map((i) => ({ ...i, type: i.type || 'DOMAIN' })) } });
      setResult(r);
      onDone();
    } catch (err) { setError(err); } finally { setBusy(false); }
  };

  return (
    <Modal title="Import indicators" onClose={onClose} wide footer={result ? <button type="button" className="btn" onClick={onClose}>Done</button> : (
      <>
        <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button type="button" className="btn" onClick={submit} disabled={busy || !items.length}>{busy ? 'Importing…' : `Import ${items.length} indicator${items.length === 1 ? '' : 's'}`}</button>
      </>
    )}
    >
      {result ? (
        <>
          <p className="ok-note">{result.created} added, {result.skipped.length} skipped.</p>
          {result.skipped.length > 0 && (
            <ul className="small skip-list">{result.skipped.map((s) => <li key={s.row}>Line {s.row}: {s.reason}</li>)}</ul>
          )}
        </>
      ) : (
        <div className="form-grid">
          <Field label="One indicator per line" hint="The type is detected automatically, or write it first: hash,44d88612fea8a8f36de82e1278abb02f. Lines starting with # are ignored.">
            <textarea rows={9} className="mono-input" value={text} onChange={(e) => setText(e.target.value)} placeholder={'203.0.113.99\nbad-login-portal.example\nhttps://bad-login-portal.example/verify'} />
          </Field>
          <div className="form-2 form-grid">
            <Field label="Severity"><Select value={defaults.severity} onChange={(v) => setDefaults({ ...defaults, severity: v })} options={SEVERITIES} /></Field>
            <Field label="Confidence"><Select value={defaults.confidence} onChange={(v) => setDefaults({ ...defaults, confidence: v })} options={CONFIDENCE} /></Field>
            <Field label="Attack type"><Select value={defaults.attackType} onChange={(v) => setDefaults({ ...defaults, attackType: v })} options={ATTACKS} /></Field>
            <Field label="Source"><input value={defaults.source} onChange={(e) => setDefaults({ ...defaults, source: e.target.value })} /></Field>
          </div>
          {unknown > 0 && <p className="warn-note">{unknown} line{unknown > 1 ? 's' : ''} could not be recognised and will probably be skipped.</p>}
          <ErrorNote error={error} />
        </div>
      )}
    </Modal>
  );
}

export default function IocPage() {
  const [f, setF] = useQueryState({});
  const { data, error, loading, reload, setData } = useApi('/ioc', { type: f.type, q: f.q, active: f.active, page: f.page, limit: 50 });
  const [modal, setModal] = useState(null);
  const [rowError, setRowError] = useState(null);

  const toggle = async (ioc) => {
    setRowError(null);
    try {
      const r = await api(`/ioc/${ioc.id}`, { method: 'PUT', body: { isActive: !ioc.isActive } });
      setData((d) => ({ ...d, data: d.data.map((x) => (x.id === ioc.id ? r.data : x)) }));
    } catch (e) { setRowError(e); }
  };
  const remove = async (ioc) => {
    if (!window.confirm(`Delete ${ioc.value}? Past matches are removed too.`)) return;
    try { await api(`/ioc/${ioc.id}`, { method: 'DELETE' }); reload(); } catch (e) { setRowError(e); }
  };

  return (
    <>
      <PageHeader
        title="IOC database"
        intro="Indicators of compromise checked against every incoming event: source and destination IPs, domains, URLs, sender addresses and file hashes. A match adds to the event's risk score."
        actions={(
          <>
            <button type="button" className="btn btn-ghost" onClick={() => setModal('bulk')}>Import a list</button>
            <button type="button" className="btn" onClick={() => setModal('add')}>Add an indicator</button>
          </>
        )}
      />
      <div className="filters">
        <SearchInput value={f.q} onChange={(v) => setF('q', v)} placeholder="Search values" />
        <Select value={f.type || ''} onChange={(v) => setF('type', v)} options={IOC_TYPES.map((t) => ({ value: t, label: IOC_TYPE_LABELS[t] }))} placeholder="Any type" aria-label="Type" />
        <label className="check"><input type="checkbox" checked={f.active === 'true'} onChange={(e) => setF('active', e.target.checked ? 'true' : '')} /> Active only</label>
      </div>
      <ErrorNote error={rowError} />
      <Panel flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? (
          <EmptyState title="No indicators yet">Add known-bad IPs, domains and hashes, or import a list from a threat feed.</EmptyState>
        ) : (
          <div className="table-scroll">
            <table className="table">
              <thead><tr><th>Indicator</th><th>Type</th><th>Severity</th><th>Confidence</th><th>Attack type</th><th>Source</th><th className="num">Hits</th><th>Last hit</th><th>Active</th><th><span className="sr-only">Actions</span></th></tr></thead>
              <tbody>
                {data.data.map((i) => (
                  <tr key={i.id} className={i.isActive ? undefined : 'row-muted'}>
                    <td><Mono>{i.value}</Mono>{i.description && <div className="muted small clamp">{i.description}</div>}</td>
                    <td className="nowrap">{iocTypeLabel(i.type)}</td>
                    <td><SeverityBadge severity={i.severity} /></td>
                    <td>{sentence(i.confidence)}</td>
                    <td>{attackLabel(i.attackType)}</td>
                    <td>{i.source}</td>
                    <td className="num">{i.hitCount}</td>
                    <td className="nowrap">{i.lastSeen ? timeAgo(i.lastSeen) : <span className="muted">Never</span>}</td>
                    <td>
                      <label className="switch">
                        <input type="checkbox" checked={i.isActive} onChange={() => toggle(i)} />
                        <span className="sr-only">Active</span>
                        <span aria-hidden="true" className="switch-track" />
                      </label>
                    </td>
                    <td className="row-actions"><button type="button" className="btn btn-ghost btn-sm btn-danger" onClick={() => remove(i)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      {data && <Pagination pagination={data.pagination} onPage={(p) => setF('page', p)} />}
      {modal === 'add' && <IocForm onClose={() => setModal(null)} onSaved={() => { setModal(null); reload(); }} />}
      {modal === 'bulk' && <BulkImport onClose={() => setModal(null)} onDone={reload} />}
    </>
  );
}
