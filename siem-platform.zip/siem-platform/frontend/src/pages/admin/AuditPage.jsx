import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import { EmptyState, ErrorNote, Loading, Mono, PageHeader, Pagination, Panel, Select } from '../../components/ui';
import SearchInput from '../../components/SearchInput';
import { dateTime } from '../../utils/format';

const AREAS = [
  { value: 'auth', label: 'Sign-in and passwords' },
  { value: 'incident', label: 'Incidents' },
  { value: 'alert', label: 'Alerts' },
  { value: 'device', label: 'Devices and keys' },
  { value: 'user', label: 'Users' },
  { value: 'ioc', label: 'IOC database' },
  { value: 'threat_intel', label: 'Threat-intel lookups' },
  { value: 'report', label: 'Report exports' },
];

const describe = (d) => {
  if (!d || !Object.keys(d).length) return '—';
  if (d.message) return d.message;
  return Object.entries(d).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(', ') : typeof v === 'object' ? JSON.stringify(v) : v}`).join('; ');
};

export default function AuditPage() {
  const [f, setF] = useQueryState({});
  const { data, error, loading, reload } = useApi('/audit', { action: f.action, q: f.q, page: f.page, limit: 50 });
  return (
    <>
      <PageHeader title="Audit log" intro="Who did what, and from where. Every sign-in, failed sign-in and change to devices, users, IOCs, alerts and incidents is recorded." />
      <div className="filters">
        <SearchInput value={f.q} onChange={(v) => setF('q', v)} placeholder="Search user or action" />
        <Select value={f.action || ''} onChange={(v) => setF('action', v)} options={AREAS} placeholder="Every area" aria-label="Area" />
      </div>
      <Panel flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? <EmptyState title="No entries match" /> : (
          <div className="table-scroll">
            <table className="table table-compact">
              <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Details</th><th>From</th></tr></thead>
              <tbody>
                {data.data.map((a) => (
                  <tr key={a.id} className={a.action === 'auth.login_failed' ? 'row-detected' : undefined}>
                    <td className="nowrap">{dateTime(a.createdAt)}</td>
                    <td>{a.username || <span className="muted">unknown</span>}</td>
                    <td><Mono>{a.action}</Mono></td>
                    <td className="clamp-cell">{describe(a.details)}</td>
                    <td><Mono>{a.ip}</Mono></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      {data && <Pagination pagination={data.pagination} onPage={(p) => setF('page', p)} />}
    </>
  );
}
