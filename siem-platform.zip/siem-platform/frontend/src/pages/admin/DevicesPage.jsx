import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import {
  EmptyState, ErrorNote, Field, HealthDot, Loading, Modal, Mono, PageHeader, Panel, Select, StatusPill,
} from '../../components/ui';
import { DEVICE_TYPES, sentence, timeAgo } from '../../utils/format';

const EMPTY = { name: '', hostname: '', type: 'WINDOWS', ipAddress: '', location: '', ownerId: '', status: 'ACTIVE' };

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* clipboard blocked */ }
  };
  return <button type="button" className="btn btn-ghost btn-sm" onClick={copy}>{copied ? 'Copied' : 'Copy'}</button>;
}

// FR1/FR2: the plaintext key exists only in this response; the server stores a hash.
function KeyReveal({ result, onClose }) {
  const origin = window.location.origin.replace(':5173', ':5000');
  const curl = `curl -X POST ${origin}/api/ingest \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ${result.apiKey}" \\
  -d '{"eventType":"failed_login","sourceIP":"192.168.1.50","username":"victim","message":"Test event from ${result.data.name}"}'`;
  return (
    <Modal title={`API key for ${result.data.name}`} onClose={onClose} wide footer={<button type="button" className="btn" onClick={onClose}>I have stored the key</button>}>
      <p className="warn-note">Copy this key now. The platform keeps only a hash, so it cannot be shown again. {result.notice}</p>
      <div className="key-box">
        <code className="mono">{result.apiKey}</code>
        <CopyButton text={result.apiKey} />
      </div>
      <h3 className="sub-head">Send a test event</h3>
      <p className="muted small">The device authenticates with the <Mono>x-api-key</Mono> header. Run this from any machine that can reach the SIEM.</p>
      <div className="key-box key-box-block">
        <pre className="pre">{curl}</pre>
        <CopyButton text={curl} />
      </div>
    </Modal>
  );
}

function DeviceForm({ device, owners, onClose, onSaved }) {
  const editing = Boolean(device);
  const [form, setForm] = useState(editing ? { ...EMPTY, ...device, hostname: device.hostname || '', ipAddress: device.ipAddress || '', location: device.location || '', ownerId: device.ownerId || '' } : EMPTY);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target ? e.target.value : e });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    const body = {
      name: form.name, hostname: form.hostname, type: form.type, ipAddress: form.ipAddress,
      location: form.location, ownerId: form.ownerId || null, ...(editing ? { status: form.status } : {}),
    };
    try {
      const r = editing
        ? await api(`/devices/${device.id}`, { method: 'PUT', body })
        : await api('/devices', { method: 'POST', body });
      onSaved(r, editing);
    } catch (err) { setError(err); setBusy(false); }
  };

  return (
    <Modal
      title={editing ? `Edit ${device.name}` : 'Register a device'}
      onClose={onClose}
      footer={(
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button type="submit" form="device-form" className="btn" disabled={busy || !form.name}>{busy ? 'Saving…' : editing ? 'Save changes' : 'Register and create key'}</button>
        </>
      )}
    >
      <form id="device-form" className="form-grid form-2" onSubmit={submit}>
        <Field label="Name"><input value={form.name} onChange={set('name')} placeholder="pfSense-Firewall" maxLength={100} required /></Field>
        <Field label="Type"><Select value={form.type} onChange={set('type')} options={DEVICE_TYPES} /></Field>
        <Field label="Hostname"><input value={form.hostname} onChange={set('hostname')} placeholder="fw01.lab.local" /></Field>
        <Field label="IP address"><input value={form.ipAddress} onChange={set('ipAddress')} placeholder="192.168.1.1" className="mono-input" /></Field>
        <Field label="Location"><input value={form.location} onChange={set('location')} placeholder="SOC lab, rack 1" /></Field>
        <Field label="Client owner" hint="The client who sees this device's events, alerts and incidents.">
          <Select value={form.ownerId} onChange={set('ownerId')} options={owners.map((u) => ({ value: u.id, label: `${u.username}${u.organization ? ` (${u.organization})` : ''}` }))} placeholder="None, administrators only" />
        </Field>
        {editing && <Field label="Status" hint="Disabled devices are refused at /api/ingest."><Select value={form.status} onChange={set('status')} options={['ACTIVE', 'INACTIVE', 'DISABLED']} /></Field>}
        <div className="span-2"><ErrorNote error={error} /></div>
      </form>
    </Modal>
  );
}

export default function DevicesPage() {
  const { base } = useAuth();
  const { data, error, loading, reload } = useApi('/devices', null, { live: true });
  const users = useApi('/users');
  const [editing, setEditing] = useState(undefined); // undefined closed, null new, object edit
  const [keyResult, setKeyResult] = useState(null);
  const [confirm, setConfirm] = useState(null); // { kind: 'delete'|'key', device }
  const [actionError, setActionError] = useState(null);

  const owners = (users.data?.data || []).filter((u) => u.role === 'CLIENT');

  const onSaved = (r, wasEdit) => {
    setEditing(undefined);
    if (!wasEdit) setKeyResult(r);
    reload();
  };

  const runConfirm = async () => {
    const { kind, device } = confirm;
    setActionError(null);
    try {
      if (kind === 'delete') await api(`/devices/${device.id}`, { method: 'DELETE' });
      else setKeyResult(await api(`/devices/${device.id}/regenerate-key`, { method: 'POST' }));
      setConfirm(null);
      reload();
    } catch (e) { setActionError(e); }
  };

  return (
    <>
      <PageHeader
        title="Devices and API keys"
        intro="Each monitored device gets its own API key and sends events to POST /api/ingest. Assign a device to a client to show its activity on that client's dashboard."
        actions={<button type="button" className="btn" onClick={() => setEditing(null)}>Register a device</button>}
      />

      <Panel flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? (
          <EmptyState title="No devices registered">Register your firewall, servers and endpoints to start collecting events.</EmptyState>
        ) : (
          <div className="table-scroll">
            <table className="table">
              <thead>
                <tr><th>Device</th><th>Address</th><th>Client owner</th><th>Status</th><th>Heartbeat</th><th className="num">Events</th><th>Key</th><th><span className="sr-only">Actions</span></th></tr>
              </thead>
              <tbody>
                {data.data.map((d) => (
                  <tr key={d.id}>
                    <td>
                      <Link to={`${base}/events?deviceId=${d.id}`} className="strong">{d.name}</Link>
                      <div className="muted small">{sentence(d.type)}{d.hostname ? `, ${d.hostname}` : ''}{d.location ? `, ${d.location}` : ''}</div>
                    </td>
                    <td><Mono>{d.ipAddress}</Mono></td>
                    <td>{d.owner ? <>{d.owner.username}<div className="muted small">{d.owner.organization}</div></> : <span className="muted">Administrators only</span>}</td>
                    <td><StatusPill status={d.status} /></td>
                    <td><HealthDot health={d.health} /><div className="muted small">{d.lastHeartbeat ? timeAgo(d.lastHeartbeat) : 'never'}</div></td>
                    <td className="num">{Number(d.eventCount).toLocaleString()}</td>
                    <td><Mono title="First characters of the key, for identification">{d.apiKeyPrefix ? `${d.apiKeyPrefix}…` : null}</Mono></td>
                    <td className="row-actions">
                      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing(d)}>Edit</button>
                      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirm({ kind: 'key', device: d })}>New key</button>
                      <button type="button" className="btn btn-ghost btn-sm btn-danger" onClick={() => setConfirm({ kind: 'delete', device: d })}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      <p className="muted small legend-note">A device that has not sent an event or heartbeat for 15 minutes shows as not reporting, and is marked inactive until it reports again.</p>

      {editing !== undefined && <DeviceForm device={editing} owners={owners} onClose={() => setEditing(undefined)} onSaved={onSaved} />}
      {keyResult && <KeyReveal result={keyResult} onClose={() => setKeyResult(null)} />}
      {confirm && (
        <Modal
          title={confirm.kind === 'delete' ? `Delete ${confirm.device.name}?` : `Replace the key for ${confirm.device.name}?`}
          onClose={() => { setConfirm(null); setActionError(null); }}
          footer={(
            <>
              <button type="button" className="btn btn-ghost" onClick={() => { setConfirm(null); setActionError(null); }}>Cancel</button>
              <button type="button" className={`btn ${confirm.kind === 'delete' ? 'btn-danger-solid' : ''}`} onClick={runConfirm}>
                {confirm.kind === 'delete' ? 'Delete device' : 'Create new key'}
              </button>
            </>
          )}
        >
          <p>
            {confirm.kind === 'delete'
              ? 'The device will no longer be able to send events. Its raw events are deleted with it. Alerts and incidents it raised are kept for the record and stay visible to administrators.'
              : 'The current key stops working immediately. Update the collector on the device with the new key.'}
          </p>
          <ErrorNote error={actionError} />
        </Modal>
      )}
    </>
  );
}
