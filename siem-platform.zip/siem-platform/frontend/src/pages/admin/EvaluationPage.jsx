import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import { EmptyState, ErrorNote, Loading, Mono, PageHeader, Panel } from '../../components/ui';
import StatRow from '../../components/StatRow';
import { attackLabel, dateTime, ms, pct } from '../../utils/format';

function RateBar({ value }) {
  if (value === null || value === undefined) return <span className="muted">—</span>;
  const tone = value >= 0.9 ? 'good' : value >= 0.6 ? 'fair' : 'poor';
  return (
    <span className="ratebar">
      <span className="ratebar-track"><span className={`ratebar-fill ratebar-${tone}`} style={{ width: `${Math.round(value * 100)}%` }} /></span>
      <span className="num">{pct(value, 0)}</span>
    </span>
  );
}

const HOW_TO = `cd backend
# one labelled run: benign traffic, all eight attack scenarios, benign again
npm run simulate -- --scenario all

# five independent runs for steadier figures
npm run simulate -- --scenario all --repeat 5

# against the lab server
npm run simulate -- --scenario all --url http://192.168.1.10:5000`;

// Detection rate, false-positive rate and alert latency (report Sections 1.2, 4.3, 4.5, 5.3).
export default function EvaluationPage() {
  const [f, setF] = useQueryState({});
  const { data, error, loading, reload } = useApi('/evaluation', { runId: f.runId });

  if (loading && !data) return <Loading label="Calculating metrics" />;
  if (error && !data) return <ErrorNote error={error} onRetry={reload} />;

  const d = data.detection;
  const lat = data.alertLatencyMs;
  const p = data.pipeline;
  const hasRuns = data.runs.length > 0;

  return (
    <>
      <PageHeader
        title="Detection evaluation"
        intro="Measures how well the detection rules perform against labelled traffic from the attack simulator. Each simulated event carries the attack type it should produce, or none for benign activity, so detections can be scored automatically."
        actions={<button type="button" className="btn btn-ghost" onClick={reload}>Recalculate</button>}
      />

      <div className="filters">
        <label className="filter-date">Run
          <select value={f.runId || ''} onChange={(e) => setF('runId', e.target.value)}>
            <option value="">All labelled runs, last 30 days</option>
            {data.runs.map((r) => <option key={r.runId} value={r.runId}>{r.runId} ({dateTime(r.startedAt)})</option>)}
          </select>
        </label>
      </div>

      {!hasRuns && (
        <Panel title="No labelled runs yet">
          <p>Run the simulator from the backend folder. It sends realistic attack and benign events through <Mono>POST /api/ingest</Mono> with each device&apos;s API key, exactly like a real collector, and labels every event with the expected result.</p>
          <pre className="pre">{HOW_TO}</pre>
        </Panel>
      )}

      <StatRow stats={[
        { label: 'Detection rate', display: pct(d.detectionRate), note: `${d.detectedRuns} of ${d.attackRuns} attack scenarios detected` },
        { label: 'False-positive rate', display: pct(d.falsePositiveRate), note: `${d.falsePositives} of ${d.benignEvents} benign events flagged`, tone: d.falsePositives ? 'high' : undefined },
        { label: 'Alerts marked false positive', value: data.analystFalsePositives.falsePositives, note: `${pct(data.analystFalsePositives.rate)} of ${data.analystFalsePositives.alerts} alerts, set by analysts` },
        { label: 'Alert latency, p95', display: ms(lat.p95), note: lat.count ? `Median ${ms(lat.p50)}, from ${lat.count} alerts` : 'No alerts yet' },
      ]}
      />
      <p className="muted small legend-note">Detection rate counts each simulated attack once, however many events it took. Alert latency is the time from an event reaching <Mono>/api/ingest</Mono> to its alert being stored and pushed to dashboards.</p>

      <div className="grid grid-2-1">
        <Panel title="By detection category" flush>
          {!d.byCategory.length ? <div className="panel-pad"><p className="muted">No labelled attack scenarios in this selection.</p></div> : (
            <div className="table-scroll">
              <table className="table">
                <thead><tr><th>Category</th><th className="num">Runs</th><th className="num">Detected</th><th className="num">Missed</th><th>Detection rate</th></tr></thead>
                <tbody>
                  {d.byCategory.map((c) => (
                    <tr key={c.attackType}>
                      <td>{attackLabel(c.attackType)}</td>
                      <td className="num">{c.runs}</td>
                      <td className="num">{c.detected}</td>
                      <td className="num">{c.missed ? <span className="tone-high">{c.missed}</span> : 0}{c.misclassified ? <span className="muted small"> ({c.misclassified} misclassified)</span> : ''}</td>
                      <td><RateBar value={c.detectionRate} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
        <div className="stack">
          <Panel title="Misses and false positives">
            {!d.missed.length && !d.falsePositives ? <p className="muted">{hasRuns ? 'Every attack scenario was detected and no benign event was flagged.' : 'Nothing to report yet.'}</p> : (
              <>
                {d.missed.length > 0 && (
                  <>
                    <p className="strong">Missed scenarios</p>
                    <ul className="plain-list">
                      {d.missed.slice(0, 12).map((m) => (
                        <li key={`${m.runId}${m.scenario}`}>{attackLabel(m.expected)} <span className="muted small">{m.scenario}{m.misclassifiedAs.length ? `, classified as ${m.misclassifiedAs.map(attackLabel).join(', ')}` : ''}</span></li>
                      ))}
                    </ul>
                  </>
                )}
                {d.falsePositives > 0 && (
                  <>
                    <p className="strong">Benign events flagged as</p>
                    <ul className="plain-list">
                      {Object.entries(d.falsePositivesByType).map(([t, n]) => <li key={t}>{attackLabel(t)} <span className="muted small">{n} event{n === 1 ? '' : 's'}</span></li>)}
                    </ul>
                  </>
                )}
              </>
            )}
          </Panel>
          <Panel title="Pipeline performance">
            <dl className="kv">
              <dt>Events processed</dt><dd>{p.eventsProcessed.toLocaleString()} <span className="muted small">since {dateTime(p.since)}</span></dd>
              <dt>Last minute</dt><dd>{p.eventsLastMinute} events</dd>
              <dt>Processing time</dt><dd>{ms(p.processingMs.p50)} median, {ms(p.processingMs.p95)} p95</dd>
              <dt>For detections</dt><dd>{ms(p.detectedProcessingMs.p50)} median, {ms(p.detectedProcessingMs.p95)} p95</dd>
              <dt>Slowest</dt><dd>{ms(p.processingMs.max)}</dd>
            </dl>
            <p className="muted small report-note">Measured inside the server for each event, from receipt to the end of detection, scoring and alerting. Resets when the server restarts.</p>
          </Panel>
        </div>
      </div>

      {hasRuns && (
        <Panel title="Labelled runs" flush>
          <div className="table-scroll">
            <table className="table table-compact table-hover">
              <thead><tr><th>Run</th><th>Started</th><th>Finished</th><th className="num">Scenarios</th><th className="num">Events</th><th className="num">Benign events</th></tr></thead>
              <tbody>
                {data.runs.map((r) => (
                  <tr key={r.runId} onClick={() => setF('runId', r.runId)} className={f.runId === r.runId ? 'row-selected' : undefined}>
                    <td><button type="button" className="link-btn" onClick={(e) => { e.stopPropagation(); setF('runId', r.runId); }}><Mono>{r.runId}</Mono></button></td>
                    <td className="nowrap">{dateTime(r.startedAt)}</td>
                    <td className="nowrap">{dateTime(r.endedAt)}</td>
                    <td className="num">{r.scenarios}</td>
                    <td className="num">{r.events}</td>
                    <td className="num">{r.benignEvents}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      )}

      <div className="grid grid-2">
        <Panel title="Thresholds in use">
          <dl className="kv">
            <dt>Alert at risk score</dt><dd>{data.thresholds.alertThreshold}</dd>
            <dt>Incident at risk score</dt><dd>{data.thresholds.incidentThreshold}</dd>
            <dt>Brute force</dt><dd>{data.thresholds.bruteForceThreshold} failures in {data.thresholds.bruteForceWindow} s</dd>
            <dt>Port scan</dt><dd>{data.thresholds.portScanThreshold} ports in {data.thresholds.portScanWindow} s</dd>
            <dt>Denial of service</dt><dd>{data.thresholds.ddosThreshold} events in {data.thresholds.ddosWindow} s, or {data.thresholds.ddosPpsThreshold.toLocaleString()} packets/s</dd>
            <dt>Exfiltration</dt><dd>{Math.round(data.thresholds.exfilBytes / 1048576)} MB outbound</dd>
            <dt>Deduplication window</dt><dd>{data.thresholds.dedupMinutes} min</dd>
          </dl>
          <p className="muted small report-note">Change these in <Mono>backend/.env</Mono> and restart the server, then run the simulator again to compare.</p>
        </Panel>
        {hasRuns ? (
          <Panel title="Run another evaluation"><pre className="pre">{HOW_TO}</pre></Panel>
        ) : <EmptyState title="Metrics appear after the first run" />}
      </div>
    </>
  );
}
