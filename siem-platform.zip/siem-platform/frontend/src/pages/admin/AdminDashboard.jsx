import { Link } from 'react-router-dom';
import { useApi } from '../../utils/useApi';
import { useAuth } from '../../context/AuthContext';
import { ErrorNote, Loading, Mono, PageHeader, Panel, SeverityBadge } from '../../components/ui';
import StatRow from '../../components/StatRow';
import SeverityStrip from '../../components/SeverityStrip';
import AlertList from '../../components/AlertList';
import BarList from '../../components/BarList';
import MitreMatrix from '../../components/MitreMatrix';
import DeviceHealthList from '../../components/DeviceHealthList';
import { attackLabel, SEVERITIES } from '../../utils/format';

export default function AdminDashboard() {
  const { base } = useAuth();
  const { data, error, loading, reload } = useApi('/dashboard/stats', null, { live: true });

  if (loading && !data) return <Loading label="Loading overview" />;
  if (error && !data) return <ErrorNote error={error} onRetry={reload} />;

  const { totals, platform } = data;
  const unhealthy = data.devices.filter((d) => d.health !== 'online').length;

  return (
    <>
      <PageHeader
        title="Security overview"
        intro="Every tenant and monitored device. Figures cover the last 24 hours unless stated."
        actions={(
          <>
            <Link to={`${base}/devices`} className="btn btn-ghost">Register a device</Link>
            <Link to={`${base}/threat-intel`} className="btn">Look up an indicator</Link>
          </>
        )}
      />

      <StatRow stats={[
        { label: 'Events ingested', value: totals.events24h, to: `${base}/events` },
        { label: 'Detections', value: totals.detections24h, to: `${base}/events?detectedOnly=true` },
        { label: 'Open alerts', value: totals.openAlerts, to: `${base}/alerts` },
        { label: 'Active incidents', value: totals.activeIncidents, note: totals.criticalIncidents ? `${totals.criticalIncidents} critical` : 'None critical', tone: totals.criticalIncidents ? 'critical' : undefined, to: `${base}/incidents` },
        { label: 'Resolved this week', value: totals.resolved7d },
      ]}
      />

      <Panel title="Activity by hour" aside={<span className="muted small">Bar height is event volume; colour is the worst detection that hour</span>}>
        <SeverityStrip hourly={data.hourly} />
      </Panel>

      <div className="grid grid-2-1">
        <Panel title="Latest alerts" aside={<Link to={`${base}/alerts`}>All alerts</Link>}>
          <AlertList alerts={data.recentAlerts} base={base} />
        </Panel>
        <div className="stack">
          <Panel title="Open alerts by severity">
            <ul className="sevcount">
              {SEVERITIES.map((s) => (
                <li key={s}>
                  <SeverityBadge severity={s} />
                  <Link to={`${base}/alerts?severity=${s}`} className="sevcount-n">{data.alertSeverity[s]}</Link>
                </li>
              ))}
            </ul>
          </Panel>
          <Panel title="Incidents by attack type">
            <BarList items={data.incidentsByType} label={(r) => attackLabel(r.attackType)} value={(r) => r.count} emptyText="No incidents recorded" />
          </Panel>
        </div>
      </div>

      <Panel title="MITRE ATT&CK coverage" aside={<Link to={`${base}/mitre`}>Full view</Link>}>
        <MitreMatrix mitre={data.mitre} tacticOrder={data.tacticOrder} base={base} compact />
      </Panel>

      <div className="grid grid-3">
        <Panel title="Most active sources">
          <BarList
            items={[...data.topSources].sort((a, b) => b.events - a.events)}
            render={(r) => <Link to={`${base}/events?sourceIP=${encodeURIComponent(r.ip)}`}><Mono>{r.ip}</Mono></Link>}
            value={(r) => r.events}
            emptyText="No source addresses in the last 24 hours"
          />
        </Panel>
        <Panel title="Device health" aside={unhealthy ? <span className="tone-high small">{unhealthy} need attention</span> : <span className="muted small">All reporting</span>}>
          <DeviceHealthList devices={data.devices} />
        </Panel>
        <Panel title="Platform">
          <dl className="kv">
            <dt>User accounts</dt><dd>{platform.users} <span className="muted">({platform.clients} client)</span></dd>
            <dt>Registered devices</dt><dd>{platform.devices}</dd>
            <dt>Active IOCs</dt><dd><Link to={`${base}/ioc`}>{platform.activeIocs}</Link></dd>
            <dt>Dashboards connected now</dt><dd>{platform.connectedDashboards}</dd>
          </dl>
          <div className="quick-links">
            <Link to={`${base}/users`}>Manage users and roles</Link>
            <Link to={`${base}/ioc`}>Add indicators of compromise</Link>
            <Link to={`${base}/audit`}>Review the audit log</Link>
          </div>
        </Panel>
      </div>
    </>
  );
}
