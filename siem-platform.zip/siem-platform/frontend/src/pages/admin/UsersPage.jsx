import { useState } from 'react';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { EmptyState, ErrorNote, Field, Loading, Modal, PageHeader, Panel } from '../../components/ui';
import { dateTime, timeAgo } from '../../utils/format';

const EMPTY = { username: '', fullName: '', email: '', role: 'CLIENT', organization: '', password: '', isActive: true };

function UserForm({ user, onClose, onSaved }) {
  const editing = Boolean(user);
  const [form, setForm] = useState(editing ? { ...EMPTY, ...user, fullName: user.fullName || '', organization: user.organization || '', password: '' } : EMPTY);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null);
    const body = { username: form.username, fullName: form.fullName, email: form.email, role: form.role, organization: form.organization };
    if (form.password) body.password = form.password;
    if (editing) body.isActive = form.isActive;
    try {
      await (editing ? api(`/users/${user.id}`, { method: 'PUT', body }) : api('/users', { method: 'POST', body }));
      onSaved();
    } catch (err) { setError(err); setBusy(false); }
  };

  return (
    <Modal
      title={editing ? `Edit ${user.username}` : 'Add a user'}
      onClose={onClose}
      footer={(
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button type="submit" form="user-form" className="btn" disabled={busy}>{busy ? 'Saving…' : editing ? 'Save changes' : 'Add user'}</button>
        </>
      )}
    >
      <form id="user-form" className="form-grid form-2" onSubmit={submit}>
        <fieldset className="role-choice span-2">
          <legend>Role</legend>
          <label className={form.role === 'ADMIN' ? 'on' : ''}>
            <input type="radio" name="role" value="ADMIN" checked={form.role === 'ADMIN'} onChange={set('role')} />
            <span><strong>Administrator</strong><span className="muted small">Sees every tenant. Manages devices, API keys, users, IOCs and threat intelligence. Can close incidents.</span></span>
          </label>
          <label className={form.role === 'CLIENT' ? 'on' : ''}>
            <input type="radio" name="role" value="CLIENT" checked={form.role === 'CLIENT'} onChange={set('role')} />
            <span><strong>Client analyst</strong><span className="muted small">Sees only the devices assigned to them. Triages alerts and works incidents.</span></span>
          </label>
        </fieldset>
        <Field label="Username"><input value={form.username} onChange={set('username')} autoComplete="off" required /></Field>
        <Field label="Full name"><input value={form.fullName} onChange={set('fullName')} /></Field>
        <Field label="Email"><input type="email" value={form.email} onChange={set('email')} required /></Field>
        <Field label="Organisation" hint={form.role === 'CLIENT' ? 'Shown as the title of their dashboard.' : undefined}><input value={form.organization} onChange={set('organization')} /></Field>
        <Field label={editing ? 'New password' : 'Password'} hint={editing ? 'Leave blank to keep the current password.' : '8+ characters with upper and lower case letters and a number.'}>
          <input type="password" value={form.password} onChange={set('password')} autoComplete="new-password" required={!editing} />
        </Field>
        {editing && (
          <label className="check check-field"><input type="checkbox" checked={form.isActive} onChange={set('isActive')} /> Account can sign in</label>
        )}
        <div className="span-2"><ErrorNote error={error} /></div>
      </form>
    </Modal>
  );
}

export default function UsersPage() {
  const { user: me } = useAuth();
  const { data, error, loading, reload } = useApi('/users');
  const [editing, setEditing] = useState(undefined);
  const [removing, setRemoving] = useState(null);
  const [removeError, setRemoveError] = useState(null);

  const remove = async () => {
    setRemoveError(null);
    try {
      await api(`/users/${removing.id}`, { method: 'DELETE' });
      setRemoving(null);
      reload();
    } catch (e) { setRemoveError(e); }
  };

  return (
    <>
      <PageHeader
        title="Users and roles"
        intro="The role decides which dashboard a person lands on after signing in. Client analysts only see the devices assigned to them on the Devices page."
        actions={<button type="button" className="btn" onClick={() => setEditing(null)}>Add a user</button>}
      />
      <Panel flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? <EmptyState title="No users" /> : (
          <div className="table-scroll">
            <table className="table">
              <thead><tr><th>User</th><th>Role</th><th>Organisation</th><th>Devices</th><th>Account</th><th>Last sign-in</th><th><span className="sr-only">Actions</span></th></tr></thead>
              <tbody>
                {data.data.map((u) => (
                  <tr key={u.id}>
                    <td>
                      <div className="strong">{u.fullName || u.username}{u.id === me.id && <span className="muted small"> (you)</span>}</div>
                      <div className="muted small">{u.username}, {u.email}</div>
                    </td>
                    <td><span className={`role-tag role-${u.role === 'ADMIN' ? 'admin' : 'client'}`}>{u.role === 'ADMIN' ? 'Administrator' : 'Client'}</span></td>
                    <td>{u.organization || <span className="muted">—</span>}</td>
                    <td>{u.devices?.length ? u.devices.map((d) => d.name).join(', ') : <span className="muted">{u.role === 'ADMIN' ? 'All' : 'None assigned'}</span>}</td>
                    <td>{u.isActive ? 'Active' : <span className="tone-high">Disabled</span>}</td>
                    <td className="nowrap" title={dateTime(u.lastLogin)}>{u.lastLogin ? timeAgo(u.lastLogin) : 'Never'}</td>
                    <td className="row-actions">
                      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing(u)}>Edit</button>
                      {u.id !== me.id && <button type="button" className="btn btn-ghost btn-sm btn-danger" onClick={() => setRemoving(u)}>Delete</button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {editing !== undefined && <UserForm user={editing} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); reload(); }} />}
      {removing && (
        <Modal
          title={`Delete ${removing.username}?`}
          onClose={() => { setRemoving(null); setRemoveError(null); }}
          footer={(
            <>
              <button type="button" className="btn btn-ghost" onClick={() => setRemoving(null)}>Cancel</button>
              <button type="button" className="btn btn-danger-solid" onClick={remove}>Delete user</button>
            </>
          )}
        >
          <p>Their devices stay registered but become visible to administrators only. To keep the history of who did what, consider disabling the account instead.</p>
          <ErrorNote error={removeError} />
        </Modal>
      )}
    </>
  );
}
