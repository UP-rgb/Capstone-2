import { useState } from 'react';
import { api } from '../../api/client';
import { useApi } from '../../utils/useApi';
import { useQueryState } from '../../utils/useQueryState';
import {
  EmptyState, ErrorNote, Loading, Mono, PageHeader, Pagination, Panel, Select, SeverityBadge,
} from '../../components/ui';
import SearchInput from '../../components/SearchInput';
import { attackLabel, dateTime, iocTypeLabel, sentence, SEVERITIES, timeAgo } from '../../utils/format';

const MODE_TEXT = {
  live: 'Live. Indicators from detections are checked with VirusTotal and AbuseIPDB, then cached.',
  local: 'Local only. Lookups use the cached and seeded intelligence; no external calls are made.',
  off: 'Off. Events are scored without threat-intelligence enrichment.',
};

function Lookup({ onLooked }) {
  const [value, setValue] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError(null); setResult(null);
    try {
      setResult(await api('/threat-intel/lookup', { method: 'POST', body: { indicator: value.trim() } }));
      onLooked();
    } catch (err) { setError(err); } finally { setBusy(false); }
  };

  return (
    <Panel title="Look up an indicator">
      <form className="lookup" onSubmit={submit}>
        <label className="sr-only" htmlFor="ti-value">Indicator</label>
        <input id="ti-value" className="mono-input" value={value} onChange={(e) => setValue(e.target.value)} placeholder="IP address, domain, URL or file hash" />
        <button type="submit" className="btn" disabled={busy || !value.trim()}>{busy ? 'Checking…' : 'Check reputation'}</button>
      </form>
      <ErrorNote error={error} />
      {result && (
        <div className="lookup-result">
          <p className={result.flagged ? 'verdict verdict-bad' : 'verdict'}>
            <Mono>{result.indicator}</Mono> ({iocTypeLabel(result.type)}) {result.flagged ? 'has a bad reputation.' : 'has no bad reputation on record.'}
            {result.ioc && <> It is also in the IOC database ({result.ioc.isActive ? 'active' : 'inactive'}).</>}
          </p>
          {result.results.length > 0 ? (
            <ul className="intel-list">
              {result.results.map((r) => (
                <li key={r.id}>
                  <span><strong>{r.source}</strong> <SeverityBadge severity={r.severity} />{r.score !== null && r.score !== undefined && <span className="muted small"> score {r.score}</span>}</span>
                  <span className="muted small">{r.summary || 'No summary'}{r.country ? `, country ${r.country}` : ''}, checked {timeAgo(r.lastChecked)}</span>
                </li>
              ))}
            </ul>
          ) : <p className="muted small">No source returned data. {result.mode !== 'live' && 'External lookups are disabled in this mode, and private addresses are never sent out.'}</p>}
        </div>
      )}
    </Panel>
  );
}

export default function ThreatIntelPage() {
  const [f, setF] = useQueryState({});
  const status = useApi('/threat-intel/status');
  const { data, error, loading, reload } = useApi('/threat-intel', { q: f.q, source: f.source, severity: f.severity, page: f.page, limit: 50 });
  const s = status.data;

  return (
    <>
      <PageHeader
        title="Threat intelligence"
        intro="Reputation data used to enrich detections. Results are cached so free-tier API limits are respected."
      />
      <div className="grid grid-2-1">
        <Lookup onLooked={() => { reload(); status.reload(); }} />
        <Panel title="Enrichment sources">
          {!s ? <Loading /> : (
            <>
              <p className="small">{MODE_TEXT[s.mode] || s.mode}</p>
              <dl className="kv">
                <dt>Mode</dt><dd><Mono>THREAT_INTEL_MODE={s.mode}</Mono></dd>
                <dt>VirusTotal</dt><dd>{s.virusTotalConfigured ? 'API key set' : <span className="muted">No API key</span>}</dd>
                <dt>AbuseIPDB</dt><dd>{s.abuseIpdbConfigured ? 'API key set' : <span className="muted">No API key</span>}</dd>
                <dt>Cache lifetime</dt><dd>{s.cacheHours} hours</dd>
                <dt>Cached records</dt><dd>{s.total}{s.bySource?.length ? <span className="muted"> ({s.bySource.map((b) => `${b.source} ${b.count}`).join(', ')})</span> : ''}</dd>
              </dl>
            </>
          )}
        </Panel>
      </div>

      <div className="filters">
        <SearchInput value={f.q} onChange={(v) => setF('q', v)} placeholder="Search indicators" />
        <Select value={f.source || ''} onChange={(v) => setF('source', v)} options={[{ value: 'LOCAL', label: 'Local' }, { value: 'VirusTotal', label: 'VirusTotal' }, { value: 'AbuseIPDB', label: 'AbuseIPDB' }]} placeholder="Any source" aria-label="Source" />
        <Select value={f.severity || ''} onChange={(v) => setF('severity', v)} options={SEVERITIES} placeholder="Any severity" aria-label="Severity" />
      </div>
      <Panel title="Cached intelligence" flush>
        {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? (
          <EmptyState title="Nothing cached yet">Records appear here when a detection's indicators are enriched or when you run a lookup.</EmptyState>
        ) : (
          <div className="table-scroll">
            <table className="table">
              <thead><tr><th>Indicator</th><th>Source</th><th>Severity</th><th>Confidence</th><th>Attack type</th><th>Summary</th><th>Checked</th></tr></thead>
              <tbody>
                {data.data.map((t) => (
                  <tr key={t.id}>
                    <td><Mono>{t.indicator}</Mono><div className="muted small">{iocTypeLabel(t.indicatorType)}</div></td>
                    <td>{t.source}</td>
                    <td>{t.severity ? <SeverityBadge severity={t.severity} /> : <span className="muted">Clean</span>}</td>
                    <td>{t.confidence ? sentence(t.confidence) : '—'}</td>
                    <td>{t.attackType ? attackLabel(t.attackType) : '—'}</td>
                    <td className="clamp-cell">{t.summary || '—'}</td>
                    <td className="nowrap" title={dateTime(t.lastChecked)}>{timeAgo(t.lastChecked)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      {data && <Pagination pagination={data.pagination} onPage={(p) => setF('page', p)} />}
    </>
  );
}
