import { useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { homeFor, useAuth } from '../context/AuthContext';
import { Field } from '../components/ui';

// Seeded accounts (backend/src/seed/seed.js). Hide with VITE_SHOW_DEMO_ACCOUNTS=false.
const DEMO = [
  { username: 'admin', password: 'Admin@123', role: 'Administrator', note: 'All tenants, devices, users and IOCs' },
  { username: 'acme.analyst', password: 'Client@123', role: 'Client', note: 'Acme Pty Ltd devices only' },
  { username: 'globex.analyst', password: 'Client@123', role: 'Client', note: 'Globex Corporation devices only' },
];

export default function Login() {
  const { user, ready, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (ready && user) return <Navigate to={homeFor(user)} replace />;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const u = await login(identifier.trim(), password);
      const from = location.state?.from;
      const home = homeFor(u);
      navigate(from && from.startsWith(home) ? from : home, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const fill = (d) => { setIdentifier(d.username); setPassword(d.password); setError(''); };

  return (
    <div className="login">
      <section className="login-story">
        <div className="login-brand">
          <svg viewBox="0 0 32 32" width="36" height="36" aria-hidden="true">
            <path d="M16 2 4 6.5v8.2c0 7.4 5.1 13.4 12 15.3 6.9-1.9 12-7.9 12-15.3V6.5L16 2z" fill="none" stroke="currentColor" strokeWidth="1.6" />
            <path d="M9 17h4l2-5 3 9 2-4h3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span>Enterprise SIEM Platform</span>
        </div>
        <h1>Threat intelligence aggregation and attack detection</h1>
        <p>
          Devices send events with their own API key. Each event is checked against detection rules
          and the IOC database, enriched with threat intelligence, scored for risk and, when it matters,
          turned into an incident tagged with its MITRE ATT&amp;CK technique.
        </p>
        <ol className="login-pipeline" aria-label="Detection pipeline">
          <li>Ingest</li><li>Detect</li><li>Match IOCs</li><li>Enrich</li><li>Score</li><li>Respond</li>
        </ol>
        <p className="login-credit">ICT312 Capstone, Group 5, Sydney Metropolitan Institute of Technology</p>
      </section>

      <section className="login-form-wrap">
        <form className="login-form" onSubmit={submit} noValidate>
          <h2>Sign in</h2>
          <p className="muted">Administrators and client analysts use the same sign-in. You land on the dashboard for your role.</p>
          <Field label="Username or email">
            <input value={identifier} onChange={(e) => setIdentifier(e.target.value)} autoComplete="username" required autoFocus />
          </Field>
          <Field label="Password">
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
          </Field>
          {error && <div className="error-note" role="alert"><span>{error}</span></div>}
          <button type="submit" className="btn btn-block" disabled={busy || !identifier || !password}>
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        {import.meta.env.VITE_SHOW_DEMO_ACCOUNTS !== 'false' && (
          <div className="demo">
            <h3>Demo accounts</h3>
            <p className="muted small">Created by <code className="mono">npm run seed</code>. Choose one to fill the form.</p>
            <ul>
              {DEMO.map((d) => (
                <li key={d.username}>
                  <button type="button" className="demo-btn" onClick={() => fill(d)}>
                    <span className="demo-top">
                      <span className="mono">{d.username}</span>
                      <span className={`role-tag role-${d.role === 'Client' ? 'client' : 'admin'}`}>{d.role}</span>
                    </span>
                    <span className="muted small">{d.note}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>
    </div>
  );
}
