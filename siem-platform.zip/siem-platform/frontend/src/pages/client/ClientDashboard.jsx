import { Link } from 'react-router-dom';
import { useApi } from '../../utils/useApi';
import { useAuth } from '../../context/AuthContext';
import { EmptyState, ErrorNote, Loading, Mono, PageHeader, Panel, SeverityBadge, StatusPill } from '../../components/ui';
import StatRow from '../../components/StatRow';
import SeverityStrip from '../../components/SeverityStrip';
import AlertList from '../../components/AlertList';
import BarList from '../../components/BarList';
import MitreMatrix from '../../components/MitreMatrix';
import DeviceHealthList from '../../components/DeviceHealthList';
import { attackLabel, timeAgo } from '../../utils/format';

const SEV_ORDER = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };

export default function ClientDashboard() {
  const { user, base } = useAuth();
  const stats = useApi('/dashboard/stats', null, { live: true });
  const active = useApi('/incidents', { status: 'active', limit: 20 }, { live: true });

  if (stats.loading && !stats.data) return <Loading label="Loading your overview" />;
  if (stats.error && !stats.data) return <ErrorNote error={stats.error} onRetry={stats.reload} />;

  const data = stats.data;
  const { totals } = data;
  const org = user.organization || 'Your organisation';

  if (!data.devices.length) {
    return (
      <>
        <PageHeader title={`${org} security overview`} />
        <EmptyState title="No devices are assigned to you yet">
          An administrator registers your firewalls, servers and endpoints and assigns them to your account.
          Once a device starts sending events, its alerts and incidents appear here.
        </EmptyState>
      </>
    );
  }

  const needs = (active.data?.data || [])
    .slice()
    .sort((a, b) => SEV_ORDER[a.severity] - SEV_ORDER[b.severity] || new Date(b.lastSeen) - new Date(a.lastSeen))
    .slice(0, 5);
  const offline = data.devices.filter((d) => d.health !== 'online' && d.health !== 'disabled');

  let headline;
  if (totals.criticalIncidents) headline = `${totals.criticalIncidents} critical incident${totals.criticalIncidents > 1 ? 's' : ''} need your attention.`;
  else if (totals.activeIncidents) headline = `${totals.activeIncidents} incident${totals.activeIncidents > 1 ? 's are' : ' is'} still open.`;
  else headline = 'No open incidents. Your devices are being monitored.';

  return (
    <>
      <PageHeader
        title={`${org} security overview`}
        intro={`${headline} Showing the ${data.devices.length} device${data.devices.length > 1 ? 's' : ''} assigned to you.`}
      />

      <StatRow stats={[
        { label: 'Events from your devices', value: totals.events24h, note: 'Last 24 hours', to: `${base}/events` },
        { label: 'Detections', value: totals.detections24h, note: 'Last 24 hours', to: `${base}/events?detectedOnly=true` },
        { label: 'Open alerts', value: totals.openAlerts, to: `${base}/alerts` },
        { label: 'Active incidents', value: totals.activeIncidents, tone: totals.criticalIncidents ? 'critical' : undefined, note: totals.criticalIncidents ? `${totals.criticalIncidents} critical` : undefined, to: `${base}/incidents` },
      ]}
      />

      <div className="grid grid-2-1">
        <Panel title="Needs your attention" aside={<Link to={`${base}/incidents`}>All incidents</Link>} flush>
          {needs.length ? (
            <div className="table-scroll"><table className="table">
              <thead><tr><th>Incident</th><th>Severity</th><th>Status</th><th>Last activity</th></tr></thead>
              <tbody>
                {needs.map((i) => (
                  <tr key={i.id}>
                    <td>
                      <Link to={`${base}/incidents/${i.id}`} className="strong">{i.title}</Link>
                      <div className="muted small"><Mono>{i.reference}</Mono> {attackLabel(i.attackType)} on {i.device?.name}</div>
                    </td>
                    <td><SeverityBadge severity={i.severity} score={i.riskScore} /></td>
                    <td><StatusPill status={i.status} /></td>
                    <td className="nowrap muted">{timeAgo(i.lastSeen)}</td>
                  </tr>
                ))}
              </tbody>
            </table></div>
          ) : <div className="panel-pad"><p className="muted">Nothing open. New incidents appear here as soon as the detection engine raises them.</p></div>}
        </Panel>
        <Panel title="Your devices" aside={offline.length ? <span className="tone-high small">{offline.length} not reporting</span> : <span className="muted small">All reporting</span>}>
          <DeviceHealthList devices={data.devices} />
        </Panel>
      </div>

      <Panel title="Activity by hour" aside={<span className="muted small">Bar height is event volume; colour is the worst detection that hour</span>}>
        <SeverityStrip hourly={data.hourly} />
      </Panel>

      <div className="grid grid-2">
        <Panel title="Latest alerts" aside={<Link to={`${base}/alerts`}>All alerts</Link>}>
          <AlertList alerts={data.recentAlerts} base={base} />
        </Panel>
        <div className="stack">
          <Panel title="Attack types seen">
            <BarList items={data.incidentsByType} label={(r) => attackLabel(r.attackType)} value={(r) => r.count} emptyText="No incidents recorded" />
          </Panel>
          <Panel title="Sources contacting your devices">
            <BarList
              items={[...data.topSources].sort((a, b) => b.events - a.events).slice(0, 5)}
              render={(r) => <Link to={`${base}/events?sourceIP=${encodeURIComponent(r.ip)}`}><Mono>{r.ip}</Mono></Link>}
              value={(r) => r.events}
              emptyText="No source addresses in the last 24 hours"
            />
          </Panel>
        </div>
      </div>

      <Panel title="MITRE ATT&CK techniques seen" aside={<Link to={`${base}/mitre`}>Full view</Link>}>
        <MitreMatrix mitre={data.mitre} tacticOrder={data.tacticOrder} base={base} compact />
      </Panel>
    </>
  );
}
