import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useApi } from '../../utils/useApi';
import { EmptyState, ErrorNote, HealthDot, Loading, Mono, PageHeader, Panel } from '../../components/ui';
import { dateTime, sentence, timeAgo } from '../../utils/format';

// Read-only for clients: devices and API keys are issued by an administrator (FR2).
export default function MyDevicesPage() {
  const { base } = useAuth();
  const { data, error, loading, reload } = useApi('/devices', null, { live: true });

  return (
    <>
      <PageHeader
        title="Monitored devices"
        intro="The devices assigned to you. To add a device, move one to another owner, or replace an API key, contact your administrator."
      />
      {loading && !data ? <Loading /> : error ? <ErrorNote error={error} onRetry={reload} /> : !data.data.length ? (
        <EmptyState title="No devices are assigned to you yet">An administrator registers devices and assigns them to your account.</EmptyState>
      ) : (
        <div className="device-cards">
          {data.data.map((d) => (
            <Panel key={d.id} title={d.name} aside={<HealthDot health={d.health} />}>
              <dl className="kv">
                <dt>Type</dt><dd>{sentence(d.type)}</dd>
                <dt>Address</dt><dd><Mono>{d.ipAddress}</Mono></dd>
                {d.hostname && <><dt>Hostname</dt><dd>{d.hostname}</dd></>}
                {d.location && <><dt>Location</dt><dd>{d.location}</dd></>}
                <dt>Last report</dt><dd title={dateTime(d.lastHeartbeat)}>{d.lastHeartbeat ? timeAgo(d.lastHeartbeat) : 'Never'}</dd>
                <dt>Events received</dt><dd>{Number(d.eventCount).toLocaleString()}</dd>
                <dt>Key</dt><dd><Mono>{d.apiKeyPrefix ? `${d.apiKeyPrefix}…` : null}</Mono></dd>
              </dl>
              <div className="quick-links">
                <Link to={`${base}/events?deviceId=${d.id}`}>Events from this device</Link>
              </div>
              {d.health === 'stale' && <p className="warn-note small">No events or heartbeat for over 15 minutes. Check that the collector is running and can reach the SIEM.</p>}
              {d.health === 'never_seen' && <p className="warn-note small">This device has not reported yet. The collector needs the device's API key.</p>}
            </Panel>
          ))}
        </div>
      )}
    </>
  );
}
