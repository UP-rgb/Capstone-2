import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { EmptyState } from '../components/ui';

export default function NotFound() {
  const { base } = useAuth();
  return (
    <EmptyState title="This page does not exist">
      The link may be out of date, or the page is only available to another role. <Link to={base}>Go to your overview</Link>.
    </EmptyState>
  );
}
