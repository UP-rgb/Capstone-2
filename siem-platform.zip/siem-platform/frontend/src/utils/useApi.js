import { useCallback, useEffect, useState } from 'react';
import { api } from '../api/client';
import { useLive } from '../context/LiveContext';

// Fetches `path` with `query`; refetches when inputs change or (if live) when the
// server pushes a new alert/incident update.
export function useApi(path, query, { live = false, skip = false } = {}) {
  const { revision } = useLive();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(!skip);
  const key = JSON.stringify(query || {});
  const liveKey = live ? revision : 0;

  const load = useCallback(async () => {
    if (skip || !path) return;
    setLoading(true);
    try {
      setData(await api(path, { query: JSON.parse(key) }));
      setError(null);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, [path, key, skip]);

  useEffect(() => { load(); }, [load, liveKey]);

  return { data, error, loading, reload: load, setData };
}
