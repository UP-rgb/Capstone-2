import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';

// Keeps list filters in the URL so they survive reloads and can be linked to
// (e.g. dashboard tiles link to /alerts?severity=HIGH). Changing a filter resets the page.
export function useQueryState(defaults = {}) {
  const [params, setParams] = useSearchParams();
  const values = useMemo(() => {
    const out = { ...defaults };
    params.forEach((v, k) => { out[k] = v; });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  const set = useCallback((key, value) => {
    setParams((prev) => {
      const next = new URLSearchParams(prev);
      if (value === '' || value === undefined || value === null) next.delete(key);
      else next.set(key, value);
      if (key !== 'page') next.delete('page');
      return next;
    }, { replace: true });
  }, [setParams]);

  // Update several keys in one navigation (separate set() calls in the same tick would overwrite each other).
  const setMany = useCallback((obj) => {
    setParams((prev) => {
      const next = new URLSearchParams(prev);
      Object.entries(obj).forEach(([k, v]) => { if (v === '' || v === undefined || v === null) next.delete(k); else next.set(k, v); });
      next.delete('page');
      return next;
    }, { replace: true });
  }, [setParams]);

  const reset = useCallback(() => setParams(new URLSearchParams(), { replace: true }), [setParams]);
  return [values, set, reset, setMany];
}
