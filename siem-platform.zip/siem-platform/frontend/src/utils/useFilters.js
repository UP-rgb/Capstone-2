import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';

// Filters live in the URL so views can be bookmarked, shared and linked to from dashboards.
export function useFilters(keys) {
  const [params, setParams] = useSearchParams();
  const filters = useMemo(
    () => Object.fromEntries([...keys, 'page'].map((k) => [k, params.get(k) || ''])),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [params, keys.join()],
  );
  const set = useCallback((patch) => {
    setParams((prev) => {
      const next = new URLSearchParams(prev);
      Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
      if (!('page' in patch)) next.delete('page');
      return next;
    }, { replace: true });
  }, [setParams]);
  const clear = useCallback(() => setParams(new URLSearchParams(), { replace: true }), [setParams]);
  const active = keys.some((k) => filters[k]);
  return { filters, set, clear, active };
}
