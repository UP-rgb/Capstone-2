export const SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
export const INCIDENT_STATUSES = ['OPEN', 'ACKNOWLEDGED', 'INVESTIGATING', 'CONTAINED', 'RESOLVED', 'CLOSED'];
export const ALERT_STATUSES = ['NEW', 'ACKNOWLEDGED', 'RESOLVED', 'FALSE_POSITIVE'];

export const ATTACK_LABELS = {
  brute_force: 'Brute force',
  phishing: 'Phishing',
  malware: 'Malware',
  ddos: 'Denial of service',
  data_exfiltration: 'Data exfiltration',
  port_scan: 'Port scan',
  ioc_reputation: 'Known-bad indicator',
  powershell: 'Suspicious PowerShell',
};
export const attackLabel = (t) => ATTACK_LABELS[t] || (t ? t.replace(/_/g, ' ') : 'Unclassified');

export const sentence = (s) => (s ? s.charAt(0) + s.slice(1).toLowerCase().replace(/_/g, ' ') : '');

export const timeAgo = (d) => {
  if (!d) return 'never';
  const s = Math.round((Date.now() - new Date(d).getTime()) / 1000);
  if (s < 45) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
};

export const dateTime = (d) => (d ? new Date(d).toLocaleString(undefined, {
  day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit',
}) : '—');

export const hourLabel = (d) => new Date(d).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });

export const DEVICE_TYPES = ['WINDOWS', 'LINUX', 'FIREWALL', 'SERVER', 'ROUTER', 'APPLICATION'];
export const IOC_TYPES = ['IP', 'DOMAIN', 'URL', 'HASH', 'EMAIL'];
export const IOC_TYPE_LABELS = { IP: 'IP address', DOMAIN: 'Domain', URL: 'URL', HASH: 'File hash', EMAIL: 'Email address' };
export const iocTypeLabel = (t) => IOC_TYPE_LABELS[t] || t;

// 45 -> "45 min", 200 -> "3.3 h", 4000 -> "2.8 d"
export const duration = (minutes) => {
  if (minutes === null || minutes === undefined) return '—';
  if (minutes < 1) return 'under 1 min';
  if (minutes < 90) return `${Math.round(minutes)} min`;
  if (minutes < 60 * 36) return `${(minutes / 60).toFixed(1)} h`;
  return `${(minutes / 1440).toFixed(1)} d`;
};
export const pct = (v, digits = 1) => (v === null || v === undefined ? '—' : `${(v * 100).toFixed(digits)}%`);
export const ms = (v) => (v === null || v === undefined ? '—' : v < 10 ? `${Number(v).toFixed(1)} ms` : `${Math.round(v)} ms`);
export const dateOnly = (d) => (d ? new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : '—');
