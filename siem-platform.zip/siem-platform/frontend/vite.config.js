import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// In development the dashboard runs on :5173 and proxies API + websocket traffic
// to the backend. Set VITE_BACKEND in frontend/.env (e.g. http://localhost:5001 or
// http://192.168.1.10:5000) to point it somewhere else. Defaults to localhost:5000.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const target = env.VITE_BACKEND || 'http://localhost:5000';
  return {
    plugins: [react()],
    server: {
      host: true,
      port: 5173,
      proxy: {
        '/api': { target, changeOrigin: true },
        '/socket.io': { target, ws: true, changeOrigin: true },
      },
    },
  };
});
