const { Op, QueryTypes } = require('sequelize');
const { sequelize, SecurityEvent, Alert, Incident, Device, User } = require('../models');
const { HttpError, asyncHandler } = require('../utils/http');
const { visibleDeviceIds } = require('../utils/scope');
const { parseRange, responseTimes, countBy, toCsv } = require('../services/reporting');
const { SEVERITIES, INCIDENT_STATUS, ALERT_STATUS } = require('../utils/constants');
const mitreMapper = require('../services/mitreMapper');
const { audit } = require('../utils/audit');

const scopeFor = async (user) => {
  const ids = await visibleDeviceIds(user);
  return {
    ids,
    where: (w = {}) => (ids === null ? w : { ...w, deviceId: { [Op.in]: ids.length ? ids : ['00000000-0000-0000-0000-000000000000'] } }),
    sql: ids === null ? '' : ids.length ? 'AND e."deviceId" IN (:ids)' : 'AND false',
  };
};

// GET /api/reports/summary?from&to — SOC report for the period (scoped to the user's devices)
exports.summary = asyncHandler(async (req, res) => {
  const { from, to } = parseRange(req.query);
  const scope = await scopeFor(req.user);
  const period = { [Op.between]: [from, to] };
  const repl = { from, to, ids: scope.ids };

  const [events, detections, alerts, incidents, resolvedInPeriod, topSources, byDevice, eventTypes] = await Promise.all([
    SecurityEvent.count({ where: scope.where({ timestamp: period }) }),
    SecurityEvent.count({ where: scope.where({ timestamp: period, attackType: { [Op.ne]: null } }) }),
    Alert.findAll({ where: scope.where({ createdAt: period }), attributes: ['severity', 'status', 'attackType', 'detectionLatencyMs'], raw: true }),
    Incident.findAll({
      where: scope.where({ createdAt: period }),
      attributes: { exclude: ['evidence', 'description'] },
      include: [{ model: Device, as: 'device', attributes: ['id', 'name'] }, { model: User, as: 'assignee', attributes: ['username'] }],
      order: [['createdAt', 'DESC']],
    }),
    Incident.count({ where: scope.where({ resolvedAt: period }) }),
    sequelize.query(
      `SELECT e."sourceIP" AS ip, COUNT(*)::int AS events, COUNT(e."attackType")::int AS detections
         FROM security_events e WHERE e."sourceIP" IS NOT NULL AND e."timestamp" BETWEEN :from AND :to ${scope.sql}
        GROUP BY 1 ORDER BY detections DESC, events DESC LIMIT 10`,
      { replacements: repl, type: QueryTypes.SELECT },
    ),
    sequelize.query(
      `SELECT d.id, d.name, d.type, COUNT(e.id)::int AS events, COUNT(e."attackType")::int AS detections
         FROM security_events e JOIN devices d ON d.id = e."deviceId"
        WHERE e."timestamp" BETWEEN :from AND :to ${scope.sql}
        GROUP BY d.id, d.name, d.type ORDER BY events DESC`,
      { replacements: repl, type: QueryTypes.SELECT },
    ),
    sequelize.query(
      `SELECT e."eventType" AS "eventType", COUNT(*)::int AS events
         FROM security_events e WHERE e."timestamp" BETWEEN :from AND :to ${scope.sql}
        GROUP BY 1 ORDER BY 2 DESC LIMIT 10`,
      { replacements: repl, type: QueryTypes.SELECT },
    ),
  ]);

  const plain = incidents.map((i) => i.toJSON());
  const techniqueCounts = countBy(plain, 'mitreTechnique');
  res.json({
    period: { from, to },
    scope: scope.ids === null ? 'all' : 'own',
    organization: req.user.role === 'ADMIN' ? null : req.user.organization,
    generatedAt: new Date(),
    generatedBy: req.user.username,
    totals: {
      events, detections, alerts: alerts.length, incidents: plain.length, resolvedInPeriod,
      openIncidents: plain.filter((i) => !['RESOLVED', 'CLOSED'].includes(i.status)).length,
      falsePositiveAlerts: alerts.filter((a) => a.status === 'FALSE_POSITIVE').length,
    },
    alertsBySeverity: countBy(alerts, 'severity', SEVERITIES),
    alertsByStatus: countBy(alerts, 'status', ALERT_STATUS),
    incidentsBySeverity: countBy(plain, 'severity', SEVERITIES),
    incidentsByStatus: countBy(plain, 'status', INCIDENT_STATUS),
    incidentsByType: countBy(plain, 'attackType'),
    mitre: mitreMapper.list().map((m) => ({ ...m, count: techniqueCounts[m.technique] || 0 })),
    responseTimes: responseTimes(plain),
    topSources,
    devices: byDevice,
    eventTypes,
    incidents: plain.map((i) => ({
      id: i.id, reference: i.reference, title: i.title, severity: i.severity, riskScore: i.riskScore, status: i.status,
      attackType: i.attackType, mitreTechnique: i.mitreTechnique, device: i.device && i.device.name, sourceIP: i.sourceIP,
      assignee: i.assignee && i.assignee.username, createdAt: i.createdAt, resolvedAt: i.resolvedAt, eventCount: i.eventCount,
    })),
  });
});

const DATASETS = {
  incidents: {
    load: (where) => Incident.findAll({ where: where('createdAt'), include: [{ model: Device, as: 'device', attributes: ['name'] }, { model: User, as: 'assignee', attributes: ['username'] }], attributes: { exclude: ['evidence', 'timeline'] }, order: [['createdAt', 'DESC']], limit: 10000 }),
    columns: [
      { label: 'Reference', value: 'reference' }, { label: 'Title', value: 'title' }, { label: 'Severity', value: 'severity' },
      { label: 'Risk score', value: 'riskScore' }, { label: 'Status', value: 'status' }, { label: 'Attack type', value: 'attackType' },
      { label: 'MITRE technique', value: 'mitreTechnique' }, { label: 'MITRE tactic', value: 'mitreTactic' },
      { label: 'Device', value: (r) => r.device && r.device.name }, { label: 'Source IP', value: 'sourceIP' },
      { label: 'Events', value: 'eventCount' }, { label: 'Assigned to', value: (r) => r.assignee && r.assignee.username },
      { label: 'Opened', value: 'createdAt' }, { label: 'Last seen', value: 'lastSeen' }, { label: 'Resolved', value: 'resolvedAt' },
    ],
  },
  alerts: {
    load: (where) => Alert.findAll({ where: where('createdAt'), include: [{ model: Device, as: 'device', attributes: ['name'] }], order: [['createdAt', 'DESC']], limit: 10000 }),
    columns: [
      { label: 'Title', value: 'title' }, { label: 'Severity', value: 'severity' }, { label: 'Risk score', value: 'riskScore' },
      { label: 'Status', value: 'status' }, { label: 'Attack type', value: 'attackType' }, { label: 'MITRE technique', value: 'mitreTechnique' },
      { label: 'Device', value: (r) => r.device && r.device.name }, { label: 'Source IP', value: 'sourceIP' },
      { label: 'Events', value: 'eventCount' }, { label: 'Detection latency (ms)', value: 'detectionLatencyMs' },
      { label: 'First seen', value: 'firstSeen' }, { label: 'Last seen', value: 'lastSeen' },
    ],
  },
  events: {
    load: (where) => SecurityEvent.findAll({ where: where('timestamp'), include: [{ model: Device, as: 'device', attributes: ['name'] }], attributes: { exclude: ['raw'] }, order: [['timestamp', 'DESC']], limit: 20000 }),
    columns: [
      { label: 'Time', value: 'timestamp' }, { label: 'Device', value: (r) => r.device && r.device.name }, { label: 'Event type', value: 'eventType' },
      { label: 'Severity', value: 'severity' }, { label: 'Risk score', value: 'riskScore' }, { label: 'Detection', value: 'attackType' },
      { label: 'Source IP', value: 'sourceIP' }, { label: 'Destination IP', value: 'destinationIP' }, { label: 'Destination port', value: 'destinationPort' },
      { label: 'User', value: 'username' }, { label: 'Message', value: 'message' },
    ],
  },
};

// GET /api/reports/export/:dataset?from&to — CSV download (scoped)
exports.exportCsv = asyncHandler(async (req, res) => {
  const ds = DATASETS[req.params.dataset];
  if (!ds) throw new HttpError(404, 'Unknown export. Use incidents, alerts or events.');
  const { from, to } = parseRange(req.query);
  const scope = await scopeFor(req.user);
  const rows = await ds.load((field) => scope.where({ [field]: { [Op.between]: [from, to] } }));
  audit(req, 'report.exported', 'Report', null, { dataset: req.params.dataset, rows: rows.length, from, to });
  const day = (d) => d.toISOString().slice(0, 10);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="siem-${req.params.dataset}-${day(from)}-to-${day(to)}.csv"`);
  res.send(`\uFEFF${toCsv(ds.columns, rows.map((r) => r.toJSON()))}`);
});
