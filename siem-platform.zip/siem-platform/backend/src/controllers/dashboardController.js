const { Op, QueryTypes } = require('sequelize');
const {
  sequelize, SecurityEvent, Alert, Incident, Device, User, IOC,
} = require('../models');
const { asyncHandler } = require('../utils/http');
const { visibleDeviceIds } = require('../utils/scope');
const mitreMapper = require('../services/mitreMapper');
const socket = require('../services/socket');

const SEV_SQL = `MAX(CASE severity WHEN 'CRITICAL' THEN 4 WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 ELSE 1 END)`;
const SEV_NAME = { 1: 'LOW', 2: 'MEDIUM', 3: 'HIGH', 4: 'CRITICAL' };

// Single scoped summary used by both dashboards (admin sees all, client sees own devices).
exports.stats = asyncHandler(async (req, res) => {
  const ids = await visibleDeviceIds(req.user);
  const scoped = (where = {}) => (ids === null ? where : { ...where, deviceId: { [Op.in]: ids.length ? ids : [null] } });
  const sqlScope = ids === null ? '' : ids.length ? 'AND "deviceId" IN (:ids)' : 'AND false';
  const since = new Date(Date.now() - 24 * 3600 * 1000);

  const [
    events24h, detections24h, openAlerts, activeIncidents, criticalIncidents, resolved7d,
    alertSeverity, incidentsByType, hourly, topSources, mitreRows, recentAlerts, devices,
  ] = await Promise.all([
    SecurityEvent.count({ where: scoped({ timestamp: { [Op.gte]: since } }) }),
    SecurityEvent.count({ where: scoped({ timestamp: { [Op.gte]: since }, attackType: { [Op.ne]: null } }) }),
    Alert.count({ where: scoped({ status: { [Op.in]: ['NEW', 'ACKNOWLEDGED'] } }) }),
    Incident.count({ where: scoped({ status: { [Op.notIn]: ['RESOLVED', 'CLOSED'] } }) }),
    Incident.count({ where: scoped({ status: { [Op.notIn]: ['RESOLVED', 'CLOSED'] }, severity: 'CRITICAL' }) }),
    Incident.count({ where: scoped({ resolvedAt: { [Op.gte]: new Date(Date.now() - 7 * 86400000) } }) }),
    Alert.findAll({ where: scoped({ status: { [Op.in]: ['NEW', 'ACKNOWLEDGED'] } }), attributes: ['severity', [sequelize.fn('COUNT', '*'), 'count']], group: ['severity'], raw: true }),
    Incident.findAll({ where: scoped(), attributes: ['attackType', [sequelize.fn('COUNT', '*'), 'count']], group: ['attackType'], raw: true }),
    sequelize.query(
      `SELECT date_trunc('hour', "timestamp") AS hour, COUNT(*)::int AS events,
              COUNT("attackType")::int AS detections, ${SEV_SQL} AS sev
         FROM security_events WHERE "timestamp" >= :since ${sqlScope}
        GROUP BY 1 ORDER BY 1`,
      { replacements: { since, ids }, type: QueryTypes.SELECT },
    ),
    sequelize.query(
      `SELECT "sourceIP" AS ip, COUNT(*)::int AS events, COUNT("attackType")::int AS detections
         FROM security_events WHERE "sourceIP" IS NOT NULL AND "timestamp" >= :since ${sqlScope}
        GROUP BY 1 ORDER BY detections DESC, events DESC LIMIT 8`,
      { replacements: { since, ids }, type: QueryTypes.SELECT },
    ),
    Incident.findAll({ where: scoped(), attributes: ['mitreTechnique', [sequelize.fn('COUNT', '*'), 'count']], group: ['mitreTechnique'], raw: true }),
    Alert.findAll({ where: scoped(), include: [{ model: Device, as: 'device', attributes: ['id', 'name'] }], order: [['lastSeen', 'DESC']], limit: 8 }),
    Device.findAll({ where: ids === null ? {} : { ownerId: req.user.id }, attributes: ['id', 'name', 'type', 'status', 'lastHeartbeat', 'eventCount'] }),
  ]);

  // Fill all 24 hours so the chart has a continuous axis.
  const byHour = new Map(hourly.map((h) => [new Date(h.hour).getTime(), h]));
  const start = new Date(); start.setUTCMinutes(0, 0, 0);
  const series = Array.from({ length: 24 }, (_, i) => {
    const t = start.getTime() - (23 - i) * 3600000;
    const h = byHour.get(t);
    return { hour: new Date(t).toISOString(), events: h ? h.events : 0, detections: h ? h.detections : 0, maxSeverity: h && h.detections ? SEV_NAME[h.sev] : null };
  });

  const mitreCounts = Object.fromEntries(mitreRows.map((r) => [r.mitreTechnique, Number(r.count)]));
  const mitre = mitreMapper.list().map((m) => ({ ...m, count: mitreCounts[m.technique] || 0 }));

  const staleMs = 15 * 60 * 1000;
  const deviceHealth = devices.map((d) => ({
    id: d.id, name: d.name, type: d.type, eventCount: d.eventCount, lastHeartbeat: d.lastHeartbeat,
    health: d.status === 'DISABLED' ? 'disabled' : !d.lastHeartbeat ? 'never_seen'
      : Date.now() - new Date(d.lastHeartbeat).getTime() > staleMs ? 'stale' : 'online',
  }));

  const body = {
    scope: ids === null ? 'all' : 'own',
    totals: { events24h, detections24h, openAlerts, activeIncidents, criticalIncidents, resolved7d },
    alertSeverity: Object.fromEntries(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((s) => [s, Number((alertSeverity.find((a) => a.severity === s) || {}).count || 0)])),
    incidentsByType: incidentsByType.map((r) => ({ attackType: r.attackType, count: Number(r.count) })).sort((a, b) => b.count - a.count),
    hourly: series,
    topSources,
    mitre,
    tacticOrder: mitreMapper.TACTIC_ORDER,
    recentAlerts,
    devices: deviceHealth,
  };

  if (req.user.role === 'ADMIN') {
    const [users, clients, iocs] = await Promise.all([User.count(), User.count({ where: { role: 'CLIENT' } }), IOC.count({ where: { isActive: true } })]);
    body.platform = { users, clients, devices: devices.length, activeIocs: iocs, connectedDashboards: socket.connectedCount() };
  }
  res.json(body);
});
