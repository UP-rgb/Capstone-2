const { Op } = require('sequelize');
const { Alert, Device, User, Incident } = require('../models');
const { HttpError, asyncHandler, parsePaging, paged } = require('../utils/http');
const { scopeWhere, canSeeDevice } = require('../utils/scope');
const { ALERT_STATUS, SEVERITIES } = require('../utils/constants');
const { audit } = require('../utils/audit');
const socket = require('../services/socket');

const include = [
  { model: Device, as: 'device', attributes: ['id', 'name', 'type', 'ownerId'] },
  { model: User, as: 'assignee', attributes: ['id', 'username'] },
  { model: Incident, as: 'incident', attributes: ['id', 'reference', 'status'] },
];

exports.list = asyncHandler(async (req, res) => {
  const { status, severity, attackType, q } = req.query;
  const paging = parsePaging(req.query, 25, 200);
  const where = {};
  if (status === 'open') where.status = { [Op.in]: ['NEW', 'ACKNOWLEDGED'] };
  else if (status && ALERT_STATUS.includes(status)) where.status = status;
  if (severity && SEVERITIES.includes(severity)) where.severity = severity;
  if (attackType) where.attackType = attackType;
  if (q) where[Op.or] = [{ title: { [Op.iLike]: `%${q}%` } }, { sourceIP: { [Op.iLike]: `%${q}%` } }];

  const { rows, count } = await Alert.findAndCountAll({
    where: await scopeWhere(req.user, where), include, order: [['lastSeen', 'DESC']],
    limit: paging.limit, offset: paging.offset,
  });
  res.json(paged(rows, count, paging));
});

const load = async (req) => {
  const alert = await Alert.findByPk(req.params.id, { include });
  if (!alert || !(await canSeeDevice(req.user, alert.deviceId))) throw new HttpError(404, 'Alert not found');
  return alert;
};

exports.get = asyncHandler(async (req, res) => res.json({ data: await load(req) }));

// PATCH /api/alerts/:id/status { status }
exports.updateStatus = asyncHandler(async (req, res) => {
  const alert = await load(req);
  const { status } = req.body;
  if (!ALERT_STATUS.includes(status)) throw new HttpError(400, `status must be one of ${ALERT_STATUS.join(', ')}`);
  await alert.update({ status });
  audit(req, 'alert.status_changed', 'Alert', alert.id, { status });
  socket.emitScoped('alert_updated', { alert: alert.toJSON() }, alert.device && alert.device.ownerId);
  res.json({ data: alert });
});

// PATCH /api/alerts/:id/assign { userId }  (admin)
exports.assign = asyncHandler(async (req, res) => {
  const alert = await load(req);
  const userId = req.body.userId || null;
  if (userId && !(await User.findByPk(userId))) throw new HttpError(400, 'User not found');
  await alert.update({ assignedTo: userId });
  audit(req, 'alert.assigned', 'Alert', alert.id, { userId });
  res.json({ data: await load(req) });
});
