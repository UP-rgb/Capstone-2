const { Op } = require('sequelize');
const { User } = require('../models');
const { signToken } = require('../middleware/auth');
const { HttpError, asyncHandler } = require('../utils/http');
const { validate, STRONG_PASSWORD } = require('../utils/validate');
const { audit } = require('../utils/audit');

// POST /api/auth/login  { identifier (username or email), password }
exports.login = asyncHandler(async (req, res) => {
  const identifier = String(req.body.identifier || req.body.username || req.body.email || '').trim();
  const password = String(req.body.password || '');
  if (!identifier || !password) throw new HttpError(400, 'Enter your username or email and password');

  const user = await User.scope('withPassword').findOne({
    where: { [Op.or]: [{ username: identifier }, { email: identifier.toLowerCase() }] },
  });
  // Same message for unknown user / wrong password so accounts can't be enumerated.
  if (!user || !(await user.checkPassword(password))) {
    audit(req, 'auth.login_failed', 'User', user ? user.id : null, { identifier });
    throw new HttpError(401, 'Username or password is incorrect');
  }
  if (!user.isActive) throw new HttpError(403, 'This account is disabled. Contact an administrator.');

  user.lastLogin = new Date();
  await user.save({ fields: ['lastLogin'] });
  req.user = user;
  audit(req, 'auth.login', 'User', user.id);

  res.json({ token: signToken(user), user: user.toSafeJSON() });
});

// GET /api/auth/me
exports.me = asyncHandler(async (req, res) => {
  res.json({ user: req.user.toSafeJSON() });
});

// POST /api/auth/change-password { currentPassword, newPassword }
exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = validate(req.body, {
    currentPassword: { required: true, type: 'string' },
    newPassword: { required: true, type: 'string', pattern: STRONG_PASSWORD, message: 'needs 8+ characters with upper and lower case letters and a number' },
  });
  const user = await User.scope('withPassword').findByPk(req.user.id);
  if (!(await user.checkPassword(currentPassword))) throw new HttpError(400, 'Current password is incorrect');
  user.password = newPassword;
  await user.save();
  audit(req, 'auth.password_changed', 'User', user.id);
  res.json({ message: 'Password updated' });
});
