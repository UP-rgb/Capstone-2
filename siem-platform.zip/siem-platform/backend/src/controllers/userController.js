const { User, Device } = require('../models');
const { HttpError, asyncHandler } = require('../utils/http');
const { validate, EMAIL, STRONG_PASSWORD } = require('../utils/validate');
const { ROLES } = require('../utils/constants');
const { audit } = require('../utils/audit');

const rules = {
  username: { required: true, type: 'string', min: 3, max: 60, pattern: /^[a-zA-Z0-9._-]+$/, message: 'may only contain letters, numbers, dots, dashes and underscores' },
  email: { required: true, type: 'string', pattern: EMAIL, message: 'must be a valid email address' },
  password: { required: true, type: 'string', pattern: STRONG_PASSWORD, message: 'needs 8+ characters with upper and lower case letters and a number' },
  role: { required: true, enum: ROLES },
  fullName: { type: 'string', max: 120 },
  organization: { type: 'string', max: 120 },
  isActive: { type: 'boolean' },
};

exports.list = asyncHandler(async (req, res) => {
  const users = await User.findAll({
    order: [['createdAt', 'ASC']],
    include: [{ model: Device, as: 'devices', attributes: ['id', 'name'] }],
  });
  res.json({ data: users });
});

exports.create = asyncHandler(async (req, res) => {
  const data = validate(req.body, rules);
  data.email = data.email.toLowerCase();
  const user = await User.create(data);
  audit(req, 'user.created', 'User', user.id, { username: user.username, role: user.role });
  res.status(201).json({ data: user.toSafeJSON() });
});

exports.update = asyncHandler(async (req, res) => {
  const user = await User.findByPk(req.params.id);
  if (!user) throw new HttpError(404, 'User not found');
  const data = validate(req.body, rules, { partial: true });
  if (user.id === req.user.id && (data.role && data.role !== 'ADMIN' || data.isActive === false)) {
    throw new HttpError(400, 'You cannot remove your own admin access or disable your own account');
  }
  if (data.email) data.email = data.email.toLowerCase();
  await user.update(data);
  audit(req, 'user.updated', 'User', user.id, { fields: Object.keys(data).filter((k) => k !== 'password') });
  res.json({ data: user.toSafeJSON() });
});

exports.remove = asyncHandler(async (req, res) => {
  if (req.params.id === req.user.id) throw new HttpError(400, 'You cannot delete your own account');
  const user = await User.findByPk(req.params.id);
  if (!user) throw new HttpError(404, 'User not found');
  await Device.update({ ownerId: null }, { where: { ownerId: user.id } });
  await user.destroy();
  audit(req, 'user.deleted', 'User', req.params.id, { username: user.username });
  res.json({ message: 'User deleted' });
});
