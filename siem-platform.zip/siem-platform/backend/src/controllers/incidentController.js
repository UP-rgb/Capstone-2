const { Op } = require('sequelize');
const {
  Incident, Device, User, Alert, SecurityEvent, IncidentComment, Evidence, IncidentAssignment,
} = require('../models');
const { HttpError, asyncHandler, parsePaging, paged } = require('../utils/http');
const { scopeWhere, canSeeDevice } = require('../utils/scope');
const { INCIDENT_STATUS, SEVERITIES } = require('../utils/constants');
const { addTimeline } = require('../services/incidentService');
const playbooks = require('../services/playbooks');
const { audit } = require('../utils/audit');
const socket = require('../services/socket');

const baseInclude = [
  { model: Device, as: 'device', attributes: ['id', 'name', 'type', 'ipAddress', 'ownerId'] },
  { model: User, as: 'assignee', attributes: ['id', 'username', 'fullName'] },
];

exports.list = asyncHandler(async (req, res) => {
  const { status, severity, attackType, q, technique } = req.query;
  const paging = parsePaging(req.query, 25, 200);
  const where = {};
  if (status === 'active') where.status = { [Op.notIn]: ['RESOLVED', 'CLOSED'] };
  else if (status && INCIDENT_STATUS.includes(status)) where.status = status;
  if (severity && SEVERITIES.includes(severity)) where.severity = severity;
  if (attackType) where.attackType = attackType;
  if (technique) where.mitreTechnique = technique;
  if (q) {
    where[Op.or] = [
      { title: { [Op.iLike]: `%${q}%` } }, { reference: { [Op.iLike]: `%${q}%` } }, { sourceIP: { [Op.iLike]: `%${q}%` } },
    ];
  }
  const { rows, count } = await Incident.findAndCountAll({
    where: await scopeWhere(req.user, where), include: baseInclude,
    attributes: { exclude: ['timeline', 'evidence'] },
    order: [['lastSeen', 'DESC']], limit: paging.limit, offset: paging.offset,
  });
  res.json(paged(rows, count, paging));
});

const load = async (req, include = baseInclude) => {
  const incident = await Incident.findByPk(req.params.id, { include });
  if (!incident || !(await canSeeDevice(req.user, incident.deviceId))) throw new HttpError(404, 'Incident not found');
  return incident;
};

exports.get = asyncHandler(async (req, res) => {
  const incident = await load(req, [
    ...baseInclude,
    { model: Alert, as: 'alerts' },
    { model: IncidentComment, as: 'comments' },
    { model: Evidence, as: 'evidenceItems' },
    { model: IncidentAssignment, as: 'assignments', include: [{ model: User, as: 'user', attributes: ['id', 'username', 'fullName'] }] },
  ]);
  const events = await SecurityEvent.findAll({
    where: { incidentId: incident.id }, order: [['timestamp', 'DESC']], limit: 200,
  });
  const json = incident.toJSON();
  json.comments.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  json.assignments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ data: { ...json, events, playbook: playbooks[incident.attackType] || null } });
});

// FR11: PATCH /api/incidents/:id/status { status, note }
exports.updateStatus = asyncHandler(async (req, res) => {
  const incident = await load(req);
  const { status, note } = req.body;
  if (!INCIDENT_STATUS.includes(status)) throw new HttpError(400, `status must be one of ${INCIDENT_STATUS.join(', ')}`);
  if (req.user.role !== 'ADMIN') {
    if (status === 'CLOSED') throw new HttpError(403, 'Only an administrator can close an incident');
    if (incident.status === 'CLOSED') throw new HttpError(403, 'Only an administrator can reopen a closed incident');
  }
  if (status === incident.status) return res.json({ data: incident });

  const msg = `Status changed from ${incident.status} to ${status}${note ? `: ${String(note).slice(0, 500)}` : ''}`;
  await incident.update({
    status,
    resolvedAt: ['RESOLVED', 'CLOSED'].includes(status) ? (incident.resolvedAt || new Date()) : null,
    timeline: addTimeline(incident, 'status', msg, req.user.username),
  });
  if (['RESOLVED', 'CLOSED'].includes(status)) {
    await Alert.update({ status: 'RESOLVED' }, { where: { incidentId: incident.id, status: { [Op.in]: ['NEW', 'ACKNOWLEDGED'] } } });
  }
  audit(req, 'incident.status_changed', 'Incident', incident.id, { message: msg, status });
  socket.emitScoped('incident_updated', { id: incident.id, reference: incident.reference, status }, incident.device && incident.device.ownerId);
  res.json({ data: incident });
});

// PATCH /api/incidents/:id/assign { userId } (admin)
exports.assign = asyncHandler(async (req, res) => {
  const incident = await load(req);
  const userId = req.body.userId || null;
  const assignee = userId ? await User.findByPk(userId) : null;
  if (userId && !assignee) throw new HttpError(400, 'User not found');
  if (userId === incident.assignedTo) return res.json({ data: incident });
  await IncidentAssignment.create({
    incidentId: incident.id, userId, assignedById: req.user.id, assignedByUsername: req.user.username,
    note: req.body.note ? String(req.body.note).slice(0, 500) : null,
  });
  await incident.update({
    assignedTo: userId,
    timeline: addTimeline(incident, 'assignment', assignee ? `Assigned to ${assignee.username}` : 'Unassigned', req.user.username),
  });
  audit(req, 'incident.assigned', 'Incident', incident.id, { userId });
  res.json({ data: await load(req) });
});

// POST /api/incidents/:id/comments { comment }
exports.addComment = asyncHandler(async (req, res) => {
  const incident = await load(req);
  const comment = String(req.body.comment || '').trim();
  if (!comment) throw new HttpError(400, 'Write a comment first');
  if (comment.length > 5000) throw new HttpError(400, 'Comment is too long (5000 characters max)');
  const row = await IncidentComment.create({ incidentId: incident.id, userId: req.user.id, username: req.user.username, comment });
  await incident.update({ timeline: addTimeline(incident, 'comment', `Comment added`, req.user.username) });
  audit(req, 'incident.commented', 'Incident', incident.id);
  res.status(201).json({ data: row });
});

// POST /api/incidents/:id/evidence { title, type, content }
exports.addEvidence = asyncHandler(async (req, res) => {
  const incident = await load(req);
  const title = String(req.body.title || '').trim();
  if (!title) throw new HttpError(400, 'Give the evidence a title');
  const row = await Evidence.create({
    incidentId: incident.id, userId: req.user.id, username: req.user.username, title: title.slice(0, 200),
    type: ['note', 'log', 'indicator', 'screenshot-ref'].includes(req.body.type) ? req.body.type : 'note',
    content: String(req.body.content || '').slice(0, 20000),
  });
  await incident.update({ timeline: addTimeline(incident, 'evidence', `Evidence added: ${row.title}`, req.user.username) });
  audit(req, 'incident.evidence_added', 'Incident', incident.id, { title: row.title });
  res.status(201).json({ data: row });
});
