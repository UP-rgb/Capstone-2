const { Device, User } = require('../models');
const { HttpError, asyncHandler } = require('../utils/http');
const { validate } = require('../utils/validate');
const { DEVICE_TYPES, DEVICE_STATUS } = require('../utils/constants');
const { generateApiKey, hashApiKey, keyPrefix } = require('../utils/apiKey');
const { isIP } = require('../utils/ip');
const { audit } = require('../utils/audit');

const STALE_MINUTES = 15;

const rules = {
  name: { required: true, type: 'string', max: 100 },
  hostname: { type: 'string', max: 160 },
  type: { required: true, enum: DEVICE_TYPES },
  ipAddress: { type: 'string', check: isIP, message: 'must be a valid IPv4 or IPv6 address' },
  location: { type: 'string', max: 120 },
  status: { enum: DEVICE_STATUS },
  ownerId: { type: 'string' },
};

// NFR4: a device is "stale" if it has not sent a heartbeat/event recently.
const withHealth = (d) => {
  const json = d.toJSON();
  delete json.apiKeyHash;
  const last = json.lastHeartbeat ? new Date(json.lastHeartbeat).getTime() : 0;
  json.health = json.status === 'DISABLED' ? 'disabled'
    : !last ? 'never_seen'
      : (Date.now() - last) > STALE_MINUTES * 60 * 1000 ? 'stale' : 'online';
  return json;
};

const checkOwner = async (ownerId) => {
  if (!ownerId) return;
  const owner = await User.findByPk(ownerId);
  if (!owner) throw new HttpError(400, 'Selected owner does not exist');
};

exports.list = asyncHandler(async (req, res) => {
  const where = req.user.role === 'ADMIN' ? {} : { ownerId: req.user.id };
  const devices = await Device.findAll({
    where,
    order: [['createdAt', 'ASC']],
    include: [{ model: User, as: 'owner', attributes: ['id', 'username', 'organization'] }],
  });
  res.json({ data: devices.map(withHealth) });
});

exports.get = asyncHandler(async (req, res) => {
  const device = await Device.findByPk(req.params.id, {
    include: [{ model: User, as: 'owner', attributes: ['id', 'username', 'organization'] }],
  });
  if (!device || (req.user.role !== 'ADMIN' && device.ownerId !== req.user.id)) throw new HttpError(404, 'Device not found');
  res.json({ data: withHealth(device) });
});

// FR2: register a device; the API key is returned ONCE.
exports.create = asyncHandler(async (req, res) => {
  const data = validate(req.body, rules);
  await checkOwner(data.ownerId);
  const apiKey = generateApiKey();
  const device = await Device.create({ ...data, apiKeyHash: hashApiKey(apiKey), apiKeyPrefix: keyPrefix(apiKey) });
  audit(req, 'device.created', 'Device', device.id, { name: device.name, type: device.type });
  res.status(201).json({ data: withHealth(device), apiKey, notice: 'Store this API key now. It will not be shown again.' });
});

exports.update = asyncHandler(async (req, res) => {
  const device = await Device.findByPk(req.params.id);
  if (!device) throw new HttpError(404, 'Device not found');
  const data = validate(req.body, rules, { partial: true });
  if ('ownerId' in req.body && !req.body.ownerId) data.ownerId = null;
  await checkOwner(data.ownerId);
  await device.update(data);
  audit(req, 'device.updated', 'Device', device.id, { fields: Object.keys(data) });
  res.json({ data: withHealth(device) });
});

exports.regenerateKey = asyncHandler(async (req, res) => {
  const device = await Device.findByPk(req.params.id);
  if (!device) throw new HttpError(404, 'Device not found');
  const apiKey = generateApiKey();
  await device.update({ apiKeyHash: hashApiKey(apiKey), apiKeyPrefix: keyPrefix(apiKey) });
  audit(req, 'device.key_regenerated', 'Device', device.id, { name: device.name });
  res.json({ data: withHealth(device), apiKey, notice: 'The previous key no longer works. Update the device configuration.' });
});

exports.remove = asyncHandler(async (req, res) => {
  const device = await Device.findByPk(req.params.id);
  if (!device) throw new HttpError(404, 'Device not found');
  await device.destroy();
  audit(req, 'device.deleted', 'Device', req.params.id, { name: device.name });
  res.json({ message: 'Device deleted' });
});
