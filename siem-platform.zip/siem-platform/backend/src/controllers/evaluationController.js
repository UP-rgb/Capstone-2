const { Op, QueryTypes } = require('sequelize');
const { sequelize, Alert } = require('../models');
const { asyncHandler } = require('../utils/http');
const { parseRange } = require('../services/reporting');
const { detectionMetrics, analystFalsePositiveRate, latencyStats } = require('../services/evaluation');
const metrics = require('../services/metrics');
const config = require('../config');

// GET /api/evaluation?runId=&from=&to=  (admin)
// Detection rate and false-positive rate from labelled simulator traffic, alert latency
// from stored alerts, and live pipeline timings (Sections 1.2, 4.3, 4.5, 5.3).
exports.metrics = asyncHandler(async (req, res) => {
  const { from, to } = parseRange({ from: req.query.from || new Date(Date.now() - 30 * 86400000).toISOString(), to: req.query.to });
  const runId = req.query.runId ? String(req.query.runId).slice(0, 64) : null;

  const runs = await sequelize.query(
    `SELECT raw->'simulation'->>'runId' AS "runId", MIN("timestamp") AS "startedAt", MAX("timestamp") AS "endedAt",
            COUNT(*)::int AS events,
            COUNT(*) FILTER (WHERE raw->'simulation'->>'expected' IS NULL)::int AS "benignEvents",
            COUNT(DISTINCT raw->'simulation'->>'scenario')::int AS scenarios
       FROM security_events
      WHERE raw->'simulation' IS NOT NULL AND "timestamp" BETWEEN :from AND :to
      GROUP BY 1 ORDER BY 2 DESC LIMIT 50`,
    { replacements: { from, to }, type: QueryTypes.SELECT },
  );

  const rows = await sequelize.query(
    `SELECT raw->'simulation'->>'runId' AS "runId", raw->'simulation'->>'scenario' AS scenario,
            raw->'simulation'->>'expected' AS expected, "attackType"
       FROM security_events
      WHERE raw->'simulation' IS NOT NULL AND "timestamp" BETWEEN :from AND :to
        ${runId ? `AND raw->'simulation'->>'runId' = :runId` : ''}`,
    { replacements: { from, to, runId }, type: QueryTypes.SELECT },
  );

  // Alert latency: alerts created in the period, or in the selected run's time window.
  let alertWindow = { [Op.between]: [from, to] };
  const run = runId && runs.find((r) => r.runId === runId);
  if (run) alertWindow = { [Op.between]: [new Date(run.startedAt), new Date(new Date(run.endedAt).getTime() + 60000)] };

  const [latencies, statusRows] = await Promise.all([
    Alert.findAll({ where: { createdAt: alertWindow, detectionLatencyMs: { [Op.ne]: null } }, attributes: ['detectionLatencyMs'], raw: true }),
    Alert.findAll({ where: { createdAt: alertWindow }, attributes: ['status', [sequelize.fn('COUNT', '*'), 'count']], group: ['status'], raw: true }),
  ]);

  res.json({
    period: { from, to },
    runId,
    runs,
    detection: detectionMetrics(rows),
    analystFalsePositives: analystFalsePositiveRate(Object.fromEntries(statusRows.map((r) => [r.status, Number(r.count)]))),
    alertLatencyMs: latencyStats(latencies.map((a) => a.detectionLatencyMs)),
    pipeline: metrics.summary(),
    thresholds: config.detection,
  });
});
