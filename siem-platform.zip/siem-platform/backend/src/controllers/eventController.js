const { Op } = require('sequelize');
const { SecurityEvent, Device, IOCMatch, IOC, Incident } = require('../models');
const { HttpError, asyncHandler, parsePaging, paged } = require('../utils/http');
const { scopeWhere, canSeeDevice } = require('../utils/scope');
const { SEVERITIES } = require('../utils/constants');

// FR12: searchable event history. GET /api/events?q=&eventType=&severity=&sourceIP=&deviceId=&from=&to=&detectedOnly=true
exports.list = asyncHandler(async (req, res) => {
  const { q, eventType, severity, sourceIP, deviceId, attackType, from, to, detectedOnly } = req.query;
  const paging = parsePaging(req.query, 50, 500);
  const where = {};
  if (eventType) where.eventType = eventType;
  if (severity && SEVERITIES.includes(severity)) where.severity = severity;
  if (sourceIP) where.sourceIP = sourceIP;
  if (deviceId) where.deviceId = deviceId;
  if (attackType) where.attackType = attackType;
  if (detectedOnly === 'true') where.attackType = { [Op.ne]: null };
  if (from || to) {
    where.timestamp = {};
    if (from) where.timestamp[Op.gte] = new Date(from);
    if (to) where.timestamp[Op.lte] = new Date(to);
  }
  if (q) {
    const like = { [Op.iLike]: `%${q}%` };
    where[Op.or] = [{ eventType: like }, { username: like }, { message: like }, { sourceIP: like }, { destinationIP: like }];
  }

  const { rows, count } = await SecurityEvent.findAndCountAll({
    where: await scopeWhere(req.user, where),
    include: [{ model: Device, as: 'device', attributes: ['id', 'name', 'type'] }],
    order: [['timestamp', 'DESC']],
    limit: paging.limit,
    offset: paging.offset,
  });
  res.json(paged(rows, count, paging));
});

exports.get = asyncHandler(async (req, res) => {
  const event = await SecurityEvent.findByPk(req.params.id, {
    include: [
      { model: Device, as: 'device', attributes: ['id', 'name', 'type', 'ipAddress'] },
      { model: Incident, as: 'incident', attributes: ['id', 'reference', 'title', 'status'] },
      { model: IOCMatch, as: 'iocMatches', include: [{ model: IOC, as: 'ioc' }] },
    ],
  });
  if (!event || !(await canSeeDevice(req.user, event.deviceId))) throw new HttpError(404, 'Event not found');
  res.json({ data: event });
});
