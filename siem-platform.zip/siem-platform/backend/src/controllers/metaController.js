const mitreMapper = require('../services/mitreMapper');
const playbooks = require('../services/playbooks');
const config = require('../config');

exports.mitre = (req, res) => res.json({ data: mitreMapper.list(), tacticOrder: mitreMapper.TACTIC_ORDER });
exports.playbooks = (req, res) => res.json({ data: playbooks });
exports.detectionConfig = (req, res) => res.json({ data: config.detection });
