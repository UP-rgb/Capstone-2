const { Op } = require('sequelize');
const { ThreatIntel, IOC } = require('../models');
const { HttpError, asyncHandler, parsePaging, paged } = require('../utils/http');
const threatIntel = require('../services/threatIntelService');
const { isIP } = require('../utils/ip');
const { audit } = require('../utils/audit');

exports.list = asyncHandler(async (req, res) => {
  const { q, source, severity } = req.query;
  const paging = parsePaging(req.query, 50, 500);
  const where = {};
  if (source) where.source = source;
  if (severity) where.severity = severity;
  if (q) where.indicator = { [Op.iLike]: `%${q}%` };
  const { rows, count } = await ThreatIntel.findAndCountAll({
    where, order: [['lastChecked', 'DESC']], limit: paging.limit, offset: paging.offset,
    attributes: { exclude: ['raw'] },
  });
  res.json(paged(rows, count, paging));
});

exports.status = asyncHandler(async (req, res) => {
  const [total, bySource] = await Promise.all([
    ThreatIntel.count(),
    ThreatIntel.findAll({ attributes: ['source', [ThreatIntel.sequelize.fn('COUNT', '*'), 'count']], group: ['source'], raw: true }),
  ]);
  res.json({ ...threatIntel.status(), total, bySource });
});

const guessType = (v) => {
  if (isIP(v)) return 'IP';
  if (/^([a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$/i.test(v)) return 'HASH';
  if (/^https?:\/\//i.test(v)) return 'URL';
  if (/^(?=.{1,253}$)(?!-)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$/i.test(v)) return 'DOMAIN';
  return null;
};

// POST /api/threat-intel/lookup { indicator } — on-demand enrichment (admin)
exports.lookup = asyncHandler(async (req, res) => {
  const value = String(req.body.indicator || '').trim().toLowerCase();
  const type = guessType(value);
  if (!type) throw new HttpError(400, 'Enter an IP address, domain, URL or file hash (MD5/SHA-1/SHA-256)');
  const results = await threatIntel.lookup({ type, value }, { force: true });
  const all = await ThreatIntel.findAll({ where: { indicator: value }, attributes: { exclude: ['raw'] } });
  const ioc = await IOC.findOne({ where: { value } });
  audit(req, 'threat_intel.lookup', 'ThreatIntel', null, { indicator: value, type });
  res.json({ indicator: value, type, results: all, flagged: results.length > 0, ioc, ...threatIntel.status() });
});
