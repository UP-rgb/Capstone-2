const { Op } = require('sequelize');
const { IOC } = require('../models');
const { HttpError, asyncHandler, parsePaging, paged } = require('../utils/http');
const { validate } = require('../utils/validate');
const { IOC_TYPES, CONFIDENCE, SEVERITIES, ATTACK_TYPES } = require('../utils/constants');
const { isIP } = require('../utils/ip');
const { audit } = require('../utils/audit');

const VALUE_CHECK = {
  IP: isIP,
  HASH: (v) => /^([a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$/i.test(v),
  DOMAIN: (v) => /^(?=.{1,253}$)(?!-)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$/i.test(v),
  URL: (v) => /^https?:\/\/\S+$/i.test(v),
  EMAIL: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
};

const rules = {
  type: { required: true, enum: IOC_TYPES },
  value: { required: true, type: 'string', max: 512 },
  confidence: { enum: CONFIDENCE },
  severity: { enum: SEVERITIES },
  attackType: { enum: ATTACK_TYPES },
  source: { type: 'string', max: 120 },
  description: { type: 'string', max: 2000 },
  isActive: { type: 'boolean' },
};

const checkValue = (type, value) => {
  if (!VALUE_CHECK[type](value.trim())) throw new HttpError(400, `"${value}" is not a valid ${type}`);
};

exports.list = asyncHandler(async (req, res) => {
  const { type, q, active } = req.query;
  const paging = parsePaging(req.query, 50, 500);
  const where = {};
  if (type && IOC_TYPES.includes(type)) where.type = type;
  if (active === 'true') where.isActive = true;
  if (q) where.value = { [Op.iLike]: `%${q}%` };
  const { rows, count } = await IOC.findAndCountAll({ where, order: [['createdAt', 'DESC']], limit: paging.limit, offset: paging.offset });
  res.json(paged(rows, count, paging));
});

exports.create = asyncHandler(async (req, res) => {
  const data = validate(req.body, rules);
  checkValue(data.type, data.value);
  const ioc = await IOC.create(data);
  audit(req, 'ioc.created', 'IOC', ioc.id, { type: ioc.type, value: ioc.value });
  res.status(201).json({ data: ioc });
});

// POST /api/ioc/bulk { items: [{type, value, ...}] } — skips duplicates and reports invalid rows
exports.bulk = asyncHandler(async (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items.slice(0, 1000) : [];
  if (!items.length) throw new HttpError(400, 'Provide items to import');
  const created = [];
  const skipped = [];
  for (const [i, item] of items.entries()) {
    try {
      const data = validate(item, rules);
      checkValue(data.type, data.value);
      const [ioc, isNew] = await IOC.findOrCreate({ where: { value: data.value.trim().toLowerCase() }, defaults: data });
      if (isNew) created.push(ioc); else skipped.push({ row: i + 1, reason: 'already exists' });
    } catch (e) {
      skipped.push({ row: i + 1, reason: e.message === 'Validation failed' ? JSON.stringify(e.details) : e.message });
    }
  }
  audit(req, 'ioc.bulk_import', 'IOC', null, { created: created.length, skipped: skipped.length });
  res.status(201).json({ created: created.length, skipped });
});

exports.update = asyncHandler(async (req, res) => {
  const ioc = await IOC.findByPk(req.params.id);
  if (!ioc) throw new HttpError(404, 'IOC not found');
  const data = validate(req.body, rules, { partial: true });
  if (data.value) checkValue(data.type || ioc.type, data.value);
  await ioc.update(data);
  audit(req, 'ioc.updated', 'IOC', ioc.id, { fields: Object.keys(data) });
  res.json({ data: ioc });
});

exports.remove = asyncHandler(async (req, res) => {
  const ioc = await IOC.findByPk(req.params.id);
  if (!ioc) throw new HttpError(404, 'IOC not found');
  await ioc.destroy();
  audit(req, 'ioc.deleted', 'IOC', req.params.id, { value: ioc.value });
  res.json({ message: 'IOC deleted' });
});
