const { processEvent } = require('../services/pipeline');
const { HttpError, asyncHandler } = require('../utils/http');

const MAX_BATCH = 100;

const checkPayload = (p, i) => {
  if (!p || typeof p !== 'object' || Array.isArray(p)) throw new HttpError(400, `Event ${i} must be a JSON object`);
  if (p.raw !== undefined && (typeof p.raw !== 'object' || Array.isArray(p.raw))) throw new HttpError(400, `Event ${i}: raw must be an object`);
  if (!p.eventType && !(p.raw && (p.raw.EventID || p.raw.eventId))) {
    throw new HttpError(400, `Event ${i}: eventType is required (or raw.EventID for Windows events)`);
  }
};

// FR3: POST /api/ingest  — single event object, an array, or { events: [...] }
exports.ingest = asyncHandler(async (req, res) => {
  const body = req.body;
  const events = Array.isArray(body) ? body : Array.isArray(body.events) ? body.events : [body];
  if (!events.length) throw new HttpError(400, 'No events supplied');
  if (events.length > MAX_BATCH) throw new HttpError(413, `Send at most ${MAX_BATCH} events per request`);
  events.forEach(checkPayload);

  const results = [];
  // Sequential so window-based rules see earlier events in the same batch.
  for (const e of events) results.push(await processEvent(req.device, e));

  const single = events.length === 1 && !Array.isArray(body) && !Array.isArray(body.events);
  res.status(201).json(single
    ? { status: 'ingested', ...results[0] }
    : { status: 'ingested', count: results.length, results });
});

// POST /api/ingest/heartbeat — deviceAuth already updated lastHeartbeat
exports.heartbeat = asyncHandler(async (req, res) => {
  res.json({ status: 'ok', device: req.device.name, lastHeartbeat: req.device.lastHeartbeat });
});
