const { Op } = require('sequelize');
const { AuditLog } = require('../models');
const { asyncHandler, parsePaging, paged } = require('../utils/http');

exports.list = asyncHandler(async (req, res) => {
  const { action, q } = req.query;
  const paging = parsePaging(req.query, 50, 500);
  const where = {};
  if (action) where.action = { [Op.iLike]: `${action}%` };
  if (q) where[Op.or] = [{ username: { [Op.iLike]: `%${q}%` } }, { action: { [Op.iLike]: `%${q}%` } }];
  const { rows, count } = await AuditLog.findAndCountAll({ where, order: [['createdAt', 'DESC']], limit: paging.limit, offset: paging.offset });
  res.json(paged(rows, count, paging));
});
