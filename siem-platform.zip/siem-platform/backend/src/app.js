const path = require('path');
const fs = require('fs');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const config = require('./config');
const routes = require('./routes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: config.corsOrigin, credentials: true }));
app.use(express.json({ limit: '1mb' }));
if (config.env !== 'test') app.use(morgan(config.env === 'production' ? 'combined' : 'dev'));

// Health check used in the lab (Section 3.1.4): GET http://<siem>:5000/
app.get('/', (req, res, next) => {
  if (req.accepts(['json', 'html']) === 'html' && fs.existsSync(path.join(__dirname, '../../frontend/dist/index.html'))) return next();
  return res.json({ system: 'Enterprise SIEM Platform', status: 'Running', timestamp: new Date().toISOString() });
});

app.use('/api', routes);

// Serve the built React dashboard (npm run build in /frontend) from the same port.
const dist = path.join(__dirname, '../../frontend/dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^\/(?!api|socket\.io).*/, (req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use('/api', notFound);
app.use(notFound);
app.use(errorHandler);

module.exports = app;
