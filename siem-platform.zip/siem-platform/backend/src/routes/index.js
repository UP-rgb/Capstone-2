const express = require('express');
const { authenticate } = require('../middleware/auth');
const { adminOnly } = require('../middleware/rbac');
const { deviceAuth } = require('../middleware/deviceAuth');
const { loginLimiter, ingestLimiter, apiLimiter } = require('../middleware/rateLimits');

const auth = require('../controllers/authController');
const users = require('../controllers/userController');
const devices = require('../controllers/deviceController');
const ingest = require('../controllers/ingestController');
const events = require('../controllers/eventController');
const alerts = require('../controllers/alertController');
const incidents = require('../controllers/incidentController');
const ioc = require('../controllers/iocController');
const intel = require('../controllers/threatIntelController');
const dashboard = require('../controllers/dashboardController');
const auditLog = require('../controllers/auditController');
const meta = require('../controllers/metaController');
const reports = require('../controllers/reportController');
const evaluation = require('../controllers/evaluationController');

const router = express.Router();

router.get('/health', (req, res) => res.json({ system: 'Enterprise SIEM Platform', status: 'Running', timestamp: new Date().toISOString() }));

// ---- Machine-to-machine ingestion (x-api-key) ----
router.post('/ingest', ingestLimiter, deviceAuth, ingest.ingest);
router.post('/ingest/heartbeat', ingestLimiter, deviceAuth, ingest.heartbeat);

// ---- Dashboard auth ----
router.post('/auth/login', loginLimiter, auth.login);

// Everything below requires a signed-in dashboard user.
router.use(apiLimiter, authenticate);

router.get('/auth/me', auth.me);
router.post('/auth/change-password', auth.changePassword);

// Shared (scoped: ADMIN sees all, CLIENT sees only their devices' data)
router.get('/dashboard/stats', dashboard.stats);
router.get('/events', events.list);
router.get('/events/:id', events.get);
router.get('/alerts', alerts.list);
router.get('/alerts/:id', alerts.get);
router.patch('/alerts/:id/status', alerts.updateStatus);
router.get('/incidents', incidents.list);
router.get('/incidents/:id', incidents.get);
router.patch('/incidents/:id/status', incidents.updateStatus);
router.post('/incidents/:id/comments', incidents.addComment);
router.post('/incidents/:id/evidence', incidents.addEvidence);
router.get('/devices', devices.list);
router.get('/devices/:id', devices.get);
router.get('/threat-intel', intel.list);
router.get('/meta/mitre', meta.mitre);
router.get('/meta/playbooks', meta.playbooks);
router.get('/reports/summary', reports.summary);
router.get('/reports/export/:dataset', reports.exportCsv);

// Administrator only
router.patch('/alerts/:id/assign', adminOnly, alerts.assign);
router.patch('/incidents/:id/assign', adminOnly, incidents.assign);
router.post('/devices', adminOnly, devices.create);
router.put('/devices/:id', adminOnly, devices.update);
router.post('/devices/:id/regenerate-key', adminOnly, devices.regenerateKey);
router.delete('/devices/:id', adminOnly, devices.remove);
router.get('/users', adminOnly, users.list);
router.post('/users', adminOnly, users.create);
router.put('/users/:id', adminOnly, users.update);
router.delete('/users/:id', adminOnly, users.remove);
router.get('/ioc', adminOnly, ioc.list);
router.post('/ioc', adminOnly, ioc.create);
router.post('/ioc/bulk', adminOnly, ioc.bulk);
router.put('/ioc/:id', adminOnly, ioc.update);
router.delete('/ioc/:id', adminOnly, ioc.remove);
router.get('/threat-intel/status', adminOnly, intel.status);
router.post('/threat-intel/lookup', adminOnly, intel.lookup);
router.get('/audit', adminOnly, auditLog.list);
router.get('/meta/detection-config', adminOnly, meta.detectionConfig);
router.get('/evaluation', adminOnly, evaluation.metrics);

module.exports = router;
