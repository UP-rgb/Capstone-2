const crypto = require('crypto');

// NFR1: device keys come from a CSPRNG; only a SHA-256 digest is persisted.
const generateApiKey = () => `siem_${crypto.randomBytes(32).toString('hex')}`;
const hashApiKey = (key) => crypto.createHash('sha256').update(String(key)).digest('hex');
const keyPrefix = (key) => `${key.slice(0, 12)}…`;

module.exports = { generateApiKey, hashApiKey, keyPrefix };
