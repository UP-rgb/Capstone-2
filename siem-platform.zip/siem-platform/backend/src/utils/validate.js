const { HttpError } = require('./http');

// Minimal declarative validator: rules = { field: { required, type, enum, max, min, pattern } }
const validate = (body, rules, { partial = false } = {}) => {
  const errors = {};
  const out = {};
  Object.entries(rules).forEach(([field, r]) => {
    const v = body ? body[field] : undefined;
    const missing = v === undefined || v === null || v === '';
    if (missing) {
      if (r.required && !partial) errors[field] = 'is required';
      return;
    }
    if (r.type === 'string' && typeof v !== 'string') { errors[field] = 'must be text'; return; }
    if (r.type === 'number' && (typeof v !== 'number' || Number.isNaN(v))) { errors[field] = 'must be a number'; return; }
    if (r.type === 'boolean' && typeof v !== 'boolean') { errors[field] = 'must be true or false'; return; }
    if (r.type === 'object' && (typeof v !== 'object' || Array.isArray(v))) { errors[field] = 'must be an object'; return; }
    if (r.enum && !r.enum.includes(v)) { errors[field] = `must be one of ${r.enum.join(', ')}`; return; }
    if (r.max && typeof v === 'string' && v.length > r.max) { errors[field] = `must be at most ${r.max} characters`; return; }
    if (r.min && typeof v === 'string' && v.length < r.min) { errors[field] = `must be at least ${r.min} characters`; return; }
    if (r.pattern && !r.pattern.test(v)) { errors[field] = r.message || 'has an invalid format'; return; }
    if (r.check && !r.check(v)) { errors[field] = r.message || 'is invalid'; return; }
    out[field] = typeof v === 'string' ? v.trim() : v;
  });
  if (Object.keys(errors).length) throw new HttpError(400, 'Validation failed', errors);
  return out;
};

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// At least 8 chars incl. upper, lower and a digit
const STRONG_PASSWORD = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

module.exports = { validate, EMAIL, STRONG_PASSWORD };
