const net = require('net');

const isIP = (v) => typeof v === 'string' && net.isIP(v.trim()) !== 0;

// RFC1918, loopback, link-local, CGNAT, documentation & unique-local ranges are treated
// as "not routable" so they are never sent to external threat-intel APIs.
const isPrivateIP = (ip) => {
  if (!isIP(ip)) return false;
  const v = ip.trim();
  if (net.isIPv6(v)) {
    const l = v.toLowerCase();
    return l === '::1' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80');
  }
  const [a, b] = v.split('.').map(Number);
  return a === 10
    || a === 127
    || (a === 172 && b >= 16 && b <= 31)
    || (a === 192 && b === 168)
    || (a === 169 && b === 254)
    || (a === 100 && b >= 64 && b <= 127)
    || a === 0;
};

const isPublicIP = (ip) => isIP(ip) && !isPrivateIP(ip);

module.exports = { isIP, isPrivateIP, isPublicIP };
