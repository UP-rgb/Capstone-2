const { AuditLog } = require('../models');

// Fire-and-forget audit record; never blocks or breaks the request.
const audit = (req, action, entityType, entityId, details = {}) => {
  AuditLog.create({
    userId: req.user ? req.user.id : null,
    username: req.user ? req.user.username : (req.device ? `device:${req.device.name}` : 'system'),
    action,
    entityType,
    entityId: entityId ? String(entityId) : null,
    details,
    ip: req.ip,
  }).catch((err) => console.error('[audit] failed:', err.message));
};

module.exports = { audit };
