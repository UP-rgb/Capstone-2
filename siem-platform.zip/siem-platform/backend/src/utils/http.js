class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

// Wraps async route handlers so rejected promises reach the error middleware.
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const parsePaging = (query, defaultLimit = 25, maxLimit = 200) => {
  const limit = Math.min(Math.max(parseInt(query.limit, 10) || defaultLimit, 1), maxLimit);
  const page = Math.max(parseInt(query.page, 10) || 1, 1);
  return { limit, offset: (page - 1) * limit, page };
};

const paged = (rows, count, { page, limit }) => ({
  data: rows,
  pagination: { page, limit, total: count, pages: Math.max(Math.ceil(count / limit), 1) },
});

module.exports = { HttpError, asyncHandler, parsePaging, paged };
