// Shared enumerations used by models, validation and services.
module.exports = {
  ROLES: ['ADMIN', 'CLIENT'],
  SEVERITIES: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'],
  CONFIDENCE: ['LOW', 'MEDIUM', 'HIGH'],
  DEVICE_TYPES: ['WINDOWS', 'LINUX', 'FIREWALL', 'SERVER', 'ROUTER', 'APPLICATION'],
  DEVICE_STATUS: ['ACTIVE', 'INACTIVE', 'DISABLED'],
  IOC_TYPES: ['IP', 'DOMAIN', 'URL', 'HASH', 'EMAIL'],
  ALERT_STATUS: ['NEW', 'ACKNOWLEDGED', 'RESOLVED', 'FALSE_POSITIVE'],
  // FR11 incident lifecycle, in order
  INCIDENT_STATUS: ['OPEN', 'ACKNOWLEDGED', 'INVESTIGATING', 'CONTAINED', 'RESOLVED', 'CLOSED'],
  ATTACK_TYPES: [
    'brute_force', 'phishing', 'malware', 'ddos',
    'data_exfiltration', 'port_scan', 'ioc_reputation', 'powershell',
  ],
};
