const { Op } = require('sequelize');
const { Device } = require('../models');

// Returns the device IDs a user may see. ADMIN => null (no restriction).
// CLIENT users only see data produced by devices assigned to them.
const visibleDeviceIds = async (user) => {
  if (user.role === 'ADMIN') return null;
  const devices = await Device.findAll({ where: { ownerId: user.id }, attributes: ['id'] });
  return devices.map((d) => d.id);
};

// Adds a deviceId restriction to a where clause for CLIENT users.
const scopeWhere = async (user, where = {}) => {
  const ids = await visibleDeviceIds(user);
  if (ids === null) return where;
  return { ...where, deviceId: { [Op.in]: ids.length ? ids : ['00000000-0000-0000-0000-000000000000'] } };
};

const canSeeDevice = async (user, deviceId) => {
  const ids = await visibleDeviceIds(user);
  return ids === null || ids.includes(deviceId);
};

module.exports = { visibleDeviceIds, scopeWhere, canSeeDevice };
