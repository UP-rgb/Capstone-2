// FR7: deterministic, additive and auditable risk scoring (Section 3.2, Risk-Scoring Model).
//
//   score = base score of the triggering rule
//         + threat-intel severity   (CRITICAL +30 | HIGH +20 | MEDIUM +15 | LOW +5)
//         + matched IOC/intel confidence (HIGH +30 | MEDIUM +20 | LOW +15)
//         + attack-type bonus       (ddos +30 | malware +25 | data_exfiltration +25 | brute_force +20)
//   capped at 100, then banded: CRITICAL >= 90, HIGH >= 70, MEDIUM >= 40, LOW < 40
//
// Every component is returned in `breakdown` and stored with the incident so an analyst
// can see exactly why a score was produced.

const TI_SEVERITY_POINTS = { CRITICAL: 30, HIGH: 20, MEDIUM: 15, LOW: 5 };
const CONFIDENCE_POINTS = { HIGH: 30, MEDIUM: 20, LOW: 15 };
const ATTACK_BONUS = { ddos: 30, malware: 25, data_exfiltration: 25, brute_force: 20 };
const SEVERITY_RANK = { LOW: 1, MEDIUM: 2, HIGH: 3, CRITICAL: 4 };

const band = (score) => {
  if (score >= 90) return 'CRITICAL';
  if (score >= 70) return 'HIGH';
  if (score >= 40) return 'MEDIUM';
  return 'LOW';
};

const highest = (items, key, rank) => items.reduce((best, item) => {
  if (!item || !item[key]) return best;
  if (!best || rank[item[key]] > rank[best[key]]) return item;
  return best;
}, null);

/**
 * @param {object} p
 * @param {number} p.baseScore        base score from the triggering detection rule (0 if none)
 * @param {string} [p.attackType]
 * @param {Array}  [p.threatIntel]    ThreatIntel-like records { severity, confidence }
 * @param {Array}  [p.iocMatches]     IOC records { confidence }
 */
const calculate = ({ baseScore = 0, attackType = null, threatIntel = [], iocMatches = [] }) => {
  const breakdown = [{ factor: 'Detection rule base score', points: baseScore }];

  const topIntel = highest(threatIntel, 'severity', SEVERITY_RANK);
  if (topIntel) {
    breakdown.push({
      factor: `Threat intel severity ${topIntel.severity} (${topIntel.source || 'intel'})`,
      points: TI_SEVERITY_POINTS[topIntel.severity] || 0,
    });
  }

  const confidenceSources = [...iocMatches, ...threatIntel].filter((x) => x && x.confidence);
  const topConfidence = highest(confidenceSources, 'confidence', { LOW: 1, MEDIUM: 2, HIGH: 3 });
  if (topConfidence) {
    breakdown.push({
      factor: `Matched indicator confidence ${topConfidence.confidence}`,
      points: CONFIDENCE_POINTS[topConfidence.confidence] || 0,
    });
  }

  if (attackType && ATTACK_BONUS[attackType]) {
    breakdown.push({ factor: `Attack type bonus (${attackType})`, points: ATTACK_BONUS[attackType] });
  }

  const raw = breakdown.reduce((s, b) => s + b.points, 0);
  const score = Math.max(0, Math.min(100, Math.round(raw)));
  return { score, severity: band(score), breakdown, uncapped: raw };
};

module.exports = { calculate, band, SEVERITY_RANK, TI_SEVERITY_POINTS, CONFIDENCE_POINTS, ATTACK_BONUS };
