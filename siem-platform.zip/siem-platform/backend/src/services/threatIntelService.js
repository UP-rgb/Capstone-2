const { ThreatIntel } = require('../models');
const config = require('../config');
const { isPublicIP } = require('../utils/ip');

const TIMEOUT_MS = 6000;

const fetchJson = async (url, headers) => {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { headers, signal: ctrl.signal });
    if (res.status === 404) return { notFound: true };
    if (res.status === 429) throw new Error('rate limited');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
};

const abuseSeverity = (score) => {
  if (score >= 90) return 'CRITICAL';
  if (score >= 70) return 'HIGH';
  if (score >= 40) return 'MEDIUM';
  if (score > 0) return 'LOW';
  return null;
};
const vtSeverity = (malicious) => {
  if (malicious >= 10) return 'CRITICAL';
  if (malicious >= 5) return 'HIGH';
  if (malicious >= 2) return 'MEDIUM';
  if (malicious >= 1) return 'LOW';
  return null;
};
const confidenceFor = (severity) => ({ CRITICAL: 'HIGH', HIGH: 'HIGH', MEDIUM: 'MEDIUM', LOW: 'LOW' }[severity] || null);

// ---- AbuseIPDB APIv2 /check ----
const queryAbuseIPDB = async (ip) => {
  const data = await fetchJson(
    `https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(ip)}&maxAgeInDays=90`,
    { Key: config.threatIntel.abuseIpdbKey, Accept: 'application/json' },
  );
  const d = data.data || {};
  const score = Number(d.abuseConfidenceScore || 0);
  const severity = abuseSeverity(score);
  return {
    indicator: ip, indicatorType: 'IP', source: 'AbuseIPDB', sourceIP: ip,
    name: `AbuseIPDB reputation for ${ip}`,
    score, severity, confidence: confidenceFor(severity), country: d.countryCode || null,
    summary: `Abuse confidence ${score}%, ${d.totalReports || 0} reports${d.isp ? `, ISP ${d.isp}` : ''}`,
    raw: d,
  };
};

// ---- VirusTotal API v3 ----
const VT_PATH = {
  IP: (v) => `ip_addresses/${encodeURIComponent(v)}`,
  DOMAIN: (v) => `domains/${encodeURIComponent(v)}`,
  HASH: (v) => `files/${encodeURIComponent(v)}`,
  URL: (v) => `urls/${Buffer.from(v).toString('base64url')}`,
};

const queryVirusTotal = async (type, value) => {
  const data = await fetchJson(
    `https://www.virustotal.com/api/v3/${VT_PATH[type](value)}`,
    { 'x-apikey': config.threatIntel.virusTotalKey, Accept: 'application/json' },
  );
  if (data.notFound) {
    return { indicator: value, indicatorType: type, source: 'VirusTotal', score: 0, severity: null, confidence: null,
      name: `VirusTotal: ${value}`, summary: 'Not found in VirusTotal', raw: {} };
  }
  const attrs = (data.data && data.data.attributes) || {};
  const stats = attrs.last_analysis_stats || {};
  const malicious = Number(stats.malicious || 0);
  const severity = vtSeverity(malicious);
  return {
    indicator: value, indicatorType: type, source: 'VirusTotal',
    sourceIP: type === 'IP' ? value : null,
    name: attrs.meaningful_name || `VirusTotal: ${value}`,
    score: malicious, severity, confidence: confidenceFor(severity), country: attrs.country || null,
    summary: `${malicious} malicious / ${stats.suspicious || 0} suspicious of ${Object.values(stats).reduce((a, b) => a + Number(b || 0), 0)} engines`,
    raw: { last_analysis_stats: stats, reputation: attrs.reputation, tags: attrs.tags },
  };
};

const isFresh = (rec) => rec.source === 'LOCAL'
  || (Date.now() - new Date(rec.lastChecked).getTime()) < config.threatIntel.cacheHours * 3600 * 1000;

// Find-then-update keeps one cached row per (indicator, source).
const upsert = async (result) => {
  const values = { ...result, lastChecked: new Date() };
  const existing = await ThreatIntel.findOne({ where: { indicator: result.indicator, source: result.source } });
  return existing ? existing.update(values) : ThreatIntel.create(values);
};

/**
 * FR6: enrich a single indicator. Uses cached/local records first (respecting free-tier
 * rate limits), and only calls the external APIs when THREAT_INTEL_MODE=live and a key exists.
 * Returns an array of ThreatIntel records (one per source) that carry a severity.
 */
const lookup = async ({ type, value }, { force = false, allowExternal = true } = {}) => {
  const mode = config.threatIntel.mode;
  if (mode === 'off') return [];

  const cached = await ThreatIntel.findAll({ where: { indicator: value } });
  const results = cached.filter((r) => force ? r.source === 'LOCAL' : isFresh(r));
  if (mode !== 'live' || !allowExternal) return results.filter((r) => r.severity);

  const tasks = [];
  const have = (src) => results.some((r) => r.source === src);
  if (type === 'IP' && isPublicIP(value) && config.threatIntel.abuseIpdbKey && !have('AbuseIPDB')) {
    tasks.push(queryAbuseIPDB(value));
  }
  const vtType = type === 'IP' && !isPublicIP(value) ? null : type;
  if (vtType && VT_PATH[vtType] && config.threatIntel.virusTotalKey && !have('VirusTotal')) {
    tasks.push(queryVirusTotal(vtType, value));
  }

  const settled = await Promise.allSettled(tasks);
  for (const s of settled) {
    if (s.status === 'fulfilled') results.push(await upsert(s.value));
    else console.warn(`[threat-intel] lookup failed for ${value}: ${s.reason && s.reason.message}`);
  }
  return results.filter((r) => r.severity);
};

/**
 * Enrich several indicators; private IPs are never sent to external services.
 * allowExternal=false limits the lookup to the local cache (used for events with no
 * detection so free-tier API quotas are only spent on events that matter).
 */
const enrich = async (indicators, { allowExternal = true } = {}) => {
  const usable = indicators.filter((i) => ['IP', 'DOMAIN', 'URL', 'HASH'].includes(i.type));
  const all = await Promise.all(usable.map((i) => lookup(i, { allowExternal }).catch(() => [])));
  return all.flat();
};

const status = () => ({
  mode: config.threatIntel.mode,
  virusTotalConfigured: Boolean(config.threatIntel.virusTotalKey),
  abuseIpdbConfigured: Boolean(config.threatIntel.abuseIpdbKey),
  cacheHours: config.threatIntel.cacheHours,
});

module.exports = { lookup, enrich, status };
