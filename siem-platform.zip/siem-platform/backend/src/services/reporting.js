// Pure helpers for SOC reports (use case "Generate SOC Reports", Figure 5).
const { HttpError } = require('../utils/http');
const { describe } = require('./metrics');

const DAY = 86400000;

/** Parses ?from&to (ISO dates). Defaults to the last 7 days; at most one year. */
const parseRange = (query = {}, now = new Date()) => {
  const to = query.to ? new Date(query.to) : now;
  const from = query.from ? new Date(query.from) : new Date(to.getTime() - 7 * DAY);
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) throw new HttpError(400, 'from and to must be valid dates');
  if (from >= to) throw new HttpError(400, 'from must be before to');
  if (to - from > 366 * DAY) throw new HttpError(400, 'Choose a period of one year or less');
  return { from, to };
};

const minutesBetween = (a, b) => Math.max(0, (new Date(b) - new Date(a)) / 60000);

/**
 * Mean time to acknowledge (first analyst status change after opening) and mean time to
 * resolve (opening to RESOLVED/CLOSED), in minutes. Incidents are plain objects with
 * createdAt, resolvedAt and timeline [{ type, at, by }].
 */
const responseTimes = (incidents) => {
  const ack = [];
  const resolve = [];
  incidents.forEach((i) => {
    const firstAction = (i.timeline || []).find((t) => t.type === 'status' || t.type === 'assignment');
    if (firstAction) ack.push(minutesBetween(i.createdAt, firstAction.at));
    if (i.resolvedAt) resolve.push(minutesBetween(i.createdAt, i.resolvedAt));
  });
  const round = (d) => ({ ...d, avg: d.avg === null ? null : Math.round(d.avg), p50: d.p50 === null ? null : Math.round(d.p50), p95: d.p95 === null ? null : Math.round(d.p95), max: d.max === null ? null : Math.round(d.max) });
  return { acknowledgeMinutes: round(describe(ack)), resolveMinutes: round(describe(resolve)) };
};

const countBy = (rows, key, keys) => {
  const out = Object.fromEntries((keys || []).map((k) => [k, 0]));
  rows.forEach((r) => { const k = typeof key === 'function' ? key(r) : r[key]; if (k !== null && k !== undefined) out[k] = (out[k] || 0) + 1; });
  return out;
};

/** RFC 4180 CSV. Cells that could be read as formulas by spreadsheets are prefixed with '. */
const toCsv = (columns, rows) => {
  const cell = (v) => {
    if (v === null || v === undefined) return '';
    let s = v instanceof Date ? v.toISOString() : typeof v === 'object' ? JSON.stringify(v) : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const head = columns.map((c) => cell(c.label)).join(',');
  const body = rows.map((r) => columns.map((c) => cell(typeof c.value === 'function' ? c.value(r) : r[c.value])).join(','));
  return [head, ...body].join('\r\n') + '\r\n';
};

module.exports = { parseRange, responseTimes, countBy, toCsv, minutesBetween };
