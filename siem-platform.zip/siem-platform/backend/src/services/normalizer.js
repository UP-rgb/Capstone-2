const { isIP } = require('../utils/ip');
const { SEVERITIES } = require('../utils/constants');

// Maps well-known Windows Security event IDs to normalised event types.
const WINDOWS_EVENT_TYPES = {
  4624: 'successful_login',
  4625: 'failed_login',
  4634: 'logoff',
  4672: 'privileged_logon',
  4688: 'process_creation',
  4720: 'user_created',
  4740: 'account_locked',
  1102: 'audit_log_cleared',
  4104: 'powershell_script',
};

const pick = (obj, ...keys) => {
  for (const k of keys) {
    if (obj && obj[k] !== undefined && obj[k] !== null && obj[k] !== '') return obj[k];
  }
  return undefined;
};

const cleanIP = (v) => (typeof v === 'string' && isIP(v.trim()) ? v.trim() : null);

/**
 * Normalises an incoming payload from any vendor (pfSense, Windows collector, Linux sensor,
 * custom app) into the SecurityEvent shape. Unknown fields are preserved in `raw`.
 */
const normalize = (payload) => {
  const raw = (payload.raw && typeof payload.raw === 'object') ? payload.raw : {};
  const eventId = Number(pick(raw, 'EventID', 'eventId', 'event_id') ?? pick(payload, 'eventId'));

  let eventType = String(pick(payload, 'eventType', 'event_type') || '').trim().toLowerCase();
  if (!eventType && WINDOWS_EVENT_TYPES[eventId]) eventType = WINDOWS_EVENT_TYPES[eventId];
  if (!eventType) eventType = 'generic';

  let severity = String(payload.severity || '').toUpperCase();
  if (!SEVERITIES.includes(severity)) severity = 'LOW';

  let timestamp = payload.timestamp ? new Date(payload.timestamp) : new Date();
  if (Number.isNaN(timestamp.getTime())) timestamp = new Date();
  // Reject timestamps far in the future (clock skew/tampering) by clamping to now.
  if (timestamp.getTime() > Date.now() + 5 * 60 * 1000) timestamp = new Date();

  const port = Number(pick(payload, 'destinationPort', 'dstPort') ?? pick(raw, 'destinationPort', 'DestinationPort', 'dst_port'));

  return {
    eventType,
    severity,
    timestamp,
    sourceIP: cleanIP(pick(payload, 'sourceIP', 'srcIp', 'source_ip') ?? pick(raw, 'IpAddress', 'SourceAddress', 'src_ip')),
    destinationIP: cleanIP(pick(payload, 'destinationIP', 'dstIp', 'destination_ip') ?? pick(raw, 'DestAddress', 'dst_ip')),
    destinationPort: Number.isInteger(port) && port > 0 && port < 65536 ? port : null,
    username: (pick(payload, 'username', 'user') ?? pick(raw, 'TargetUserName', 'AccountName', 'user')) || null,
    message: (pick(payload, 'message') ?? pick(raw, 'Message', 'message')) || null,
    raw: { ...raw, ...(Number.isFinite(eventId) ? { EventID: eventId } : {}) },
  };
};

module.exports = { normalize, WINDOWS_EVENT_TYPES };
