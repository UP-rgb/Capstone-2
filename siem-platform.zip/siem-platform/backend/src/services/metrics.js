// In-memory pipeline timings (NFR2 performance, Section 4.3). Keeps the most recent
// samples so the evaluation page can show processing time and throughput without a
// database write per event. Resets when the server restarts.
const MAX_SAMPLES = 2000;
const samples = []; // { at, ms, detected }
const startedAt = Date.now();
let total = 0;

const record = (ms, detected) => {
  total += 1;
  samples.push({ at: Date.now(), ms, detected: Boolean(detected) });
  if (samples.length > MAX_SAMPLES) samples.shift();
};

const percentile = (values, p) => {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[idx];
};

const describe = (values) => {
  if (!values.length) return { count: 0, avg: null, p50: null, p95: null, max: null };
  const sum = values.reduce((s, v) => s + v, 0);
  return {
    count: values.length,
    avg: Math.round((sum / values.length) * 10) / 10,
    p50: percentile(values, 50),
    p95: percentile(values, 95),
    max: Math.max(...values),
  };
};

const summary = () => {
  const lastMinute = samples.filter((s) => Date.now() - s.at <= 60000).length;
  return {
    since: new Date(startedAt).toISOString(),
    eventsProcessed: total,
    eventsLastMinute: lastMinute,
    processingMs: describe(samples.map((s) => s.ms)),
    detectedProcessingMs: describe(samples.filter((s) => s.detected).map((s) => s.ms)),
  };
};

module.exports = { record, summary, describe, percentile };
