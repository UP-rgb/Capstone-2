const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const config = require('../config');
const { User } = require('../models');

let io = null;

// FR9: real-time push to connected dashboards. Admins receive everything; clients only
// receive alerts/incidents for devices they own (room "user:<id>").
const init = (httpServer) => {
  io = new Server(httpServer, { cors: { origin: config.corsOrigin, credentials: true } });

  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth && socket.handshake.auth.token;
      const payload = jwt.verify(token, config.jwt.secret);
      const user = await User.findByPk(payload.sub);
      if (!user || !user.isActive) return next(new Error('unauthorised'));
      socket.user = user;
      return next();
    } catch {
      return next(new Error('unauthorised'));
    }
  });

  io.on('connection', (socket) => {
    const { user } = socket;
    socket.join(user.role === 'ADMIN' ? 'admins' : `user:${user.id}`);
    socket.emit('connected', { role: user.role, at: new Date().toISOString() });
  });

  return io;
};

const emitScoped = (eventName, payload, ownerId) => {
  if (!io) return;
  io.to('admins').emit(eventName, payload);
  if (ownerId) io.to(`user:${ownerId}`).emit(eventName, payload);
};

const connectedCount = () => (io ? io.engine.clientsCount : 0);

module.exports = { init, emitScoped, connectedCount };
