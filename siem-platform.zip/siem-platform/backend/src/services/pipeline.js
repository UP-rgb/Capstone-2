const config = require('../config');
const { SecurityEvent } = require('../models');
const { normalize } = require('./normalizer');
const { extractIndicators, matchEvent } = require('./iocMatcher');
const { runDetection } = require('../detection');
const threatIntel = require('./threatIntelService');
const riskEngine = require('./riskEngine');
const mitreMapper = require('./mitreMapper');
const { upsertAlert, upsertIncident, maxSeverity } = require('./incidentService');
const socket = require('./socket');
const metrics = require('./metrics');

const trunc = (v, n) => (v == null ? v : String(v).slice(0, n));

/**
 * The /api/ingest pipeline (Figure 6 / Figure 7):
 *   normalise -> persist SecurityEvent -> IOC match -> detection rules ->
 *   threat-intel enrichment -> risk score -> MITRE map -> alert / incident -> Socket.io push
 */
const processEvent = async (device, payload) => {
  const t0 = process.hrtime.bigint();
  const elapsedMs = () => Number(process.hrtime.bigint() - t0) / 1e6;
  try {
    const result = await runPipeline(device, payload, elapsedMs);
    metrics.record(elapsedMs(), Boolean(result.detection));
    return result;
  } catch (err) {
    metrics.record(elapsedMs(), false);
    throw err;
  }
};

const runPipeline = async (device, payload, elapsedMs) => {
  const n = normalize(payload);
  const event = await SecurityEvent.create({
    ...n,
    eventType: trunc(n.eventType, 80),
    username: trunc(n.username, 120),
    deviceId: device.id,
  });
  device.increment('eventCount').catch(() => {});

  const indicators = extractIndicators(event);
  const iocMatches = await matchEvent(event, indicators);
  const detections = await runDetection(event, iocMatches);
  let primary = detections[0] || null;

  // Spend external API quota only on events that already look suspicious.
  const intel = await threatIntel.enrich(indicators, { allowExternal: Boolean(primary || iocMatches.length) });

  // Threat intel alone (e.g. AbuseIPDB-listed source IP) can raise an alert.
  if (!primary && intel.some((t) => riskEngine.SEVERITY_RANK[t.severity] >= riskEngine.SEVERITY_RANK.MEDIUM)) {
    const t = intel[0];
    primary = {
      rule: 'ioc_reputation', attackType: 'ioc_reputation', baseScore: 40,
      title: `Traffic involving ${t.indicator} flagged by ${t.source}`,
      description: t.summary || `${t.source} rates ${t.indicator} as ${t.severity}.`,
      evidence: { indicator: t.indicator, source: t.source },
    };
  }

  const result = { eventId: event.id, eventType: event.eventType, detection: null };
  if (!primary) return result; // "log event only (no incident)" branch

  primary.secondary = detections.slice(1);
  const risk = riskEngine.calculate({
    baseScore: primary.baseScore,
    attackType: primary.attackType,
    threatIntel: intel,
    iocMatches: iocMatches.map((m) => m.ioc),
  });
  const mitre = mitreMapper.map(primary.attackType);

  await event.update({
    riskScore: risk.score,
    attackType: primary.attackType,
    severity: maxSeverity(event.severity, risk.severity),
  });

  result.detection = {
    attackType: primary.attackType, title: primary.title, riskScore: risk.score,
    severity: risk.severity, mitre, breakdown: risk.breakdown,
  };

  if (risk.score < config.detection.alertThreshold) return result;

  const { alert, created: alertCreated } = await upsertAlert({ event, detection: primary, risk, mitre });
  result.alertId = alert.id;

  let incident = null;
  let incidentCreated = false;
  if (risk.score >= config.detection.incidentThreshold) {
    ({ incident, created: incidentCreated } = await upsertIncident({
      event, detection: primary, risk, mitre, iocMatches, threatIntel: intel, device,
    }));
    if (!alert.incidentId) await alert.update({ incidentId: incident.id });
    result.incidentId = incident.id;
    result.incidentReference = incident.reference;
  }

  const payloadOut = {
    alert: { ...alert.toJSON(), device: { id: device.id, name: device.name } },
    incident: incident ? { id: incident.id, reference: incident.reference, status: incident.status } : null,
    isNewAlert: alertCreated,
    isNewIncident: incidentCreated,
  };
  if (alertCreated) {
    const latency = Math.max(1, Math.round(elapsedMs()));
    await alert.update({ detectionLatencyMs: latency });
    payloadOut.alert.detectionLatencyMs = latency;
    result.alertLatencyMs = latency;
  }
  if (alertCreated || incidentCreated) socket.emitScoped('new_alert', payloadOut, device.ownerId);
  else socket.emitScoped('alert_updated', payloadOut, device.ownerId);

  return result;
};

module.exports = { processEvent };
