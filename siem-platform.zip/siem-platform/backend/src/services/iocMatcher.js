const { Op } = require('sequelize');
const { IOC, IOCMatch } = require('../models');
const { isIP } = require('../utils/ip');

const HASH_RE = /^([a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$/i;
const URL_RE = /\bhttps?:\/\/[^\s"'<>)]+/gi;
const DOMAIN_RE = /^(?=.{1,253}$)(?!-)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$/i;

const domainFromUrl = (u) => {
  try { return new URL(u).hostname.toLowerCase(); } catch { return null; }
};

const firstOf = (obj, keys) => keys.map((k) => obj[k]).filter((v) => typeof v === 'string' && v.trim());

/**
 * FR5: pulls every indicator (IP, hash, domain, URL, e-mail) out of a normalised event.
 * Returns [{ field, type, value }], values lower-cased and de-duplicated.
 */
const extractIndicators = (event) => {
  const raw = event.raw || {};
  const found = [];
  const add = (field, type, value) => {
    if (!value) return;
    const v = String(value).trim().toLowerCase();
    if (v && !found.some((f) => f.value === v)) found.push({ field, type, value: v });
  };

  if (isIP(event.sourceIP)) add('sourceIP', 'IP', event.sourceIP);
  if (isIP(event.destinationIP)) add('destinationIP', 'IP', event.destinationIP);

  firstOf(raw, ['hash', 'sha256', 'sha1', 'md5', 'fileHash', 'FileHash', 'Hashes'])
    .forEach((h) => h.split(/[,;\s=]+/).filter((p) => HASH_RE.test(p)).forEach((p) => add('hash', 'HASH', p)));

  const urls = [
    ...firstOf(raw, ['url', 'URL', 'link', 'clickedUrl']),
    ...[event.message, raw.CommandLine, raw.ScriptBlockText, raw.body]
      .filter((t) => typeof t === 'string')
      .flatMap((t) => t.match(URL_RE) || []),
  ];
  urls.forEach((u) => {
    add('url', 'URL', u);
    add('url.domain', 'DOMAIN', domainFromUrl(u));
  });

  firstOf(raw, ['domain', 'Domain', 'QueryName', 'query', 'senderDomain'])
    .filter((d) => DOMAIN_RE.test(d.trim()))
    .forEach((d) => add('domain', 'DOMAIN', d));

  firstOf(raw, ['email', 'sender', 'from', 'From'])
    .forEach((e) => {
      add('email', 'EMAIL', e);
      const at = e.lastIndexOf('@');
      if (at > 0) add('email.domain', 'DOMAIN', e.slice(at + 1));
    });

  return found;
};

/** Looks indicators up in the local IOC database and records IOCMatch rows. */
const matchEvent = async (event, indicators) => {
  if (!indicators.length) return [];
  const iocs = await IOC.findAll({
    where: { value: { [Op.in]: indicators.map((i) => i.value) }, isActive: true },
  });
  if (!iocs.length) return [];

  const matches = iocs.map((ioc) => {
    const ind = indicators.find((i) => i.value === ioc.value);
    return { ioc, field: ind ? ind.field : 'unknown', value: ioc.value };
  });

  await IOCMatch.bulkCreate(matches.map((m) => ({
    securityEventId: event.id, iocId: m.ioc.id, matchedField: m.field, matchedValue: m.value,
  })));
  await Promise.all(matches.map((m) => m.ioc.update({ hitCount: m.ioc.hitCount + 1, lastSeen: new Date() })));
  return matches;
};

module.exports = { extractIndicators, matchEvent, domainFromUrl };
