const { Op } = require('sequelize');
const { sequelize, Alert, Incident, SecurityEvent } = require('../models');
const config = require('../config');
const { SEVERITY_RANK } = require('./riskEngine');

const MAX_TIMELINE = 200;
const maxSeverity = (a, b) => (SEVERITY_RANK[a] >= SEVERITY_RANK[b] ? a : b);

const timelineEntry = (type, message, by = 'system', extra = {}) => ({
  at: new Date().toISOString(), type, message, by, ...extra,
});

const withEntry = (timeline, entry) => [...(timeline || []), entry].slice(-MAX_TIMELINE);

const nextReference = async () => {
  const [[row]] = await sequelize.query("SELECT nextval('incident_ref_seq') AS n");
  return `INC-${String(row.n).padStart(5, '0')}`;
};

const dedupSince = (ts) => new Date(new Date(ts).getTime() - config.detection.dedupMinutes * 60 * 1000);

/** Creates an alert, or folds the event into a recent matching open alert (alert-fatigue control). */
const upsertAlert = async ({ event, detection, risk, mitre }) => {
  const existing = await Alert.findOne({
    where: {
      attackType: detection.attackType,
      sourceIP: event.sourceIP || null,
      deviceId: event.deviceId,
      status: { [Op.in]: ['NEW', 'ACKNOWLEDGED'] },
      lastSeen: { [Op.gte]: dedupSince(event.timestamp) },
    },
    order: [['lastSeen', 'DESC']],
  });

  if (existing) {
    await existing.update({
      eventCount: existing.eventCount + 1,
      lastSeen: event.timestamp,
      riskScore: Math.max(existing.riskScore, risk.score),
      severity: maxSeverity(existing.severity, risk.severity),
      description: detection.description,
    });
    return { alert: existing, created: false };
  }

  const alert = await Alert.create({
    title: detection.title,
    description: detection.description,
    severity: risk.severity,
    sourceIP: event.sourceIP,
    attackType: detection.attackType,
    mitreTechnique: mitre && mitre.technique,
    mitreTactic: mitre && mitre.tactic,
    riskScore: risk.score,
    deviceId: event.deviceId,
    firstSeen: event.timestamp,
    lastSeen: event.timestamp,
    createdAt: event.timestamp,
  });
  return { alert, created: true };
};

/** FR8: creates a MITRE-tagged incident, or updates an open one for the same attack/source/device. */
const upsertIncident = async ({ event, detection, risk, mitre, iocMatches, threatIntel, device }) => {
  const evidence = {
    detection: detection.evidence,
    riskBreakdown: risk.breakdown,
    iocMatches: iocMatches.map((m) => ({ value: m.value, type: m.ioc.type, field: m.field, source: m.ioc.source, confidence: m.ioc.confidence })),
    threatIntel: threatIntel.map((t) => ({ indicator: t.indicator, source: t.source, severity: t.severity, confidence: t.confidence, summary: t.summary })),
    secondaryDetections: (detection.secondary || []).map((d) => ({ attackType: d.attackType, title: d.title })),
  };

  const existing = await Incident.findOne({
    where: {
      attackType: detection.attackType,
      sourceIP: event.sourceIP || null,
      deviceId: event.deviceId,
      status: { [Op.notIn]: ['RESOLVED', 'CLOSED'] },
      lastSeen: { [Op.gte]: dedupSince(event.timestamp) },
    },
    order: [['lastSeen', 'DESC']],
  });

  if (existing) {
    const severity = maxSeverity(existing.severity, risk.severity);
    const escalated = severity !== existing.severity;
    await existing.update({
      eventCount: existing.eventCount + 1,
      lastSeen: event.timestamp,
      riskScore: Math.max(existing.riskScore, risk.score),
      severity,
      evidence: { ...existing.evidence, ...evidence, latestDescription: detection.description },
      timeline: escalated
        ? withEntry(existing.timeline, timelineEntry('escalated', `Severity raised to ${severity} (risk ${risk.score})`))
        : existing.timeline,
    });
    await event.update({ incidentId: existing.id });
    return { incident: existing, created: false };
  }

  const incident = await Incident.create({
    reference: await nextReference(),
    title: detection.title,
    description: detection.description,
    attackType: detection.attackType,
    mitreTechnique: mitre && mitre.technique,
    mitreTactic: mitre && mitre.tactic,
    mitreName: mitre && mitre.name,
    severity: risk.severity,
    riskScore: risk.score,
    sourceIP: event.sourceIP,
    deviceId: event.deviceId,
    evidence,
    firstSeen: event.timestamp,
    lastSeen: event.timestamp,
    createdAt: event.timestamp,
    timeline: [timelineEntry('created',
      `Incident opened by detection engine on ${device.name}: ${detection.title} (risk ${risk.score}, ${mitre ? mitre.technique : 'unmapped'})`,
      'detection-engine', { at: new Date(event.timestamp).toISOString() })],
  });

  await event.update({ incidentId: incident.id });
  // Link the earlier related events from the same source (e.g. the failed logins that
  // led up to a brute-force threshold) so the incident shows the full picture.
  if (event.sourceIP) {
    await SecurityEvent.update({ incidentId: incident.id }, {
      where: {
        incidentId: null,
        deviceId: event.deviceId,
        sourceIP: event.sourceIP,
        timestamp: { [Op.between]: [dedupSince(event.timestamp), event.timestamp] },
      },
    });
  }
  return { incident, created: true };
};

const addTimeline = (incident, type, message, by) => withEntry(incident.timeline, timelineEntry(type, message, by));

module.exports = { upsertAlert, upsertIncident, addTimeline, timelineEntry, maxSeverity };
