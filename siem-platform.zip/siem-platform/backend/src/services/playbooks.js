// Response playbooks shown on incident pages and the Playbooks view (site map, Figure 2).
module.exports = {
  brute_force: {
    title: 'Brute-force / password spraying',
    steps: [
      'Confirm the source IP and targeted accounts from the incident evidence.',
      'Block the source IP on pfSense (Firewall > Rules) or add it to an alias block list.',
      'Check for any successful logon (Event 4624) from the same source after the failures.',
      'Force a password reset and review MFA status for targeted accounts.',
      'Confirm account lockout policy is enabled; document and close.',
    ],
  },
  phishing: {
    title: 'Phishing',
    steps: [
      'Identify every recipient of the message and whether anyone clicked the link.',
      'Block the sender domain and URL at the mail gateway / DNS filter.',
      'Reset credentials for any user who entered them; revoke active sessions.',
      'Add the domain, URL and sender to the IOC database.',
      'Notify users with a short awareness message.',
    ],
  },
  malware: {
    title: 'Malware execution',
    steps: [
      'Isolate the affected host from the network.',
      'Collect the file hash, path and parent process; check VirusTotal.',
      'Quarantine or remove the file and run a full scan.',
      'Look for persistence (services, scheduled tasks, Run keys).',
      'Re-image if integrity cannot be confirmed; add the hash to IOCs.',
    ],
  },
  ddos: {
    title: 'Network denial of service',
    steps: [
      'Confirm the service impact and the targeted host/port.',
      'Apply rate limiting or SYN-cookie protection on pfSense.',
      'Block or geo-filter the top source ranges.',
      'Engage the upstream provider if the link is saturated.',
      'Record traffic peaks for the post-incident review.',
    ],
  },
  data_exfiltration: {
    title: 'Data exfiltration',
    steps: [
      'Block the external destination immediately.',
      'Identify the process and user that generated the transfer.',
      'Determine what data left and its classification.',
      'Isolate the host and preserve evidence.',
      'Assess privacy-breach notification obligations (Privacy Act / NDB scheme).',
    ],
  },
  port_scan: {
    title: 'Network reconnaissance',
    steps: [
      'Identify whether the scanning source is internal or external.',
      'Block the source if external and not an approved scanner.',
      'Review which ports responded and whether those services need exposure.',
      'Watch for follow-up exploitation attempts from the same source.',
    ],
  },
  ioc_reputation: {
    title: 'Known-bad indicator observed',
    steps: [
      'Review the matched indicator and its threat-intelligence source.',
      'Determine which host communicated with it and the direction of traffic.',
      'Block the indicator at the firewall/DNS layer.',
      'Hunt for other hosts contacting the same indicator.',
    ],
  },
  powershell: {
    title: 'Suspicious PowerShell',
    steps: [
      'Decode any encoded command and review what it does.',
      'Identify the parent process and how it was launched.',
      'Block any download URL and check for dropped files.',
      'Enable script block logging (Event 4104) if not already enabled.',
      'Isolate the host if malicious activity is confirmed.',
    ],
  },
};
