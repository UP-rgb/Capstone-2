// FR8: maps each detection category to a MITRE ATT&CK technique and tactic (Table 3).
const MAPPING = {
  brute_force:       { technique: 'T1110',     tactic: 'Credential Access',   name: 'Brute Force' },
  phishing:          { technique: 'T1566',     tactic: 'Initial Access',      name: 'Phishing' },
  malware:           { technique: 'T1204',     tactic: 'Execution',           name: 'User Execution' },
  ddos:              { technique: 'T1498',     tactic: 'Impact',              name: 'Network Denial of Service' },
  data_exfiltration: { technique: 'T1041',     tactic: 'Exfiltration',        name: 'Exfiltration Over C2 Channel' },
  port_scan:         { technique: 'T1046',     tactic: 'Discovery',           name: 'Network Service Discovery' },
  ioc_reputation:    { technique: 'T1071',     tactic: 'Command and Control', name: 'Application Layer Protocol' },
  powershell:        { technique: 'T1059.001', tactic: 'Execution',           name: 'PowerShell' },
};

// Tactic order used by the dashboard matrix view (subset of the Enterprise matrix).
const TACTIC_ORDER = [
  'Initial Access', 'Execution', 'Credential Access', 'Discovery',
  'Command and Control', 'Exfiltration', 'Impact',
];

const map = (attackType) => MAPPING[attackType] || null;

const list = () => Object.entries(MAPPING).map(([attackType, m]) => ({ attackType, ...m }));

module.exports = { map, list, MAPPING, TACTIC_ORDER };
