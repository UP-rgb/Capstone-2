// Pure detection-quality calculations (Sections 1.2, 4.5, 5.3: detection rate,
// false-positive rate, alert latency). Ground truth comes from labelled events:
// scripts/simulate.js adds raw.simulation = { runId, scenario, expected } to every event,
// where expected is the attack type that should be detected, or null for benign traffic.
const { describe } = require('./metrics');

/**
 * rows: [{ runId, scenario, expected, attackType }]
 * A scenario run (runId + scenario) counts as detected when any of its events was
 * classified with the expected attack type. Brute force, for example, is only detected
 * on the 5th failed logon, so per-event scoring would understate the rule.
 */
const detectionMetrics = (rows) => {
  const groups = new Map();
  const benign = { events: 0, flagged: 0, flaggedAs: {} };

  rows.forEach((r) => {
    if (!r.expected) {
      benign.events += 1;
      if (r.attackType) {
        benign.flagged += 1;
        benign.flaggedAs[r.attackType] = (benign.flaggedAs[r.attackType] || 0) + 1;
      }
      return;
    }
    const key = `${r.runId}|${r.scenario}`;
    if (!groups.has(key)) groups.set(key, { runId: r.runId, scenario: r.scenario, expected: r.expected, events: 0, detected: false, misclassifiedAs: new Set() });
    const g = groups.get(key);
    g.events += 1;
    if (r.attackType === r.expected) g.detected = true;
    else if (r.attackType) g.misclassifiedAs.add(r.attackType);
  });

  const runs = [...groups.values()];
  const byCategory = {};
  runs.forEach((g) => {
    const c = byCategory[g.expected] || (byCategory[g.expected] = { attackType: g.expected, runs: 0, detected: 0, missed: 0, misclassified: 0 });
    c.runs += 1;
    if (g.detected) c.detected += 1;
    else {
      c.missed += 1;
      if (g.misclassifiedAs.size) c.misclassified += 1;
    }
  });
  Object.values(byCategory).forEach((c) => { c.detectionRate = c.runs ? c.detected / c.runs : null; });

  const detected = runs.filter((g) => g.detected).length;
  return {
    attackRuns: runs.length,
    detectedRuns: detected,
    detectionRate: runs.length ? detected / runs.length : null,
    benignEvents: benign.events,
    falsePositives: benign.flagged,
    falsePositiveRate: benign.events ? benign.flagged / benign.events : null,
    falsePositivesByType: benign.flaggedAs,
    byCategory: Object.values(byCategory).sort((a, b) => a.attackType.localeCompare(b.attackType)),
    missed: runs.filter((g) => !g.detected).map((g) => ({ runId: g.runId, scenario: g.scenario, expected: g.expected, misclassifiedAs: [...g.misclassifiedAs] })),
  };
};

/** Analyst-labelled false positives: alerts closed as FALSE_POSITIVE out of all alerts. */
const analystFalsePositiveRate = (alertStatusCounts) => {
  const total = Object.values(alertStatusCounts).reduce((s, n) => s + n, 0);
  const fp = alertStatusCounts.FALSE_POSITIVE || 0;
  return { alerts: total, falsePositives: fp, rate: total ? fp / total : null };
};

const latencyStats = (values) => describe(values.filter((v) => Number.isFinite(v)));

module.exports = { detectionMetrics, analystFalsePositiveRate, latencyStats };
