const { windowWhere } = require('./helpers');

// Many distinct destination ports probed by one source in a short window (MITRE T1046).
module.exports = {
  name: 'port_scan',
  async evaluate(event, { SecurityEvent, config }) {
    if (!event.sourceIP || !event.destinationPort) return null;
    const { portScanThreshold, portScanWindow } = config.detection;
    const where = { sourceIP: event.sourceIP, ...windowWhere(event, portScanWindow) };
    const ports = await SecurityEvent.count({ where, distinct: true, col: 'destinationPort' });
    if (ports < portScanThreshold) return null;
    return {
      attackType: 'port_scan',
      baseScore: 45,
      title: `Port scan from ${event.sourceIP}`,
      description: `${ports} distinct ports probed in ${portScanWindow}s (threshold ${portScanThreshold}).`,
      evidence: { distinctPorts: ports, windowSeconds: portScanWindow, threshold: portScanThreshold },
    };
  },
};
