const { lc } = require('./helpers');

const PATTERNS = [
  { re: /-e(nc|ncodedcommand)?\s+[a-z0-9+/=]{20,}/i, label: 'encoded command', weight: 2 },
  { re: /frombase64string/i, label: 'base64 decoding', weight: 1 },
  { re: /(iex|invoke-expression)\b/i, label: 'Invoke-Expression', weight: 1 },
  { re: /(downloadstring|downloadfile|invoke-webrequest|iwr\s|net\.webclient|start-bitstransfer)/i, label: 'download cradle', weight: 2 },
  { re: /-(w|windowstyle)\s+hidden/i, label: 'hidden window', weight: 1 },
  { re: /-(nop|noprofile)\b/i, label: 'no profile', weight: 0.5 },
  { re: /-(ep|executionpolicy)\s+bypass/i, label: 'execution policy bypass', weight: 1 },
  { re: /(amsiutils|amsiinitfailed|set-mppreference\s+-disable)/i, label: 'defence evasion (AMSI/Defender)', weight: 2 },
];

// Suspicious PowerShell from process creation (4688) or script block logging (4104) - MITRE T1059.001.
module.exports = {
  name: 'powershell',
  async evaluate(event) {
    if (!['process_creation', 'powershell_script', 'powershell'].includes(event.eventType)) return null;
    const proc = lc(event.raw.NewProcessName || event.raw.processName || '');
    const text = `${event.raw.CommandLine || ''} ${event.raw.ScriptBlockText || ''}`;
    const isPs = event.eventType !== 'process_creation' || proc.includes('powershell') || proc.includes('pwsh') || /powershell/i.test(text);
    if (!isPs) return null;

    const hits = PATTERNS.filter((p) => p.re.test(text));
    const weight = hits.reduce((s, h) => s + h.weight, 0);
    if (weight < 2) return null;

    return {
      attackType: 'powershell',
      baseScore: Math.min(50 + Math.round(weight * 6), 80),
      title: `Suspicious PowerShell execution${event.username ? ` by ${event.username}` : ''}`,
      description: `Indicators: ${hits.map((h) => h.label).join(', ')}.`,
      evidence: { indicators: hits.map((h) => h.label), commandLine: text.trim().slice(0, 2000), parent: event.raw.ParentProcessName || null },
    };
  },
};
