const { Op } = require('sequelize');
const config = require('../config');
const { SecurityEvent } = require('../models');

const rules = [
  require('./bruteForce'),
  require('./ddos'),
  require('./portScan'),
  require('./malware'),
  require('./phishing'),
  require('./powershell'),
  require('./dataExfiltration'),
];

/**
 * FR4: runs every rule against the stored event. Returns all detections, highest base
 * score first. A rule that throws is logged and skipped so one bad rule can't stop ingest.
 */
const runDetection = async (event, iocMatches = []) => {
  const ctx = { SecurityEvent, Op, config, iocMatches };
  const detections = [];
  for (const rule of rules) {
    try {
      const d = await rule.evaluate(event, ctx);
      if (d) detections.push({ rule: rule.name, ...d });
    } catch (err) {
      console.error(`[detection] rule ${rule.name} failed:`, err.message);
    }
  }

  // An IOC hit with no behavioural rule still deserves attention (T1071 reputation).
  if (!detections.length && iocMatches.length) {
    const top = iocMatches[0];
    detections.push({
      rule: 'ioc_reputation',
      attackType: 'ioc_reputation',
      baseScore: 40,
      title: `Traffic involving known-bad ${top.ioc.type.toLowerCase()} ${top.value}`,
      description: `${iocMatches.length} indicator(s) matched the IOC database: ${iocMatches.map((m) => m.value).join(', ')}.`,
      evidence: { matched: iocMatches.map((m) => ({ value: m.value, type: m.ioc.type, field: m.field, source: m.ioc.source })) },
    });
  }

  return detections.sort((a, b) => b.baseScore - a.baseScore);
};

module.exports = { runDetection, rules };
