const { Op } = require('sequelize');
const { windowWhere } = require('./helpers');

const FAILED_TYPES = ['failed_login', 'auth_failure', 'login_failed', 'ssh_failed', 'authentication_failure'];

// FR4: N failed logins from the same source (or against the same account on a host)
// inside the configured window => brute force (MITRE T1110).
module.exports = {
  name: 'brute_force',
  async evaluate(event, { SecurityEvent, config }) {
    if (!FAILED_TYPES.includes(event.eventType)) return null;
    const { bruteForceThreshold: threshold, bruteForceWindow: windowSec } = config.detection;

    let key;
    const where = { eventType: { [Op.in]: FAILED_TYPES }, ...windowWhere(event, windowSec) };
    if (event.sourceIP) {
      where.sourceIP = event.sourceIP;
      key = `source ${event.sourceIP}`;
    } else if (event.username) {
      where.username = event.username;
      where.deviceId = event.deviceId;
      key = `account "${event.username}"`;
    } else {
      return null;
    }

    const count = await SecurityEvent.count({ where });
    if (count < threshold) return null;

    const users = await SecurityEvent.findAll({
      where, attributes: ['username'], group: ['username'], raw: true,
    });
    const targeted = users.map((u) => u.username).filter(Boolean);
    const sprayed = targeted.length >= 3;

    return {
      attackType: 'brute_force',
      baseScore: 65,
      title: sprayed ? `Password spraying from ${key}` : `Brute-force login attempts from ${key}`,
      description: `${count} failed logins in ${windowSec}s (threshold ${threshold})`
        + `${targeted.length ? ` targeting ${targeted.slice(0, 5).join(', ')}` : ''}.`,
      evidence: { failedAttempts: count, windowSeconds: windowSec, threshold, targetedAccounts: targeted },
    };
  },
};
