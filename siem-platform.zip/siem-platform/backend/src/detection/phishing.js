const { lc } = require('./helpers');
const { domainFromUrl } = require('../services/iocMatcher');

const PHISH_TYPES = ['email_received', 'phishing', 'phishing_report', 'url_click', 'proxy_request', 'dns_query'];
const BRANDS = ['paypal', 'microsoft', 'office365', 'outlook', 'apple', 'netflix', 'amazon', 'commbank', 'westpac', 'mygov', 'ato'];
const OFFICIAL = /(^|\.)(paypal\.com|microsoft\.com|office\.com|live\.com|outlook\.com|apple\.com|netflix\.com|amazon\.com(\.au)?|commbank\.com\.au|westpac\.com\.au|my\.gov\.au|ato\.gov\.au)$/;
const RISKY_TLDS = ['zip', 'mov', 'top', 'xyz', 'click', 'country', 'gq', 'tk', 'ml', 'cf'];
const LURE_WORDS = ['verify', 'urgent', 'suspended', 'password', 'invoice', 'reset', 'login', 'unusual activity'];

// Heuristics are scored; 2+ signals (or any IOC hit) => phishing (MITRE T1566).
const heuristics = (event) => {
  const raw = event.raw;
  const url = raw.url || raw.URL || '';
  const sender = String(raw.sender || raw.from || '');
  const domain = lc(raw.domain || raw.senderDomain || domainFromUrl(url) || (sender.includes('@') ? sender.split('@').pop() : '') || '');
  const text = lc(`${raw.subject || ''} ${raw.body || ''} ${event.message || ''}`);
  const signals = [];
  if (domain.includes('xn--')) signals.push('punycode (look-alike) domain');
  if (domain && BRANDS.some((b) => domain.includes(b)) && !OFFICIAL.test(domain)) signals.push(`brand name in unofficial domain ${domain}`);
  if (domain && RISKY_TLDS.includes(domain.split('.').pop())) signals.push(`high-risk TLD .${domain.split('.').pop()}`);
  if (/https?:\/\/\d{1,3}(\.\d{1,3}){3}/.test(url)) signals.push('URL uses a raw IP address');
  if (domain.split('.').length >= 5) signals.push('excessive subdomains');
  if (raw.spf === 'fail' || raw.dkim === 'fail' || raw.dmarc === 'fail') signals.push('sender authentication (SPF/DKIM/DMARC) failed');
  const lures = LURE_WORDS.filter((w) => text.includes(w));
  if (lures.length >= 2) signals.push(`lure wording (${lures.join(', ')})`);
  if (/\.(html?|iso|img|js|vbs|hta|lnk)$/i.test(raw.attachment || '')) signals.push(`risky attachment ${raw.attachment}`);
  return { signals, domain };
};

module.exports = {
  name: 'phishing',
  async evaluate(event, { iocMatches }) {
    // Only IOCs tagged as phishing (or untagged) count; e.g. a malware C2 domain is left
    // to the IOC-reputation path instead of being mislabelled as phishing.
    const iocHit = iocMatches.find((m) => ['DOMAIN', 'URL', 'EMAIL'].includes(m.ioc.type)
      && (!m.ioc.attackType || m.ioc.attackType === 'phishing'));
    if (!PHISH_TYPES.includes(event.eventType) && !iocHit) return null;

    const { signals, domain } = heuristics(event);
    if (!iocHit && signals.length < 2) return null;

    return {
      attackType: 'phishing',
      baseScore: Math.min(50 + Math.max(signals.length - 2, 0) * 5, 65),
      title: `Phishing ${event.eventType === 'url_click' ? 'link clicked' : 'attempt'}${domain ? ` via ${domain}` : ''}`,
      description: iocHit
        ? `Indicator ${iocHit.value} matches a known phishing IOC.${signals.length ? ` Also: ${signals.join('; ')}.` : ''}`
        : `Suspicious message: ${signals.join('; ')}.`,
      evidence: {
        signals, domain: domain || null, sender: event.raw.sender || event.raw.from || null,
        recipient: event.username || event.raw.recipient || null, subject: event.raw.subject || null,
      },
    };
  },
};
