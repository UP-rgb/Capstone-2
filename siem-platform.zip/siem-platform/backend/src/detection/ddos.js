const { windowWhere } = require('./helpers');

const FLOOD_TYPES = ['syn_flood', 'udp_flood', 'icmp_flood', 'network_flood', 'http_flood', 'ddos'];

// FR4: volumetric denial of service (MITRE T1498). Two signals:
//  - a sensor/firewall reports a flood with packets-per-second above the threshold
//  - more than N events hit the same destination inside a short window
module.exports = {
  name: 'ddos',
  async evaluate(event, { SecurityEvent, config }) {
    const { ddosThreshold, ddosWindow, ddosPpsThreshold } = config.detection;
    const pps = Number(event.raw.packetsPerSecond || event.raw.pps || 0);

    if (FLOOD_TYPES.includes(event.eventType) && pps >= ddosPpsThreshold) {
      return {
        attackType: 'ddos',
        baseScore: 60,
        title: `Network flood against ${event.destinationIP || 'monitored host'}`,
        description: `${event.eventType} at ${pps.toLocaleString()} packets/s (threshold ${ddosPpsThreshold.toLocaleString()}).`,
        evidence: { packetsPerSecond: pps, threshold: ddosPpsThreshold, uniqueSources: event.raw.uniqueSources || null },
      };
    }

    if (!event.destinationIP) return null;
    const where = { destinationIP: event.destinationIP, ...windowWhere(event, ddosWindow) };
    const count = await SecurityEvent.count({ where });
    if (count < ddosThreshold) return null;
    const sources = await SecurityEvent.count({ where, distinct: true, col: 'sourceIP' });

    return {
      attackType: 'ddos',
      baseScore: sources >= 5 ? 60 : 50,
      title: `Traffic flood against ${event.destinationIP}`,
      description: `${count} events to ${event.destinationIP} in ${ddosWindow}s from ${sources} source(s).`,
      evidence: { eventsInWindow: count, windowSeconds: ddosWindow, uniqueSources: sources, threshold: ddosThreshold },
    };
  },
};
