const { Op } = require('sequelize');

// Time window [event.timestamp - seconds, event.timestamp] so back-dated/replayed
// events are evaluated against the events that surrounded them.
const windowWhere = (event, seconds) => {
  const end = new Date(event.timestamp);
  const start = new Date(end.getTime() - seconds * 1000);
  return { timestamp: { [Op.between]: [start, end] } };
};

const lc = (v) => (typeof v === 'string' ? v.toLowerCase() : '');

module.exports = { windowWhere, lc };
