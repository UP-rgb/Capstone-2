const { isPublicIP } = require('../utils/ip');

// Large outbound transfer to an external address (MITRE T1041).
module.exports = {
  name: 'data_exfiltration',
  async evaluate(event, { config }) {
    const bytesOut = Number(event.raw.bytesOut || event.raw.bytes_out || event.raw.sentBytes || 0);
    if (!bytesOut || !isPublicIP(event.destinationIP)) return null;
    const threshold = config.detection.exfilBytes;
    if (bytesOut < threshold) return null;
    const mb = (bytesOut / 1048576).toFixed(1);
    return {
      attackType: 'data_exfiltration',
      baseScore: bytesOut >= threshold * 4 ? 60 : 50,
      title: `Large outbound transfer to ${event.destinationIP}`,
      description: `${mb} MB sent to external host ${event.destinationIP}${event.destinationPort ? `:${event.destinationPort}` : ''}.`,
      evidence: { bytesOut, megabytes: Number(mb), thresholdBytes: threshold, protocol: event.raw.protocol || null },
    };
  },
};
