const jwt = require('jsonwebtoken');
const config = require('../config');
const { User } = require('../models');
const { HttpError } = require('../utils/http');

const signToken = (user) => jwt.sign(
  { sub: user.id, role: user.role, username: user.username },
  config.jwt.secret,
  { expiresIn: config.jwt.expiresIn },
);

// Verifies the Bearer JWT and loads the current user (so deactivated users lose access immediately).
const authenticate = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) throw new HttpError(401, 'Sign in to continue');
    let payload;
    try {
      payload = jwt.verify(token, config.jwt.secret);
    } catch (e) {
      throw new HttpError(401, e.name === 'TokenExpiredError' ? 'Session expired, sign in again' : 'Invalid session token');
    }
    const user = await User.findByPk(payload.sub);
    if (!user || !user.isActive) throw new HttpError(401, 'Account is disabled or no longer exists');
    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { authenticate, signToken };
