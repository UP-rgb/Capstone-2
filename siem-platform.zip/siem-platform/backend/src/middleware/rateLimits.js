const rateLimit = require('express-rate-limit');
const config = require('../config');

const json = (message) => ({ error: message });

// Slows down password guessing against the dashboard login.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: json('Too many sign-in attempts. Wait 15 minutes and try again.'),
});

// Protects the ingest endpoint from being flooded (Section 3.4.1). Keyed per device key.
const ingestLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: config.ingestRateLimit,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.header('x-api-key') || req.ip,
  message: json('Ingest rate limit exceeded for this device'),
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 600,
  standardHeaders: true,
  legacyHeaders: false,
  message: json('Too many requests'),
});

module.exports = { loginLimiter, ingestLimiter, apiLimiter };
