const { HttpError } = require('../utils/http');

// FR10: role-based access control for protected routes.
const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return next(new HttpError(401, 'Sign in to continue'));
  if (!roles.includes(req.user.role)) {
    return next(new HttpError(403, 'Your role does not allow this action'));
  }
  return next();
};

module.exports = { authorize, adminOnly: authorize('ADMIN') };
