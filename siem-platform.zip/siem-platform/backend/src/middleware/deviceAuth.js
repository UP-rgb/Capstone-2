const { Device } = require('../models');
const { hashApiKey } = require('../utils/apiKey');
const { HttpError } = require('../utils/http');

// FR1: devices authenticate with the x-api-key header before any event is accepted.
const deviceAuth = async (req, res, next) => {
  try {
    const key = req.header('x-api-key');
    if (!key) throw new HttpError(401, 'Missing x-api-key header');
    const device = await Device.findOne({ where: { apiKeyHash: hashApiKey(key) } });
    if (!device) throw new HttpError(401, 'Invalid API key');
    if (device.status === 'DISABLED') throw new HttpError(403, 'Device is disabled');
    // A heartbeat/event from an INACTIVE device brings it back to ACTIVE.
    device.lastHeartbeat = new Date();
    if (device.status === 'INACTIVE') device.status = 'ACTIVE';
    await device.save({ fields: ['lastHeartbeat', 'status'] });
    req.device = device;
    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { deviceAuth };
