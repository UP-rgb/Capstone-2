require('dotenv').config();

const num = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));

const config = {
  env: process.env.NODE_ENV || 'development',
  port: num(process.env.PORT, 5000),
  host: process.env.HOST || '0.0.0.0',
  corsOrigin: (process.env.CORS_ORIGIN || 'http://localhost:5173').split(',').map((s) => s.trim()),

  db: {
    host: process.env.DB_HOST || 'localhost',
    port: num(process.env.DB_PORT, 5432),
    name: process.env.DB_NAME || 'siem_db',
    user: process.env.DB_USER || 'siem_user',
    password: process.env.DB_PASSWORD || '',
    logging: process.env.DB_LOGGING === 'true',
  },

  jwt: {
    secret: process.env.JWT_SECRET || '',
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
  },

  detection: {
    alertThreshold: num(process.env.ALERT_THRESHOLD, 40),
    incidentThreshold: num(process.env.INCIDENT_THRESHOLD, 70),
    bruteForceThreshold: num(process.env.BRUTE_FORCE_THRESHOLD, 5),
    bruteForceWindow: num(process.env.BRUTE_FORCE_WINDOW_SECONDS, 120),
    ddosThreshold: num(process.env.DDOS_THRESHOLD, 50),
    ddosWindow: num(process.env.DDOS_WINDOW_SECONDS, 10),
    ddosPpsThreshold: num(process.env.DDOS_PPS_THRESHOLD, 10000),
    portScanThreshold: num(process.env.PORT_SCAN_THRESHOLD, 15),
    portScanWindow: num(process.env.PORT_SCAN_WINDOW_SECONDS, 60),
    exfilBytes: num(process.env.EXFIL_BYTES_THRESHOLD, 50 * 1024 * 1024),
    dedupMinutes: num(process.env.DEDUP_WINDOW_MINUTES, 30),
  },

  threatIntel: {
    mode: (process.env.THREAT_INTEL_MODE || 'local').toLowerCase(),
    cacheHours: num(process.env.THREAT_INTEL_CACHE_HOURS, 24),
    virusTotalKey: process.env.VIRUSTOTAL_API_KEY || '',
    abuseIpdbKey: process.env.ABUSEIPDB_API_KEY || '',
  },

  ingestRateLimit: num(process.env.INGEST_RATE_LIMIT, 1200),
};

if (!config.jwt.secret || config.jwt.secret.length < 32) {
  if (config.env === 'production') {
    throw new Error('JWT_SECRET must be set to at least 32 characters in production');
  }
  console.warn('[config] JWT_SECRET is missing or short - using an insecure development fallback.');
  config.jwt.secret = config.jwt.secret || 'dev-only-insecure-secret-change-me-0123456789';
}

module.exports = config;
