/* eslint-disable no-console */
// Seeds users, devices, IOCs, local threat intel, and ~24h of realistic activity.
// Scenario events are pushed through the real ingest pipeline (detection, IOC matching,
// risk scoring, MITRE mapping, incident creation), so dashboards show genuine output.
//
//   npm run seed         -> seeds an empty database
//   npm run seed:reset   -> DROPS all tables and reseeds
const fs = require('fs');
const path = require('path');
const {
  sequelize, User, Device, IOC, ThreatIntel, Incident, Alert, IncidentComment,
} = require('../models');
const { generateApiKey, hashApiKey, keyPrefix } = require('../utils/apiKey');
const { processEvent } = require('../services/pipeline');
const { addTimeline } = require('../services/incidentService');

const RESET = process.argv.includes('--reset');
const NOW = Date.now();
const ago = (minutes, plusSeconds = 0) => new Date(NOW - minutes * 60000 + plusSeconds * 1000).toISOString();
const rand = (arr) => arr[Math.floor(Math.random() * arr.length)];

const USERS = [
  { username: 'admin', email: 'admin@siem.local', password: 'Admin@123', role: 'ADMIN', fullName: 'Abhisan Limbu', organization: 'SOC Group 5' },
  { username: 'nishan', email: 'nishan@siem.local', password: 'Admin@123', role: 'ADMIN', fullName: 'Nishan Majhi', organization: 'SOC Group 5' },
  { username: 'acme.analyst', email: 'analyst@acme.example', password: 'Client@123', role: 'CLIENT', fullName: 'Acme Security Analyst', organization: 'Acme Pty Ltd' },
  { username: 'globex.analyst', email: 'analyst@globex.example', password: 'Client@123', role: 'CLIENT', fullName: 'Globex Security Analyst', organization: 'Globex Corporation' },
];

const DEVICES = [
  { name: 'pfSense-Firewall', hostname: 'pfsense.lab', type: 'FIREWALL', ipAddress: '192.168.1.1', location: 'SOC lab edge', owner: 'acme.analyst' },
  { name: 'Windows-Target', hostname: 'WINDOWS11TARGET', type: 'WINDOWS', ipAddress: '192.168.1.40', location: 'SOC lab LAN', owner: 'acme.analyst' },
  { name: 'Ubuntu-SIEM', hostname: 'ubuntu-siem', type: 'LINUX', ipAddress: '192.168.1.10', location: 'SOC lab LAN', owner: null },
  { name: 'Globex-Web-01', hostname: 'web01.globex.example', type: 'SERVER', ipAddress: '10.20.0.15', location: 'Globex DMZ', owner: 'globex.analyst' },
];

// Documentation/test ranges (RFC 5737) and .example domains only — nothing real.
const IOCS = [
  { type: 'IP', value: '198.51.100.66', confidence: 'HIGH', severity: 'HIGH', attackType: 'ioc_reputation', source: 'Lab threat feed', description: 'Command-and-control server used in lab scenario' },
  { type: 'IP', value: '203.0.113.99', confidence: 'MEDIUM', severity: 'HIGH', attackType: 'data_exfiltration', source: 'Lab threat feed', description: 'File-drop host linked to exfiltration' },
  { type: 'HASH', value: '44d88612fea8a8f36de82e1278abb02f', confidence: 'HIGH', severity: 'CRITICAL', attackType: 'malware', source: 'EICAR', description: 'EICAR anti-malware test file (MD5) - harmless test signature' },
  { type: 'HASH', value: '275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f', confidence: 'HIGH', severity: 'CRITICAL', attackType: 'malware', source: 'EICAR', description: 'EICAR anti-malware test file (SHA-256)' },
  { type: 'DOMAIN', value: 'paypal-account-verify.example', confidence: 'HIGH', severity: 'HIGH', attackType: 'phishing', source: 'Lab phishing feed', description: 'Credential-harvesting look-alike domain' },
  { type: 'URL', value: 'http://paypal-account-verify.example/login', confidence: 'HIGH', severity: 'HIGH', attackType: 'phishing', source: 'Lab phishing feed' },
  { type: 'EMAIL', value: 'security-alert@paypal-account-verify.example', confidence: 'HIGH', severity: 'HIGH', attackType: 'phishing', source: 'Lab phishing feed' },
  { type: 'DOMAIN', value: 'update-cdn-sync.example', confidence: 'MEDIUM', severity: 'MEDIUM', attackType: 'malware', source: 'Lab threat feed', description: 'Malware staging domain' },
];

const LOCAL_INTEL = [
  { indicator: '198.51.100.66', indicatorType: 'IP', sourceIP: '198.51.100.66', name: 'Lab C2 server', attackType: 'ioc_reputation', mitreTechnique: 'T1071', severity: 'HIGH', confidence: 'HIGH', source: 'LOCAL', score: 92, country: 'ZZ', summary: 'Curated lab intel: C2 beacon destination (abuse confidence 92%)' },
  { indicator: '203.0.113.99', indicatorType: 'IP', sourceIP: '203.0.113.99', name: 'Exfil drop host', attackType: 'data_exfiltration', mitreTechnique: 'T1041', severity: 'CRITICAL', confidence: 'MEDIUM', source: 'LOCAL', score: 97, country: 'ZZ', summary: 'Curated lab intel: bulk upload destination seen in prior incidents' },
  { indicator: '44d88612fea8a8f36de82e1278abb02f', indicatorType: 'HASH', name: 'EICAR-Test-File', attackType: 'malware', mitreTechnique: 'T1204', severity: 'CRITICAL', confidence: 'HIGH', source: 'LOCAL', score: 64, summary: 'Detected by 64 engines (EICAR test signature)' },
];

const writeKeys = (keys) => {
  const file = path.join(__dirname, '../../scripts/.device-keys.json');
  fs.writeFileSync(file, JSON.stringify(keys, null, 2));
  return file;
};

const run = async () => {
  await sequelize.authenticate();
  if (RESET) {
    console.log('Dropping and recreating all tables...');
    await sequelize.sync({ force: true });
    await sequelize.query('DROP SEQUENCE IF EXISTS incident_ref_seq');
  } else {
    await sequelize.sync();
    if (await User.count()) {
      console.log('Database already has users. Run "npm run seed:reset" to wipe and reseed.');
      process.exit(0);
    }
  }
  await sequelize.query('CREATE SEQUENCE IF NOT EXISTS incident_ref_seq START 1');

  // ---- users ----
  const users = {};
  for (const u of USERS) users[u.username] = await User.create(u);

  // ---- devices ----
  const devices = {};
  const keys = {};
  for (const d of DEVICES) {
    const apiKey = generateApiKey();
    devices[d.name] = await Device.create({
      ...d, ownerId: d.owner ? users[d.owner].id : null,
      apiKeyHash: hashApiKey(apiKey), apiKeyPrefix: keyPrefix(apiKey),
      lastHeartbeat: new Date(), status: 'ACTIVE',
    });
    keys[d.name] = apiKey;
  }

  await IOC.bulkCreate(IOCS);
  await ThreatIntel.bulkCreate(LOCAL_INTEL.map((t) => ({ ...t, lastChecked: new Date() })));

  const fw = devices['pfSense-Firewall'];
  const win = devices['Windows-Target'];
  const ubuntu = devices['Ubuntu-SIEM'];
  const globex = devices['Globex-Web-01'];
  const ingest = (device, payload) => processEvent(device, payload);

  // ---- background (benign) activity over 24h ----
  console.log('Generating background activity...');
  for (let i = 0; i < 160; i += 1) {
    const minutes = Math.floor(Math.random() * 1440);
    const kind = rand(['login', 'fw', 'dns', 'proc', 'fw', 'login']);
    if (kind === 'login') {
      await ingest(win, { eventType: 'successful_login', severity: 'LOW', timestamp: ago(minutes), sourceIP: '192.168.1.50', username: rand(['victim', 'student', 'labadmin']), raw: { EventID: 4624, LogonType: rand([2, 3, 10]) } });
    } else if (kind === 'fw') {
      await ingest(fw, { eventType: 'firewall_pass', severity: 'LOW', timestamp: ago(minutes), sourceIP: rand(['192.168.1.40', '192.168.1.50', '192.168.1.10']), destinationIP: rand(['142.250.70.206', '13.107.42.14', '104.16.132.229']), destinationPort: rand([443, 80, 53]), raw: { action: 'pass', interface: 'lan' } });
    } else if (kind === 'dns') {
      await ingest(fw, { eventType: 'dns_query', severity: 'LOW', timestamp: ago(minutes), sourceIP: '192.168.1.40', raw: { domain: rand(['microsoft.com', 'smit.edu.au', 'github.com', 'ubuntu.com']) } });
    } else {
      await ingest(win, { eventType: 'process_creation', severity: 'LOW', timestamp: ago(minutes), username: 'victim', raw: { EventID: 4688, NewProcessName: rand(['C:\\Windows\\System32\\svchost.exe', 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Windows\\explorer.exe']), CommandLine: '' } });
    }
  }
  for (let i = 0; i < 40; i += 1) {
    await ingest(globex, { eventType: 'http_request', severity: 'LOW', timestamp: ago(Math.floor(Math.random() * 1440)), sourceIP: rand(['1.1.1.1', '8.8.4.4', '9.9.9.9']), destinationIP: '10.20.0.15', destinationPort: 443, raw: { path: rand(['/', '/login', '/api/products']), status: 200 } });
  }

  // ---- attack scenarios (Acme / SOC lab) ----
  console.log('Replaying attack scenarios through the detection pipeline...');
  // 1) RDP brute force from Kali-like external source: 7 failures in ~70s -> T1110, risk 85 (HIGH)
  for (let i = 0; i < 7; i += 1) {
    await ingest(win, { eventType: 'failed_login', severity: 'MEDIUM', timestamp: ago(1210, i * 10), sourceIP: '203.0.113.45', username: i < 4 ? 'administrator' : 'victim', message: 'An account failed to log on.', raw: { EventID: 4625, LogonType: 10, FailureReason: 'Unknown user name or bad password.', Status: '0xC000006D' } });
  }
  // 2) Port scan against pfSense WAN: 22 ports in 30s -> T1046 (MEDIUM alert)
  const ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1433, 1723, 3306, 3389, 5900, 8080, 8443, 9200];
  for (const [i, p] of ports.entries()) {
    await ingest(fw, { eventType: 'firewall_block', severity: 'LOW', timestamp: ago(960, i), sourceIP: '192.168.1.66', destinationIP: '192.168.1.1', destinationPort: p, raw: { action: 'block', interface: 'wan', proto: 'tcp', flags: 'S' } });
  }
  // 3) Phishing e-mail with known-bad sender/link -> T1566
  await ingest(win, { eventType: 'email_received', severity: 'LOW', timestamp: ago(720), username: 'victim', raw: { sender: 'security-alert@paypal-account-verify.example', subject: 'Urgent: verify your account - unusual activity', body: 'Your account is suspended. Verify your password at http://paypal-account-verify.example/login', spf: 'fail', attachment: '' } });
  // 4) EICAR test file executed from Temp -> T1204 (CRITICAL)
  await ingest(win, { eventType: 'process_creation', severity: 'MEDIUM', timestamp: ago(480), username: 'victim', raw: { EventID: 4688, NewProcessName: 'C:\\Users\\victim\\AppData\\Local\\Temp\\invoice_viewer.exe', CommandLine: 'invoice_viewer.exe /silent', hash: '44d88612fea8a8f36de82e1278abb02f', ParentProcessName: 'C:\\Windows\\explorer.exe' } });
  // 5) Encoded PowerShell download cradle -> T1059.001
  await ingest(win, { eventType: 'process_creation', severity: 'MEDIUM', timestamp: ago(300), username: 'victim', raw: { EventID: 4688, NewProcessName: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', CommandLine: 'powershell.exe -nop -w hidden -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkA', ParentProcessName: 'C:\\Windows\\System32\\cmd.exe' } });
  // 6) SYN flood reported by pfSense -> T1498 (CRITICAL)
  await ingest(fw, { eventType: 'syn_flood', severity: 'HIGH', timestamp: ago(180), destinationIP: '192.168.1.1', destinationPort: 443, raw: { packetsPerSecond: 48000, uniqueSources: 1260, interface: 'wan' } });
  // 7) 180 MB upload to known drop host -> T1041 (CRITICAL)
  await ingest(fw, { eventType: 'firewall_pass', severity: 'LOW', timestamp: ago(90), sourceIP: '192.168.1.40', destinationIP: '203.0.113.99', destinationPort: 443, raw: { bytesOut: 188743680, protocol: 'https', action: 'pass' } });
  // 8) Beacon to known C2 -> T1071
  await ingest(fw, { eventType: 'firewall_pass', severity: 'LOW', timestamp: ago(45), sourceIP: '192.168.1.40', destinationIP: '198.51.100.66', destinationPort: 8443, raw: { action: 'pass', bytesOut: 2048 } });
  // 9) Linux SIEM host: a few SSH failures (below threshold - logged only)
  for (let i = 0; i < 3; i += 1) {
    await ingest(ubuntu, { eventType: 'ssh_failed', severity: 'LOW', timestamp: ago(240, i * 20), sourceIP: '192.168.1.66', username: 'root', raw: { program: 'sshd', message: 'Failed password for root' } });
  }

  // ---- Globex (second client - demonstrates data isolation) ----
  for (let i = 0; i < 9; i += 1) {
    await ingest(globex, { eventType: 'ssh_failed', severity: 'MEDIUM', timestamp: ago(360, i * 6), sourceIP: '192.0.2.77', username: rand(['root', 'admin', 'ubuntu', 'deploy']), raw: { program: 'sshd' } });
  }
  await ingest(globex, { eventType: 'url_click', severity: 'LOW', timestamp: ago(150), username: 'j.smith', raw: { url: 'http://xn--micrsoft-login-secure.top/office365/verify', subject: 'Password reset required' } });

  // ---- give the incidents some analyst history ----
  const admin = users.admin;
  const bf = await Incident.findOne({ where: { attackType: 'brute_force', sourceIP: '203.0.113.45' } });
  if (bf) {
    await IncidentComment.create({ incidentId: bf.id, userId: admin.id, username: admin.username, comment: 'Source blocked on pfSense WAN alias. No successful 4624 logon from 203.0.113.45 found after the failures.' });
    let tl = addTimeline(bf, 'status', 'Status changed from OPEN to INVESTIGATING', admin.username);
    tl = addTimeline({ timeline: tl }, 'status', 'Status changed from INVESTIGATING to RESOLVED: source blocked, passwords rotated', admin.username);
    await bf.update({ status: 'RESOLVED', resolvedAt: new Date(), assignedTo: admin.id, timeline: tl });
    await Alert.update({ status: 'RESOLVED' }, { where: { incidentId: bf.id } });
  }
  const mal = await Incident.findOne({ where: { attackType: 'malware' } });
  if (mal) {
    await mal.update({ status: 'INVESTIGATING', assignedTo: users.nishan.id, timeline: addTimeline(mal, 'assignment', 'Assigned to nishan', admin.username) });
  }
  await Alert.update({ status: 'ACKNOWLEDGED' }, { where: { attackType: 'port_scan' } });

  const keyFile = writeKeys(keys);
  const [incidents, alerts] = await Promise.all([Incident.count(), Alert.count()]);

  console.log('\n=== Seed complete ===');
  console.log(`Incidents: ${incidents}   Alerts: ${alerts}\n`);
  console.log('Dashboard accounts:');
  USERS.forEach((u) => console.log(`  ${u.role.padEnd(6)}  ${u.username.padEnd(15)} ${u.password}   (${u.organization})`));
  console.log('\nDevice API keys (shown once; also saved to scripts/.device-keys.json for the simulator):');
  Object.entries(keys).forEach(([name, k]) => console.log(`  ${name.padEnd(17)} ${k}`));
  console.log(`\nKeys file: ${keyFile}`);
  await sequelize.close();
};

run().catch(async (err) => {
  console.error('Seed failed:', err);
  await sequelize.close().catch(() => {});
  process.exit(1);
});
