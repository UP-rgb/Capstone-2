const http = require('http');
const { Op } = require('sequelize');
const config = require('./config');
const app = require('./app');
const { sequelize, Device } = require('./models');
const socket = require('./services/socket');

const STALE_MINUTES = 15;

const start = async () => {
  try {
    await sequelize.authenticate();
    // Prototype uses sync(); Capstone 2 moves to versioned Sequelize migrations.
    // DB_SYNC_ALTER=true adds new columns/tables to an existing database (use once after upgrading).
    await sequelize.sync({ alter: process.env.DB_SYNC_ALTER === 'true' });
    await sequelize.query('CREATE SEQUENCE IF NOT EXISTS incident_ref_seq START 1');
    console.log(`[db] connected to ${config.db.name}@${config.db.host}:${config.db.port}`);
  } catch (err) {
    console.error('[db] unable to connect:', err.message);
    console.error('    Check DB_* values in backend/.env and that PostgreSQL is running.');
    process.exit(1);
  }

  const server = http.createServer(app);
  socket.init(server);

  // NFR4: mark devices INACTIVE when their heartbeat goes quiet.
  setInterval(async () => {
    const cutoff = new Date(Date.now() - STALE_MINUTES * 60 * 1000);
    const [n] = await Device.update({ status: 'INACTIVE' }, {
      where: { status: 'ACTIVE', lastHeartbeat: { [Op.lt]: cutoff } },
    }).catch(() => [0]);
    if (n) console.log(`[devices] ${n} device(s) marked INACTIVE (no heartbeat for ${STALE_MINUTES} min)`);
  }, 60 * 1000).unref();

  server.listen(config.port, config.host, () => {
    console.log(`[siem] Enterprise SIEM Platform listening on http://${config.host}:${config.port}`);
    console.log(`[siem] threat-intel mode: ${config.threatIntel.mode}`);
  });

  const shutdown = () => {
    console.log('[siem] shutting down');
    server.close(() => sequelize.close().then(() => process.exit(0)));
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
};

start();
