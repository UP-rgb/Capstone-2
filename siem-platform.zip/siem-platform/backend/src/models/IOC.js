const { DataTypes } = require('sequelize');
const { IOC_TYPES, CONFIDENCE, SEVERITIES } = require('../utils/constants');

module.exports = (sequelize) => sequelize.define('IOC', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  type: { type: DataTypes.ENUM(...IOC_TYPES), allowNull: false },
  value: { type: DataTypes.STRING(512), allowNull: false, unique: true },
  confidence: { type: DataTypes.ENUM(...CONFIDENCE), defaultValue: 'MEDIUM' },
  severity: { type: DataTypes.ENUM(...SEVERITIES), defaultValue: 'MEDIUM' },
  attackType: { type: DataTypes.STRING(40) },
  source: { type: DataTypes.STRING(120), defaultValue: 'manual' },
  description: { type: DataTypes.TEXT },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
  hitCount: { type: DataTypes.INTEGER, defaultValue: 0 },
  lastSeen: { type: DataTypes.DATE },
}, {
  tableName: 'iocs',
  hooks: {
    beforeValidate: (ioc) => { if (ioc.value) ioc.value = String(ioc.value).trim().toLowerCase(); },
  },
});
