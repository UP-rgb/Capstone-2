const { DataTypes } = require('sequelize');
const bcrypt = require('bcryptjs');
const { ROLES } = require('../utils/constants');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
    username: { type: DataTypes.STRING(60), allowNull: false, unique: true },
    fullName: { type: DataTypes.STRING(120) },
    organization: { type: DataTypes.STRING(120) },
    email: { type: DataTypes.STRING(160), allowNull: false, unique: true, validate: { isEmail: true } },
    password: { type: DataTypes.STRING, allowNull: false },
    role: { type: DataTypes.ENUM(...ROLES), allowNull: false, defaultValue: 'CLIENT' },
    isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
    lastLogin: { type: DataTypes.DATE },
  }, {
    tableName: 'users',
    defaultScope: { attributes: { exclude: ['password'] } },
    scopes: { withPassword: { attributes: { include: ['password'] } } },
    hooks: {
      // NFR1: passwords are always stored as bcrypt hashes
      beforeSave: async (user) => {
        if (user.changed('password')) user.password = await bcrypt.hash(user.password, 12);
      },
    },
  });

  User.prototype.checkPassword = function checkPassword(plain) {
    return bcrypt.compare(plain, this.password);
  };

  User.prototype.toSafeJSON = function toSafeJSON() {
    const { password, ...rest } = this.get({ plain: true });
    return rest;
  };

  return User;
};
