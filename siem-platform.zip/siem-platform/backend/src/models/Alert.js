const { DataTypes } = require('sequelize');
const { SEVERITIES, ALERT_STATUS } = require('../utils/constants');

module.exports = (sequelize) => sequelize.define('Alert', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  title: { type: DataTypes.STRING(200), allowNull: false },
  description: { type: DataTypes.TEXT },
  severity: { type: DataTypes.ENUM(...SEVERITIES), allowNull: false },
  status: { type: DataTypes.ENUM(...ALERT_STATUS), defaultValue: 'NEW' },
  sourceIP: { type: DataTypes.STRING(45) },
  attackType: { type: DataTypes.STRING(40) },
  mitreTechnique: { type: DataTypes.STRING(20) },
  mitreTactic: { type: DataTypes.STRING(60) },
  riskScore: { type: DataTypes.INTEGER, defaultValue: 0 },
  eventCount: { type: DataTypes.INTEGER, defaultValue: 1 },
  firstSeen: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  lastSeen: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  deviceId: { type: DataTypes.UUID },
  incidentId: { type: DataTypes.UUID },
  assignedTo: { type: DataTypes.UUID },
  // Alert latency (Sections 1.2, 5.3): ms from the triggering event reaching /api/ingest
  // to the alert being stored and pushed over Socket.io.
  detectionLatencyMs: { type: DataTypes.INTEGER },
}, {
  tableName: 'alerts',
  indexes: [{ fields: ['status'] }, { fields: ['deviceId'] }, { fields: ['createdAt'] }],
});
