const sequelize = require('../config/database');

const User = require('./User')(sequelize);
const Device = require('./Device')(sequelize);
const SecurityEvent = require('./SecurityEvent')(sequelize);
const Alert = require('./Alert')(sequelize);
const Incident = require('./Incident')(sequelize);
const IncidentComment = require('./IncidentComment')(sequelize);
const Evidence = require('./Evidence')(sequelize);
const IOC = require('./IOC')(sequelize);
const IOCMatch = require('./IOCMatch')(sequelize);
const ThreatIntel = require('./ThreatIntel')(sequelize);
const AuditLog = require('./AuditLog')(sequelize);
const IncidentAssignment = require('./IncidentAssignment')(sequelize);

// ---- Associations (see ER diagram, Figure 3) ----
User.hasMany(Device, { foreignKey: 'ownerId', as: 'devices' });
Device.belongsTo(User, { foreignKey: 'ownerId', as: 'owner' });

Device.hasMany(SecurityEvent, { foreignKey: 'deviceId', as: 'events', onDelete: 'CASCADE' });
SecurityEvent.belongsTo(Device, { foreignKey: 'deviceId', as: 'device' });

Incident.hasMany(SecurityEvent, { foreignKey: 'incidentId', as: 'events' });
SecurityEvent.belongsTo(Incident, { foreignKey: 'incidentId', as: 'incident' });

Incident.hasMany(Alert, { foreignKey: 'incidentId', as: 'alerts' });
Alert.belongsTo(Incident, { foreignKey: 'incidentId', as: 'incident' });

Device.hasMany(Alert, { foreignKey: 'deviceId', as: 'alerts', onDelete: 'SET NULL' });
Alert.belongsTo(Device, { foreignKey: 'deviceId', as: 'device' });
Device.hasMany(Incident, { foreignKey: 'deviceId', as: 'incidents', onDelete: 'SET NULL' });
Incident.belongsTo(Device, { foreignKey: 'deviceId', as: 'device' });

Alert.belongsTo(User, { foreignKey: 'assignedTo', as: 'assignee' });
Incident.belongsTo(User, { foreignKey: 'assignedTo', as: 'assignee' });

Incident.hasMany(IncidentComment, { foreignKey: 'incidentId', as: 'comments', onDelete: 'CASCADE' });
IncidentComment.belongsTo(Incident, { foreignKey: 'incidentId' });
Incident.hasMany(Evidence, { foreignKey: 'incidentId', as: 'evidenceItems', onDelete: 'CASCADE' });
Evidence.belongsTo(Incident, { foreignKey: 'incidentId' });

SecurityEvent.hasMany(IOCMatch, { foreignKey: 'securityEventId', as: 'iocMatches', onDelete: 'CASCADE' });
IOCMatch.belongsTo(SecurityEvent, { foreignKey: 'securityEventId', as: 'event' });
IOC.hasMany(IOCMatch, { foreignKey: 'iocId', as: 'matches', onDelete: 'CASCADE' });
IOCMatch.belongsTo(IOC, { foreignKey: 'iocId', as: 'ioc' });

AuditLog.belongsTo(User, { foreignKey: 'userId', as: 'user', constraints: false });

Incident.hasMany(IncidentAssignment, { foreignKey: 'incidentId', as: 'assignments', onDelete: 'CASCADE' });
IncidentAssignment.belongsTo(Incident, { foreignKey: 'incidentId' });
IncidentAssignment.belongsTo(User, { foreignKey: 'userId', as: 'user', constraints: false });

module.exports = {
  sequelize,
  User, Device, SecurityEvent, Alert, Incident, IncidentComment,
  Evidence, IOC, IOCMatch, ThreatIntel, AuditLog, IncidentAssignment,
};
