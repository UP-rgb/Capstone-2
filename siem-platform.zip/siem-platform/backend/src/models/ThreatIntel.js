const { DataTypes } = require('sequelize');
const { SEVERITIES, CONFIDENCE } = require('../utils/constants');

// Cached enrichment results (VirusTotal / AbuseIPDB) and locally curated intel.
module.exports = (sequelize) => sequelize.define('ThreatIntel', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(200) },
  indicator: { type: DataTypes.STRING(512), allowNull: false },
  indicatorType: { type: DataTypes.STRING(20), allowNull: false }, // IP | DOMAIN | URL | HASH
  attackType: { type: DataTypes.STRING(40) },
  mitreTechnique: { type: DataTypes.STRING(20) },
  severity: { type: DataTypes.ENUM(...SEVERITIES) },
  confidence: { type: DataTypes.ENUM(...CONFIDENCE) },
  source: { type: DataTypes.STRING(40), allowNull: false }, // VirusTotal | AbuseIPDB | LOCAL
  sourceIP: { type: DataTypes.STRING(45) },
  score: { type: DataTypes.INTEGER }, // abuseConfidenceScore or VT malicious count
  country: { type: DataTypes.STRING(8) },
  summary: { type: DataTypes.TEXT },
  raw: { type: DataTypes.JSONB, defaultValue: {} },
  lastChecked: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
}, {
  tableName: 'threat_intel',
  indexes: [{ unique: true, fields: ['indicator', 'source'] }],
});
