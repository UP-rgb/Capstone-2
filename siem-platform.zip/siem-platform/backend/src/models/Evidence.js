const { DataTypes } = require('sequelize');

module.exports = (sequelize) => sequelize.define('Evidence', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  incidentId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  username: { type: DataTypes.STRING(60) },
  title: { type: DataTypes.STRING(200), allowNull: false },
  type: { type: DataTypes.STRING(40), defaultValue: 'note' }, // note | log | screenshot-ref | indicator
  content: { type: DataTypes.TEXT },
}, { tableName: 'evidence' });
