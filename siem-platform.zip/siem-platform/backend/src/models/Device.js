const { DataTypes } = require('sequelize');
const { DEVICE_TYPES, DEVICE_STATUS } = require('../utils/constants');

module.exports = (sequelize) => sequelize.define('Device', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(100), allowNull: false },
  hostname: { type: DataTypes.STRING(160) },
  type: { type: DataTypes.ENUM(...DEVICE_TYPES), allowNull: false },
  ipAddress: { type: DataTypes.STRING(45) },
  location: { type: DataTypes.STRING(120) },
  // The plaintext API key is shown once at creation/regeneration; only its SHA-256 hash is stored.
  apiKeyHash: { type: DataTypes.STRING(64), allowNull: false, unique: true },
  apiKeyPrefix: { type: DataTypes.STRING(16) },
  status: { type: DataTypes.ENUM(...DEVICE_STATUS), defaultValue: 'ACTIVE' },
  lastHeartbeat: { type: DataTypes.DATE },
  eventCount: { type: DataTypes.INTEGER, defaultValue: 0 },
  ownerId: { type: DataTypes.UUID }, // CLIENT user that owns/monitors this device
}, {
  tableName: 'devices',
  defaultScope: { attributes: { exclude: ['apiKeyHash'] } },
  scopes: { withKey: { attributes: { include: ['apiKeyHash'] } } },
});
