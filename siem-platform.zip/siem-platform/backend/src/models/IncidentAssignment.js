const { DataTypes } = require('sequelize');

// IncidentAssignment (ER diagram, Figure 3): history of who an incident was assigned to,
// when, and by whom. Incident.assignedTo keeps the current assignee for fast filtering.
module.exports = (sequelize) => sequelize.define('IncidentAssignment', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  incidentId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID }, // null = unassigned
  assignedById: { type: DataTypes.UUID },
  assignedByUsername: { type: DataTypes.STRING(60) },
  note: { type: DataTypes.STRING(500) },
}, {
  tableName: 'incident_assignments',
  updatedAt: false,
  indexes: [{ fields: ['incidentId'] }],
});
