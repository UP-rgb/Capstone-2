const { DataTypes } = require('sequelize');

module.exports = (sequelize) => sequelize.define('IOCMatch', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  securityEventId: { type: DataTypes.UUID, allowNull: false },
  iocId: { type: DataTypes.UUID, allowNull: false },
  matchedField: { type: DataTypes.STRING(60) },
  matchedValue: { type: DataTypes.STRING(512) },
}, { tableName: 'ioc_matches' });
