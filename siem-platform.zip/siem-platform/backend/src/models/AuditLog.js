const { DataTypes } = require('sequelize');

// FR12: auditable record of who did what
module.exports = (sequelize) => sequelize.define('AuditLog', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  userId: { type: DataTypes.UUID },
  username: { type: DataTypes.STRING(60) },
  action: { type: DataTypes.STRING(80), allowNull: false },
  entityType: { type: DataTypes.STRING(40) },
  entityId: { type: DataTypes.STRING(64) },
  details: { type: DataTypes.JSONB, defaultValue: {} },
  ip: { type: DataTypes.STRING(64) },
}, { tableName: 'audit_logs', updatedAt: false, indexes: [{ fields: ['createdAt'] }] });
