const { DataTypes } = require('sequelize');
const { SEVERITIES, INCIDENT_STATUS } = require('../utils/constants');

module.exports = (sequelize) => sequelize.define('Incident', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  reference: { type: DataTypes.STRING(20), unique: true }, // human friendly e.g. INC-000123
  title: { type: DataTypes.STRING(200), allowNull: false },
  description: { type: DataTypes.TEXT },
  attackType: { type: DataTypes.STRING(40) },
  mitreTechnique: { type: DataTypes.STRING(20) },
  mitreTactic: { type: DataTypes.STRING(60) },
  mitreName: { type: DataTypes.STRING(100) },
  severity: { type: DataTypes.ENUM(...SEVERITIES), allowNull: false },
  riskScore: { type: DataTypes.INTEGER, defaultValue: 0 },
  status: { type: DataTypes.ENUM(...INCIDENT_STATUS), defaultValue: 'OPEN' },
  sourceIP: { type: DataTypes.STRING(45) },
  eventCount: { type: DataTypes.INTEGER, defaultValue: 1 },
  firstSeen: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  lastSeen: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  deviceId: { type: DataTypes.UUID },
  assignedTo: { type: DataTypes.UUID },
  // Risk breakdown, matched IOCs and threat-intel kept for transparency/auditability
  evidence: { type: DataTypes.JSONB, defaultValue: {} },
  timeline: { type: DataTypes.JSONB, defaultValue: [] },
  resolvedAt: { type: DataTypes.DATE },
}, {
  tableName: 'incidents',
  indexes: [{ fields: ['status'] }, { fields: ['deviceId'] }, { fields: ['createdAt'] }],
});
