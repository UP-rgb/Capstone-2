const { DataTypes } = require('sequelize');
const { SEVERITIES } = require('../utils/constants');

module.exports = (sequelize) => sequelize.define('SecurityEvent', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  deviceId: { type: DataTypes.UUID, allowNull: false },
  incidentId: { type: DataTypes.UUID },
  eventType: { type: DataTypes.STRING(80), allowNull: false },
  severity: { type: DataTypes.ENUM(...SEVERITIES), defaultValue: 'LOW' },
  riskScore: { type: DataTypes.INTEGER, defaultValue: 0 },
  attackType: { type: DataTypes.STRING(40) },
  sourceIP: { type: DataTypes.STRING(45) },
  destinationIP: { type: DataTypes.STRING(45) },
  destinationPort: { type: DataTypes.INTEGER },
  username: { type: DataTypes.STRING(120) },
  message: { type: DataTypes.TEXT },
  raw: { type: DataTypes.JSONB, defaultValue: {} },
  timestamp: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
}, {
  tableName: 'security_events',
  indexes: [
    { fields: ['deviceId', 'timestamp'] },
    { fields: ['sourceIP', 'timestamp'] },
    { fields: ['destinationIP', 'timestamp'] },
    { fields: ['eventType'] },
    { fields: ['incidentId'] },
  ],
});
