const { DataTypes } = require('sequelize');

module.exports = (sequelize) => sequelize.define('IncidentComment', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  incidentId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  username: { type: DataTypes.STRING(60) },
  comment: { type: DataTypes.TEXT, allowNull: false },
}, { tableName: 'incident_comments' });
