/* eslint-disable no-console */
// Database-free unit tests for the detection logic (run: npm run test:unit).
// Window-based rules receive a mocked SecurityEvent model so no PostgreSQL is needed.
const assert = require('assert');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'unit-test-secret-unit-test-secret-1234';
const config = require('../src/config');
const risk = require('../src/services/riskEngine');
const mitre = require('../src/services/mitreMapper');
const { normalize } = require('../src/services/normalizer');
const bruteForce = require('../src/detection/bruteForce');
const ddos = require('../src/detection/ddos');
const malware = require('../src/detection/malware');
const phishing = require('../src/detection/phishing');
const powershell = require('../src/detection/powershell');
const exfil = require('../src/detection/dataExfiltration');
const portScan = require('../src/detection/portScan');
const { isPrivateIP, isPublicIP } = require('../src/utils/ip');
const { detectionMetrics, analystFalsePositiveRate } = require('../src/services/evaluation');
const { responseTimes, toCsv, parseRange } = require('../src/services/reporting');
const metrics = require('../src/services/metrics');

let passed = 0;
const tests = [];
const test = (name, fn) => tests.push([name, fn]);

const mockModel = ({ count = 0, distinct = 0, users = [] } = {}) => ({
  count: async (opts) => (opts && opts.distinct ? distinct : count),
  findAll: async () => users.map((username) => ({ username })),
});
const ev = (o) => ({ deviceId: 'd1', timestamp: new Date(), raw: {}, ...o });
const ctx = (o = {}) => ({ config, iocMatches: [], SecurityEvent: mockModel(), ...o });

test('risk: 5 failed logins (brute force) scores 85 / HIGH as in Section 4.4', () => {
  const r = risk.calculate({ baseScore: 65, attackType: 'brute_force' });
  assert.strictEqual(r.score, 85);
  assert.strictEqual(r.severity, 'HIGH');
});
test('risk: score is capped at 100 and banded CRITICAL', () => {
  const r = risk.calculate({ baseScore: 55, attackType: 'malware', threatIntel: [{ severity: 'CRITICAL', confidence: 'HIGH' }], iocMatches: [{ confidence: 'HIGH' }] });
  assert.strictEqual(r.score, 100);
  assert.strictEqual(r.severity, 'CRITICAL');
  assert.ok(r.uncapped > 100);
});
test('risk: bands follow CRITICAL>=90, HIGH>=70, MEDIUM>=40, LOW<40', () => {
  assert.deepStrictEqual([90, 89, 70, 69, 40, 39].map(risk.band), ['CRITICAL', 'HIGH', 'HIGH', 'MEDIUM', 'MEDIUM', 'LOW']);
});
test('mitre: all eight detection categories map to a technique', () => {
  assert.strictEqual(mitre.list().length, 8);
  assert.strictEqual(mitre.map('brute_force').technique, 'T1110');
  assert.strictEqual(mitre.map('powershell').technique, 'T1059.001');
  assert.strictEqual(mitre.map('nope'), null);
});
test('normalizer: Windows 4625 becomes failed_login and IpAddress becomes sourceIP', () => {
  const n = normalize({ raw: { EventID: 4625, IpAddress: '192.168.1.66', TargetUserName: 'victim' } });
  assert.strictEqual(n.eventType, 'failed_login');
  assert.strictEqual(n.sourceIP, '192.168.1.66');
  assert.strictEqual(n.username, 'victim');
});
test('normalizer: invalid IPs dropped, future timestamps clamped', () => {
  const n = normalize({ eventType: 'x', sourceIP: 'not-an-ip', timestamp: '2999-01-01T00:00:00Z' });
  assert.strictEqual(n.sourceIP, null);
  assert.ok(n.timestamp.getTime() <= Date.now() + 1000);
});
test('ip: private vs public classification', () => {
  assert.ok(isPrivateIP('192.168.1.10'));
  assert.ok(isPrivateIP('10.0.2.2'));
  assert.ok(isPublicIP('8.8.8.8'));
  assert.ok(!isPublicIP('172.20.0.1'));
});
test('bruteForce: fires at threshold, not below', async () => {
  const e = ev({ eventType: 'failed_login', sourceIP: '203.0.113.5' });
  assert.strictEqual(await bruteForce.evaluate(e, ctx({ SecurityEvent: mockModel({ count: 4 }) })), null);
  const d = await bruteForce.evaluate(e, ctx({ SecurityEvent: mockModel({ count: 5, users: ['victim'] }) }));
  assert.strictEqual(d.attackType, 'brute_force');
  assert.strictEqual(d.baseScore, 65);
});
test('ddos: flood report above pps threshold', async () => {
  const d = await ddos.evaluate(ev({ eventType: 'syn_flood', raw: { packetsPerSecond: 50000 } }), ctx());
  assert.strictEqual(d.attackType, 'ddos');
  assert.strictEqual(await ddos.evaluate(ev({ eventType: 'syn_flood', raw: { packetsPerSecond: 10 } }), ctx()), null);
});
test('malware: offensive tool in process creation', async () => {
  const d = await malware.evaluate(ev({ eventType: 'process_creation', raw: { NewProcessName: 'C:\\Tools\\mimikatz.exe' } }), ctx());
  assert.strictEqual(d.attackType, 'malware');
  assert.strictEqual(await malware.evaluate(ev({ eventType: 'process_creation', raw: { NewProcessName: 'C:\\Windows\\explorer.exe' } }), ctx()), null);
});
test('phishing: look-alike punycode domain on a risky TLD', async () => {
  const d = await phishing.evaluate(ev({ eventType: 'url_click', raw: { url: 'http://xn--pple-43d.top/verify' } }), ctx());
  assert.strictEqual(d.attackType, 'phishing');
  const clean = await phishing.evaluate(ev({ eventType: 'dns_query', raw: { domain: 'microsoft.com' } }), ctx());
  assert.strictEqual(clean, null);
});
test('powershell: hidden encoded command detected, plain Get-Process ignored', async () => {
  const d = await powershell.evaluate(ev({ eventType: 'process_creation', raw: { NewProcessName: 'powershell.exe', CommandLine: 'powershell -nop -w hidden -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoA' } }), ctx());
  assert.strictEqual(d.attackType, 'powershell');
  const benign = await powershell.evaluate(ev({ eventType: 'process_creation', raw: { NewProcessName: 'powershell.exe', CommandLine: 'powershell Get-Process' } }), ctx());
  assert.strictEqual(benign, null);
});
test('exfiltration: large upload to public IP only', async () => {
  const big = 200 * 1024 * 1024;
  assert.ok(await exfil.evaluate(ev({ destinationIP: '203.0.113.9', raw: { bytesOut: big } }), ctx()));
  assert.strictEqual(await exfil.evaluate(ev({ destinationIP: '192.168.1.20', raw: { bytesOut: big } }), ctx()), null);
});

// The simulator's benign scenario is used as the negative class for the false-positive
// rate, so none of these events may trigger a rule on their own.
test('benign traffic: no rule fires on normal logons, browsing, e-mail or PowerShell', async () => {
  const benign = [
    { eventType: 'failed_login', sourceIP: '192.168.1.70', raw: { EventID: 4625 } },
    { eventType: 'process_creation', raw: { EventID: 4688, NewProcessName: 'C:\\Windows\\System32\\notepad.exe', CommandLine: 'notepad.exe report.txt', ParentProcessName: 'C:\\Windows\\explorer.exe' } },
    { eventType: 'process_creation', raw: { EventID: 4688, NewProcessName: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', CommandLine: 'powershell.exe Get-Process | Sort-Object CPU' } },
    { eventType: 'email_received', raw: { sender: 'it-support@example.com', subject: 'Team meeting moved to 3pm', body: 'See the updated calendar invite.', spf: 'pass', dkim: 'pass' } },
    { eventType: 'url_click', raw: { url: 'https://www.example.org/docs/handbook' } },
    { eventType: 'firewall_pass', sourceIP: '192.168.1.70', destinationIP: '93.184.215.14', destinationPort: 443, raw: { bytesOut: 48213 } },
    { eventType: 'dns_query', sourceIP: '192.168.1.70', raw: { query: 'www.microsoft.com' } },
    { eventType: 'firewall_block', sourceIP: '192.168.1.70', destinationIP: '192.168.1.1', destinationPort: 23, raw: {} },
  ];
  const rules = { bruteForce, ddos, portScan, malware, phishing, powershell, exfil };
  for (const payload of benign) {
    const event = { ...ev({}), ...normalize(payload) };
    for (const [name, rule] of Object.entries(rules)) {
      const d = await rule.evaluate(event, ctx({ SecurityEvent: mockModel({ count: 1, distinct: 1 }) }));
      assert.strictEqual(d, null, `${name} fired on benign ${payload.eventType}`);
    }
  }
});

test('evaluation: detection rate counts a scenario once, false positives from benign events', () => {
  const m = detectionMetrics([
    { runId: 'r1', scenario: 'bruteforce', expected: 'brute_force', attackType: null },
    { runId: 'r1', scenario: 'bruteforce', expected: 'brute_force', attackType: 'brute_force' },
    { runId: 'r1', scenario: 'portscan', expected: 'port_scan', attackType: null },
    { runId: 'r1', scenario: 'c2', expected: 'ioc_reputation', attackType: 'ioc_reputation' },
    { runId: 'r1', scenario: 'benign', expected: null, attackType: null },
    { runId: 'r1', scenario: 'benign', expected: null, attackType: 'phishing' },
    { runId: 'r1', scenario: 'benign', expected: null, attackType: null },
    { runId: 'r1', scenario: 'benign', expected: null, attackType: null },
  ]);
  assert.strictEqual(m.attackRuns, 3);
  assert.strictEqual(m.detectedRuns, 2);
  assert.ok(Math.abs(m.detectionRate - 2 / 3) < 1e-9);
  assert.strictEqual(m.falsePositiveRate, 0.25);
  assert.deepStrictEqual(m.missed.map((x) => x.expected), ['port_scan']);
  assert.strictEqual(analystFalsePositiveRate({ NEW: 6, FALSE_POSITIVE: 2, RESOLVED: 2 }).rate, 0.2);
});

test('metrics: percentiles and averages for latency', () => {
  const d = metrics.describe([10, 20, 30, 40, 100]);
  assert.strictEqual(d.p50, 30);
  assert.strictEqual(d.p95, 100);
  assert.strictEqual(d.avg, 40);
  assert.strictEqual(metrics.describe([]).avg, null);
});

test('reporting: response times, safe CSV, date range validation', () => {
  const t0 = new Date('2026-08-11T10:00:00Z');
  const r = responseTimes([
    { createdAt: t0, resolvedAt: new Date('2026-08-11T12:00:00Z'), timeline: [{ type: 'created', at: t0 }, { type: 'status', at: new Date('2026-08-11T10:10:00Z') }] },
    { createdAt: t0, resolvedAt: null, timeline: [{ type: 'assignment', at: new Date('2026-08-11T10:30:00Z') }] },
  ]);
  assert.strictEqual(r.acknowledgeMinutes.avg, 20);
  assert.strictEqual(r.resolveMinutes.avg, 120);
  const csv = toCsv([{ label: 'A', value: 'a' }, { label: 'B', value: 'b' }], [{ a: 'x, "y"', b: '=HYPERLINK("evil")' }]);
  assert.strictEqual(csv, 'A,B\r\n"x, ""y""","\'=HYPERLINK(""evil"")"\r\n');
  assert.throws(() => parseRange({ from: '2026-08-10', to: '2026-08-01' }), /before/);
  const def = parseRange({}, new Date('2026-08-11T00:00:00Z'));
  assert.strictEqual(def.to - def.from, 7 * 86400000);
});

(async () => {
  for (const [name, fn] of tests) {
    try { await fn(); passed += 1; console.log(`  ok   ${name}`); } catch (e) { console.log(`  FAIL ${name}\n       ${e.message}`); }
  }
  console.log(`\n${passed}/${tests.length} passed`);
  process.exit(passed === tests.length ? 0 : 1);
})();
