#!/usr/bin/env node
/* eslint-disable no-console */
// Zero-dependency log shipper for Linux hosts and the pfSense syslog stream received by
// rsyslog on the Ubuntu SIEM. Tails files, parses sshd and pfSense filterlog lines,
// and posts batches to POST /api/ingest.
//
//   SIEM_URL=http://192.168.1.10:5000 SIEM_API_KEY=siem_xxx \
//     node log-forwarder.js /var/log/auth.log /var/log/remote/pfsense.log
//
// Requires Node 18+. Run with sudo if the log files are root-readable only.
const fs = require('fs');

const URL_BASE = (process.env.SIEM_URL || 'http://localhost:5000').replace(/\/$/, '');
const KEY = process.env.SIEM_API_KEY;
const files = process.argv.slice(2);
if (!KEY || !files.length) {
  console.error('Usage: SIEM_URL=... SIEM_API_KEY=... node log-forwarder.js <logfile> [more files]');
  process.exit(1);
}

const queue = [];
let lastHeartbeat = 0;

const parseLine = (line) => {
  let m = line.match(/sshd\[\d+\]: Failed password for (?:invalid user )?(\S+) from (\S+) port (\d+)/);
  if (m) return { eventType: 'ssh_failed', severity: 'MEDIUM', username: m[1], sourceIP: m[2], destinationPort: 22, message: line.trim(), raw: { program: 'sshd', srcPort: Number(m[3]) } };
  m = line.match(/sshd\[\d+\]: Accepted (\S+) for (\S+) from (\S+) port/);
  if (m) return { eventType: 'successful_login', username: m[2], sourceIP: m[3], destinationPort: 22, message: line.trim(), raw: { program: 'sshd', method: m[1] } };
  m = line.match(/sudo: +(\S+) : .*COMMAND=(.*)$/);
  if (m) return { eventType: 'sudo_command', username: m[1], message: line.trim(), raw: { program: 'sudo', command: m[2] } };

  // pfSense filterlog (IPv4): rule,sub,anchor,tracker,iface,reason,action,dir,4,tos,ecn,ttl,id,off,flags,protoid,proto,len,src,dst,sport,dport,...
  m = line.match(/filterlog(?:\[\d+\])?:\s*(.*)$/);
  if (m) {
    const f = m[1].split(',');
    if (f[8] !== '4') return null;
    const proto = f[16];
    const ev = {
      eventType: f[6] === 'block' ? 'firewall_block' : 'firewall_pass',
      sourceIP: f[18], destinationIP: f[19],
      raw: { action: f[6], interface: f[4], direction: f[7], proto, tracker: f[3] },
    };
    if (proto === 'tcp' || proto === 'udp') {
      ev.destinationPort = Number(f[21]);
      ev.raw.srcPort = Number(f[20]);
      if (proto === 'tcp') ev.raw.flags = f[23];
    }
    return ev;
  }
  return null;
};

const tail = (file) => {
  let pos = fs.existsSync(file) ? fs.statSync(file).size : 0; // start at end: ship new lines only
  let partial = '';
  const read = () => {
    fs.stat(file, (err, st) => {
      if (err) return;
      if (st.size < pos) pos = 0; // rotated/truncated
      if (st.size === pos) return;
      const stream = fs.createReadStream(file, { start: pos, end: st.size - 1, encoding: 'utf8' });
      pos = st.size;
      stream.on('data', (chunk) => {
        const lines = (partial + chunk).split('\n');
        partial = lines.pop();
        lines.forEach((l) => { const ev = parseLine(l); if (ev) queue.push(ev); });
      });
    });
  };
  setInterval(read, 1000);
  console.log(`tailing ${file}`);
};

const flush = async () => {
  const batch = queue.splice(0, 100);
  try {
    if (!batch.length) {
      if (Date.now() - lastHeartbeat > 60000) {
        await fetch(`${URL_BASE}/api/ingest/heartbeat`, { method: 'POST', headers: { 'x-api-key': KEY } });
        lastHeartbeat = Date.now();
      }
      return;
    }
    const res = await fetch(`${URL_BASE}/api/ingest`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': KEY }, body: JSON.stringify({ events: batch }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || res.status);
    const hits = body.results.filter((r) => r.detection);
    console.log(`${new Date().toLocaleTimeString()} sent ${batch.length}, detections ${hits.length}`);
  } catch (e) {
    console.error(`send failed (${e.message}); requeueing ${batch.length}`);
    queue.unshift(...batch.slice(0, 5000 - queue.length));
  }
};

files.forEach(tail);
setInterval(flush, 3000);
