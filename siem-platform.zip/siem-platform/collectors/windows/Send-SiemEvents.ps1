<#
.SYNOPSIS
  Lightweight Windows Security log forwarder for the Enterprise SIEM Platform.

.DESCRIPTION
  Polls the Security event log (Get-WinEvent) for selected event IDs and posts them in
  batches to POST /api/ingest with the device's x-api-key. Sends a heartbeat when idle.
  Run from an elevated PowerShell on the Windows target (Security log needs admin).

  Prerequisite (once): enable the audit categories used in Section 4.2.1
    auditpol /set /subcategory:"Logon" /success:enable /failure:enable
    auditpol /set /subcategory:"Process Creation" /success:enable
    # optional - include command lines in 4688:
    reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\System\Audit" /v ProcessCreationIncludeCmdLine_Enabled /t REG_DWORD /d 1 /f

.EXAMPLE
  .\Send-SiemEvents.ps1 -SiemUrl http://192.168.1.10:5000 -ApiKey siem_xxxxxxxx
#>
param(
  [string]$SiemUrl = "http://192.168.1.10:5000",
  [Parameter(Mandatory = $true)][string]$ApiKey,
  [int[]]$EventIds = @(4624, 4625, 4672, 4688, 4720, 4740, 1102),
  [int]$IntervalSeconds = 10,
  [int]$LookbackMinutes = 5
)

$ErrorActionPreference = "Stop"
$stateDir = Join-Path $env:ProgramData "SiemForwarder"
$stateFile = Join-Path $stateDir "lastRecordId.txt"
New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
$lastId = if (Test-Path $stateFile) { [int64](Get-Content $stateFile) } else { 0 }
$headers = @{ "x-api-key" = $ApiKey }

function Convert-Event($e) {
  $xml = [xml]$e.ToXml()
  $data = @{}
  foreach ($d in $xml.Event.EventData.Data) { if ($d.Name) { $data[$d.Name] = [string]$d.'#text' } }
  $data["EventID"] = $e.Id
  $data["Computer"] = $e.MachineName
  $ip = $data["IpAddress"]
  $user = if ($data["TargetUserName"]) { $data["TargetUserName"] } else { $data["SubjectUserName"] }
  $msg = if ($e.Message) { ($e.Message -split "`r?`n")[0] } else { "" }
  $payload = @{
    timestamp = $e.TimeCreated.ToUniversalTime().ToString("o")
    username  = $user
    message   = $msg
    raw       = $data
  }
  if ($ip -and $ip -ne "-" -and $ip -ne "::1" -and $ip -ne "127.0.0.1") { $payload["sourceIP"] = $ip }
  return $payload
}

Write-Host "Forwarding Security events $($EventIds -join ',') to $SiemUrl every $IntervalSeconds s (Ctrl+C to stop)"
while ($true) {
  try {
    $since = (Get-Date).AddMinutes(-$LookbackMinutes)
    $events = Get-WinEvent -FilterHashtable @{ LogName = "Security"; Id = $EventIds; StartTime = $since } -ErrorAction SilentlyContinue |
      Where-Object { $_.RecordId -gt $lastId } | Sort-Object RecordId

    if ($events) {
      $batch = @()
      foreach ($e in $events) {
        $batch += (Convert-Event $e)
        if ($batch.Count -ge 100) {
          Invoke-RestMethod -Method Post -Uri "$SiemUrl/api/ingest" -Headers $headers -ContentType "application/json" `
            -Body (ConvertTo-Json -InputObject @{ events = $batch } -Depth 6) | Out-Null
          $batch = @()
        }
        $lastId = $e.RecordId
      }
      if ($batch.Count -gt 0) {
        $res = Invoke-RestMethod -Method Post -Uri "$SiemUrl/api/ingest" -Headers $headers -ContentType "application/json" `
          -Body (ConvertTo-Json -InputObject @{ events = $batch } -Depth 6)
        $detected = @($res.results | Where-Object { $_.detection }).Count
        Write-Host "$(Get-Date -Format T)  sent $($events.Count) event(s), $detected detection(s)"
      }
      Set-Content -Path $stateFile -Value $lastId
    } else {
      Invoke-RestMethod -Method Post -Uri "$SiemUrl/api/ingest/heartbeat" -Headers $headers | Out-Null
    }
  } catch {
    Write-Warning "$(Get-Date -Format T)  $($_.Exception.Message)"
  }
  Start-Sleep -Seconds $IntervalSeconds
}
