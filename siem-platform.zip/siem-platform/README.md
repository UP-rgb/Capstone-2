# Enterprise SIEM Platform

Threat Intelligence Aggregation and Attack Detection Platform. ICT312 Capstone, Group 5, Sydney Metropolitan Institute of Technology. Supervisor: A/Prof Javad Rezazadeh.

This is a working prototype of the design in the Capstone 1 report. Monitored devices push events to an authenticated ingestion API. Each event is checked by rule-based detection and the IOC database, enriched with threat intelligence, given a weighted risk score, and, above the threshold, turned into an incident tagged with its MITRE ATT&CK technique. Analysts get the alert live over Socket.io.

There are two dashboards. Which one you see depends on the role stored against your account in the database:

| Role | Lands on | Sees | Can do |
|---|---|---|---|
| `ADMIN` | `/admin` | Every tenant, device, event, alert and incident | Everything below, plus: register devices and issue API keys, manage users and roles, manage IOCs, run threat-intel lookups, assign and close incidents, measure detection quality, read the audit log |
| `CLIENT` | `/client` | Only data from devices assigned to them (`Device.ownerId`) | Triage alerts, investigate incidents, change incident status (except Closed), comment, attach evidence, search their events, produce SOC reports for their organisation |

The scoping is enforced by the API (`backend/src/utils/scope.js`), not just hidden in the interface. A client who calls `/api/incidents/<someone else's id>` gets a 404. A client who opens an `/admin` URL is redirected to `/client`.

---

## Contents

```
siem-platform/
├── backend/                Node.js + Express + Sequelize + Socket.io
│   ├── src/
│   │   ├── config/         environment and database connection
│   │   ├── models/         User, Device, SecurityEvent, Alert, Incident, IncidentComment,
│   │   │                   Evidence, IncidentAssignment, IOC, IOCMatch, ThreatIntel, AuditLog
│   │   ├── middleware/     JWT auth, RBAC, device API-key auth, rate limits, errors
│   │   ├── detection/      bruteForce, ddos, portScan, malware, phishing, powershell,
│   │   │                   dataExfiltration, index (runner)
│   │   ├── services/       pipeline, riskEngine, mitreMapper, iocMatcher, threatIntelService,
│   │   │                   incidentService, normalizer, socket, playbooks,
│   │   │                   reporting, evaluation, metrics
│   │   ├── controllers/    one per resource
│   │   ├── routes/         all API routes in one file
│   │   ├── seed/seed.js    demo users, devices, IOCs and attack history
│   │   ├── app.js          Express app (also serves the built dashboard)
│   │   └── server.js       entry point
│   └── scripts/
│       ├── simulate.js     attack-traffic simulator
│       └── unit-tests.js   database-free unit tests
├── frontend/               React + React Router + Vite + socket.io-client
│   └── src/
│       ├── pages/admin/    AdminDashboard, Devices, Users, IOC, ThreatIntel, Evaluation, Audit
│       ├── pages/client/   ClientDashboard, MyDevices
│       ├── pages/shared/   Alerts, Incidents, IncidentDetail, Events, Mitre, Playbooks,
│       │                   Reports, Account
│       ├── components/     layout, charts (severity strip, ATT&CK matrix), UI kit
│       └── context/        AuthContext (JWT session), LiveContext (Socket.io)
├── collectors/
│   ├── windows/Send-SiemEvents.ps1   Windows Security log → /api/ingest
│   └── linux/log-forwarder.js        sshd / sudo / pfSense filterlog → /api/ingest
└── docker-compose.yml      optional PostgreSQL for development
```

---

## Requirements

- Node.js 18 or newer (20 LTS recommended)
- PostgreSQL 14 or newer
- A modern browser

## Setup on the Ubuntu SIEM server (192.168.1.10)

### 1. PostgreSQL

```bash
sudo apt update && sudo apt install -y postgresql
sudo -u postgres psql <<'SQL'
CREATE USER siem_user WITH PASSWORD 'change_me';
CREATE DATABASE siem_db OWNER siem_user;
SQL
```

On a development machine with Docker you can run `docker compose up -d` instead. It uses the same credentials.

### 2. Backend

```bash
cd backend
cp .env.example .env
# Edit .env: set DB_PASSWORD, and replace JWT_SECRET with a long random value:
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"

npm install
npm run seed:reset      # creates tables + demo data (drops existing data)
npm start               # http://0.0.0.0:5000
```

Health check (report Section 3.1.4):

```bash
curl http://192.168.1.10:5000/
# {"system":"Enterprise SIEM Platform","status":"Running","timestamp":"..."}
```

**Upgrading an existing database** from an earlier copy of this project: start the backend once with `DB_SYNC_ALTER=true` to add the new `incident_assignments` table and the alert latency column, then set it back to `false`. Alternatively run `npm run seed:reset` to start fresh.

`npm run seed` without `--reset` only adds what is missing. The seed writes the plaintext API keys of the demo devices to `backend/scripts/.device-keys.json` so the simulator can use them. That file is git-ignored.

### 3. Frontend

For development with hot reload:

```bash
cd frontend
npm install
npm run dev             # http://localhost:5173, proxies /api and /socket.io to :5000
```

If the backend is on another machine, set `VITE_BACKEND=http://192.168.1.10:5000` in `frontend/.env`.

For the lab, build once and let the backend serve the dashboard on port 5000:

```bash
cd frontend && npm run build    # creates frontend/dist
cd ../backend && npm start      # http://192.168.1.10:5000 now serves the dashboard too
```

When serving this way, add the dashboard's address to `CORS_ORIGIN` in `backend/.env` only if you access it from a different origin.

### Demo accounts

| Username | Password | Role | Sees |
|---|---|---|---|
| `admin` | `Admin@123` | Administrator | Everything |
| `nishan` | `Admin@123` | Administrator | Everything |
| `acme.analyst` | `Client@123` | Client, Acme Pty Ltd | pfSense-Firewall, Windows-Target |
| `globex.analyst` | `Client@123` | Client, Globex Corporation | Globex-Web-01 |

`Ubuntu-SIEM` has no owner, so only administrators see it. The sign-in page lists these accounts. Set `VITE_SHOW_DEMO_ACCOUNTS=false` before building to hide them, and change the passwords from the Account page before any shared demo.

---

## Trying it out

1. Sign in as `admin`. The overview shows seeded history: a resolved brute-force incident, a malware incident under investigation, phishing, DDoS, exfiltration, PowerShell and C2 activity.
2. In a second browser (or a private window), sign in as `acme.analyst`. The client dashboard shows only Acme's two devices. Globex's SSH brute force and phishing incidents are not visible.
3. Generate live attacks and watch both dashboards update with toast notifications:

```bash
cd backend
npm run simulate -- --scenario bruteforce
npm run simulate -- --scenario all --url http://192.168.1.10:5000
npm run simulate -- --scenario malware --device Windows-Target
```

Scenarios: `bruteforce`, `portscan`, `ddos`, `malware`, `phishing`, `powershell`, `exfil`, `c2`, `benign`, `heartbeat`, `all`. Add `--repeat 5` for several independent runs.

The brute-force scenario reproduces the illustrative scenario in report Section 4.4: 5 failed logins within 120 seconds from one source produce a HIGH incident mapped to T1110.

4. Open an incident and move it through its lifecycle, add a comment and evidence. As the client, notice that Closed is not offered. As admin, assign the incident and close it.
5. As admin, register a new device under *Devices and API keys*. The key is shown once, along with a ready-to-run `curl` test command.
6. Open *SOC reports* (either role), choose a period, and print it or save it as PDF. Download incidents, alerts or events as CSV for the same period.
7. As admin, open *Detection evaluation* after running the simulator to see detection rate, false-positive rate and alert latency for each run.

---

## SOC reports (use case "Generate SOC Reports", Figure 5)

*SOC reports* builds a report for a chosen period (last 24 hours, 7 days, 30 days, or custom dates). Administrators get all tenants; a client gets only their organisation's devices. The report contains:

- a plain-language summary paragraph that reads on its own when printed
- totals: events, detections, alerts, incidents opened and resolved, alerts marked false positive
- incidents by severity, status and attack type, and the MITRE ATT&CK techniques observed
- analyst response times: time to first action (first status change or assignment) and time to resolve, as median and average
- activity per device, top source addresses, and the list of incidents opened in the period

*Print or save as PDF* uses a print stylesheet that hides the navigation and lays the report out for A4. The CSV buttons download the underlying incidents, alerts or events for the same period and scope. CSV cells that a spreadsheet could interpret as formulas are escaped, and every export is recorded in the audit log.

## Detection evaluation (Sections 1.2, 4.3, 4.5 and 5.3)

The report names detection rate, false-positive rate and alert latency as the evaluation metrics. The platform measures all three:

- **Ground truth.** The simulator labels every event it sends with `raw.simulation = { runId, scenario, expected }`. `expected` is the attack type the rules should produce, or `null` for the `benign` scenario (normal logons, one mistyped password, everyday PowerShell, ordinary e-mail, browsing and DNS). The `all` scenario sends benign traffic before and after the eight attacks.
- **Detection rate** = attack scenarios detected ÷ attack scenarios sent. A scenario counts once, however many events it took. Brute force, for example, is only detected on the fifth failed logon. Results are broken down per category, and misses are listed along with any wrong classification.
- **False-positive rate** = benign events classified as an attack ÷ benign events sent. Alerts that analysts mark *False positive* are also reported separately, as an operational measure for real traffic.
- **Alert latency** is stored on every new alert (`detectionLatencyMs`): the time from the triggering event reaching `/api/ingest` to the alert being saved and pushed over Socket.io. The page shows median, p95 and maximum.
- **Pipeline performance** (NFR2): processing time per event and events per minute since the server started. This is kept in memory, so it costs no extra database write per event.

```bash
npm run simulate -- --scenario all --repeat 5     # then open Detection evaluation
```

Each run gets an ID, such as `run-20261002094512-k3fz`, so you can compare runs before and after changing thresholds in `.env`. The same figures are available from `GET /api/evaluation?runId=...`, which is useful for quoting in the Capstone 2 report.

---

## Connecting real devices (FR1, FR3, NFR7)

Any device that can make an HTTPS POST can send events. Register it as admin, copy its API key, then:

```bash
curl -X POST http://192.168.1.10:5000/api/ingest \
  -H "Content-Type: application/json" \
  -H "x-api-key: <device key>" \
  -d '{"eventType":"failed_login","sourceIP":"192.168.1.50","username":"victim","message":"An account failed to log on"}'
```

The body can be one event, an array of events, or `{ "events": [...] }`, with up to 100 events per request. Recognised fields:

| Field | Notes |
|---|---|
| `eventType` | e.g. `failed_login`, `ssh_failed`, `process_creation`, `powershell_script`, `firewall_block`, `firewall_pass`, `syn_flood`, `malware_detected`, `av_alert`, `email_received`, `url_click`, `dns_query`. If missing, it is derived from a Windows `EventID` (4624, 4625, 4634, 4672, 4688, 4720, 4740, 1102, 4104) |
| `timestamp` | ISO 8601; defaults to now; future times are clamped |
| `severity` | `LOW`, `MEDIUM`, `HIGH`, `CRITICAL` (the device's own rating) |
| `sourceIP`, `destinationIP`, `destinationPort` | aliases `srcIp`, `dstIp`, `dstPort` accepted |
| `username`, `message` | free text |
| `raw` | any JSON object; stored as JSONB and shown on the incident page |

Devices should also call `POST /api/ingest/heartbeat` (same header) at least every 15 minutes. A device that is silent for longer shows as not reporting and is marked inactive (NFR4).

### Windows target (192.168.1.40)

Enable auditing first (report Section 4.2.1), then run the collector as Administrator:

```powershell
auditpol /set /subcategory:"Logon" /failure:enable /success:enable
auditpol /set /subcategory:"Process Creation" /success:enable
.\collectors\windows\Send-SiemEvents.ps1 -SiemUrl http://192.168.1.10:5000 -ApiKey <Windows-Target key>
```

It polls the Security log with `Get-WinEvent` every 10 seconds (`-IntervalSeconds`) for event IDs 4624, 4625, 4672, 4688, 4720, 4740 and 1102 (`-EventIds`), and posts them in batches. This replaces the rsyslog/Winlogbeat path described as future work in the report.

### pfSense and Linux hosts

Forward pfSense logs to the Ubuntu server with remote syslog (Status > System Logs > Settings), then tail them with the forwarder:

```bash
SIEM_URL=http://192.168.1.10:5000 SIEM_API_KEY=<pfSense key> \
  node collectors/linux/log-forwarder.js /var/log/pfsense/filter.log

SIEM_URL=http://192.168.1.10:5000 SIEM_API_KEY=<Ubuntu key> \
  node collectors/linux/log-forwarder.js /var/log/auth.log
```

It parses sshd failed and accepted logins, sudo use, and pfSense filterlog lines, and sends a heartbeat at most once a minute.

---

## How detection and scoring work

**Pipeline** (`services/pipeline.js`, report Figures 6 and 7): authenticate device → normalise → store `SecurityEvent` → run detection rules → match IOCs → enrich with threat intelligence → calculate risk → create or update an alert (score ≥ 40) → create or update an incident with a MITRE tag (score ≥ 70) → push `new_alert` over Socket.io to administrators and the device owner only.

**Detection rules** (`src/detection/`), with thresholds set in `.env`:

| Category | Trigger (defaults) | MITRE |
|---|---|---|
| brute_force | 5 failed logins from one source within 120 s | T1110 Credential Access |
| ddos | 50 events to the same destination within 10 s, or a flood report (`syn_flood`, `udp_flood`, ...) ≥ 10,000 pps | T1498 Impact |
| port_scan | 15 distinct destination ports from one source within 60 s | T1046 Discovery |
| malware | AV/EDR alert events, file hashes in the IOC database, offensive tools or executables in temp/public folders in process creation (4688) | T1204 Execution |
| phishing | two or more signals on email, click or DNS events (look-alike or punycode domains, risky TLDs, SPF/DKIM/DMARC failure, risky attachments), or a phishing IOC hit | T1566 Initial Access |
| powershell | weighted signals in 4688/4104 events: encoded commands, download cradles, Invoke-Expression, hidden window, execution-policy bypass, AMSI/Defender tampering | T1059.001 Execution |
| data_exfiltration | outbound transfer ≥ 50 MB to an external address | T1041 Exfiltration |
| ioc_reputation | any event whose IP, domain, URL or hash is in the IOC database | T1071 Command and Control |

**Risk score** (`services/riskEngine.js`, report Section 3.2). The score is additive and capped at 100:

- base score from the triggering rule
- \+ threat-intel severity: CRITICAL 30, HIGH 20, MEDIUM 15, LOW 5
- \+ highest matched confidence: HIGH 30, MEDIUM 20, LOW 15
- \+ attack bonus: ddos 30, malware 25, data_exfiltration 25, brute_force 20

Bands: CRITICAL ≥ 90, HIGH ≥ 70, MEDIUM ≥ 40, LOW < 40. The breakdown is stored with each incident and shown on its page under *Why it scored*.

**Alert-fatigue control.** Repeat detections of the same attack type from the same source on the same device within `DEDUP_WINDOW_MINUTES` (default 30) update the open alert and incident instead of creating new ones. The update increments the event count and raises severity if needed; an escalation is recorded on the timeline.

**Threat intelligence** (`THREAT_INTEL_MODE`):

- `local` (default): uses only cached and seeded records. Works offline in the isolated lab.
- `live`: queries VirusTotal (IPs, domains, URLs, hashes) and AbuseIPDB (IPs) when the keys are set. External calls are made only for events that already triggered a rule or IOC match, results are cached for `THREAT_INTEL_CACHE_HOURS`, and private addresses are never sent out. This respects the free-tier limits (report Table 4).
- `off`: no enrichment.

---

## API summary

All routes are under `/api`. Dashboard routes need `Authorization: Bearer <JWT>` from `POST /api/auth/login` (`{ "identifier": "admin", "password": "..." }`).

| Method and path | Who | Purpose |
|---|---|---|
| `GET /health` | public | health check |
| `POST /ingest`, `POST /ingest/heartbeat` | device (`x-api-key`) | event ingestion |
| `POST /auth/login`, `GET /auth/me`, `POST /auth/change-password` | any user | session |
| `GET /dashboard/stats` | scoped | dashboard figures |
| `GET /events`, `GET /events/:id` | scoped | search: `q, eventType, severity, sourceIP, deviceId, from, to, detectedOnly` |
| `GET /alerts`, `GET /alerts/:id`, `PATCH /alerts/:id/status` | scoped | alert queue |
| `GET /incidents`, `GET /incidents/:id` | scoped | filters: `status=active`, `severity`, `attackType`, `technique`, `q` |
| `PATCH /incidents/:id/status` | scoped (Closed is admin only) | lifecycle |
| `POST /incidents/:id/comments`, `POST /incidents/:id/evidence` | scoped | investigation notes |
| `GET /devices`, `GET /devices/:id` | scoped | client sees own devices |
| `GET /threat-intel`, `GET /meta/mitre`, `GET /meta/playbooks` | any user | reference data |
| `GET /reports/summary?from&to` | scoped | SOC report data |
| `GET /reports/export/incidents\|alerts\|events?from&to` | scoped | CSV export |
| `PATCH /alerts/:id/assign`, `PATCH /incidents/:id/assign` | admin | assignment (recorded in `incident_assignments`) |
| `POST /devices`, `PUT /devices/:id`, `DELETE /devices/:id`, `POST /devices/:id/regenerate-key` | admin | device management (FR2) |
| `GET/POST /users`, `PUT/DELETE /users/:id` | admin | users and roles (FR10) |
| `GET/POST /ioc`, `POST /ioc/bulk`, `PUT/DELETE /ioc/:id` | admin | IOC database (FR5) |
| `GET /threat-intel/status`, `POST /threat-intel/lookup` | admin | enrichment (FR6) |
| `GET /audit`, `GET /meta/detection-config` | admin | audit trail (FR12) |
| `GET /evaluation?runId&from&to` | admin | detection rate, false-positive rate, latency |

Socket.io events: `new_alert`, `alert_updated`, `incident_updated`. The socket connection is authenticated with the JWT. Administrators join the `admins` room; each client only receives events for their own devices.

---

## Traceability to the report

| Requirement | Where it is implemented |
|---|---|
| FR1 Device authentication | `middleware/deviceAuth.js`; SHA-256 key hash lookup; refuses disabled devices |
| FR2 Device management | `controllers/deviceController.js`; admin *Devices and API keys* page |
| FR3 Event ingestion | `controllers/ingestController.js`, `services/normalizer.js` |
| FR4 Detection engine | `src/detection/*` |
| FR5 IOC matching | `services/iocMatcher.js`, `models/IOC.js`, `models/IOCMatch.js` |
| FR6 Threat-intel enrichment | `services/threatIntelService.js` |
| FR7 Risk scoring | `services/riskEngine.js` |
| FR8 Incidents and MITRE mapping | `services/incidentService.js`, `services/mitreMapper.js` |
| FR9 Real-time alerts | `services/socket.js`, `frontend/src/context/LiveContext.jsx` |
| FR10 RBAC | `middleware/rbac.js`, `utils/scope.js`, `components/ProtectedRoute.jsx` |
| FR11 Incident lifecycle | `controllers/incidentController.js`; incident detail page; assignment history in `models/IncidentAssignment.js` |
| FR12 Audit and search | `models/AuditLog.js`, `utils/audit.js`, event search and audit log pages |
| Figure 5 "Generate SOC Reports" | `controllers/reportController.js`, `services/reporting.js`; *SOC reports* page |
| Figure 3 ERD | all tables, including `IncidentAssignment`; investigation work is held in `IncidentComment` and `Evidence` |
| Objectives (1.2), Evaluation (4.5), Future work (5.3) | `services/evaluation.js`, `controllers/evaluationController.js`, labelled simulator; *Detection evaluation* page |
| Performance (4.3) | `services/metrics.js`; `Alert.detectionLatencyMs` |
| NFR1 Security | bcrypt passwords, signed 8 h JWT, `crypto.randomBytes` keys, Helmet, rate limits, input validation |
| NFR3 Scalability | indexed PostgreSQL tables via Sequelize |
| NFR4 Availability | device heartbeats; stale devices marked inactive every minute |
| NFR5 Usability | live alerts, ATT&CK matrix view, incident workflow pages |
| NFR6 Maintainability | controllers, services, models, middleware and detection in separate modules |
| NFR7 Interoperability | vendor-neutral JSON ingestion; Windows and Linux collectors |

### Deliberate differences from the report

- **API keys are stored hashed.** The report's ERD has `apiKey (unique)`. Here the database stores `apiKeyHash` and a short `apiKeyPrefix`, and the full key is shown only once, so a database leak does not expose working device keys (report Section 3.4.1).
- **Roles are `ADMIN` and `CLIENT`.** The client role is the report's Security Analyst, scoped to the devices of one organisation. This is what lets one platform serve several clients with separate dashboards.
- **Schema is created with `sequelize.sync()`.** Versioned migrations are left for Capstone 2.
- **The Windows collector posts directly to `/api/ingest`** rather than going through rsyslog and Winlogbeat.

## Tests

```bash
cd backend && npm run test:unit
```

The 17 tests cover:

- risk scoring and banding, including the score of 85 from Section 4.4
- MITRE mapping
- Windows event normalisation and IP classification
- the brute-force, DDoS, malware, phishing, PowerShell and exfiltration rules
- a check that the simulator's benign traffic triggers no rule
- the detection-rate and false-positive calculations
- latency percentiles
- report response times, CSV escaping and date-range validation They need no database. End-to-end checks are done with the simulator above.

## Security notes for the lab

- Change every seeded password and the `JWT_SECRET` before connecting anything beyond the isolated 192.168.1.0/24 network.
- Keep `.env` and `backend/scripts/.device-keys.json` out of version control (both are in `.gitignore`).
- The seed uses only documentation address ranges (RFC 5737) and the harmless EICAR test hashes as "malicious" indicators.
- Use HTTPS (for example nginx in front of port 5000) if traffic leaves the lab network.
